package com.weidai.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.weidai.dao.NoticeMapper;
import com.weidai.pojo.Notice;
import com.weidai.service.NoticeService;

@Service("noticeService")
public class NoticeServiceImpl implements NoticeService {
	
	@Resource
	private NoticeMapper noticeMapper;

	@Override
	public List<Notice> getNotice() {
		return noticeMapper.getNotice();
	}

}
