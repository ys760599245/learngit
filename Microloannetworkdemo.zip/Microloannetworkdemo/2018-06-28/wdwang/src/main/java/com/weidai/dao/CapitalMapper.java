package com.weidai.dao;

import com.weidai.pojo.Capital;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CapitalMapper {
 
}