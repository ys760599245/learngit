package com.weidai.pojo;

import java.math.BigDecimal;

public class Usercard {
    private Integer ucId;

    private String ucUserid;

    private String ucUsername;

    private String ucIdcard;

    private String ucBanknum;

    private BigDecimal ucBankmoney;

    private Integer ucPassword;

    private String ucDebank;

    public Integer getUcId() {
        return ucId;
    }

    public void setUcId(Integer ucId) {
        this.ucId = ucId;
    }

    public String getUcUserid() {
        return ucUserid;
    }

    public void setUcUserid(String ucUserid) {
        this.ucUserid = ucUserid == null ? null : ucUserid.trim();
    }

    public String getUcUsername() {
        return ucUsername;
    }

    public void setUcUsername(String ucUsername) {
        this.ucUsername = ucUsername == null ? null : ucUsername.trim();
    }

    public String getUcIdcard() {
        return ucIdcard;
    }

    public void setUcIdcard(String ucIdcard) {
        this.ucIdcard = ucIdcard == null ? null : ucIdcard.trim();
    }

    public String getUcBanknum() {
        return ucBanknum;
    }

    public void setUcBanknum(String ucBanknum) {
        this.ucBanknum = ucBanknum == null ? null : ucBanknum.trim();
    }

    public BigDecimal getUcBankmoney() {
        return ucBankmoney;
    }

    public void setUcBankmoney(BigDecimal ucBankmoney) {
        this.ucBankmoney = ucBankmoney;
    }

    public Integer getUcPassword() {
        return ucPassword;
    }

    public void setUcPassword(Integer ucPassword) {
        this.ucPassword = ucPassword;
    }

    public String getUcDebank() {
        return ucDebank;
    }

    public void setUcDebank(String ucDebank) {
        this.ucDebank = ucDebank == null ? null : ucDebank.trim();
    }
}