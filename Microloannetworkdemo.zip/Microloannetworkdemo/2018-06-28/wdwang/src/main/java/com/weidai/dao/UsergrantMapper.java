package com.weidai.dao;

import com.weidai.pojo.Usergrant;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UsergrantMapper {
    
}