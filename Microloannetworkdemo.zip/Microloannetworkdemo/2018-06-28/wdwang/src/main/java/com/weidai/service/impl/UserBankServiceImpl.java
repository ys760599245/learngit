/**
 * 
 */
package com.weidai.service.impl;

import javax.annotation.Resource;
import javax.websocket.server.ServerEndpoint;

import org.springframework.stereotype.Service;

import com.weidai.dao.UserbankMapper;
import com.weidai.pojo.Userbank;
import com.weidai.service.UserBankService;

/**
 * @author admin
 *
 */
@Service("userBankService")
public class UserBankServiceImpl implements UserBankService {
	@Resource
	private UserbankMapper userbankMapper;

	@Override
	public int deleteByPrimaryKey(Integer ubId) {
		// TODO Auto-generated method stub
		return userbankMapper.deleteByPrimaryKey(ubId);
	}

	@Override
	public int insert(Userbank record) {
		// TODO Auto-generated method stub
		return userbankMapper.insert(record);
	}

	@Override
	public int insertSelective(Userbank record) {
		// TODO Auto-generated method stub
		return userbankMapper.insertSelective(record);
	}

	@Override
	public Userbank selectByPrimaryKey(Integer ubId) {
		// TODO Auto-generated method stub
		return userbankMapper.selectByPrimaryKey(ubId);
	}

	@Override
	public int updateByPrimaryKeySelective(Userbank record) {
		// TODO Auto-generated method stub
		return userbankMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Userbank record) {
		// TODO Auto-generated method stub
		return userbankMapper.updateByPrimaryKey(record);
	}

	@Override
	public Userbank existIDnumbers(String ubIdcard) {
		// TODO Auto-generated method stub
		return userbankMapper.existIDnumbers(ubIdcard);
	}

}
