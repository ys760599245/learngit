package com.weidai.controller;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONArray;
import com.weidai.pojo.User;
import com.weidai.pojo.Userbank;
import com.weidai.service.UserBankService;
import com.weidai.service.UserService;

@Controller
@RequestMapping("/bk")
public class bankController {
	private Logger logger=Logger.getLogger(bankController.class);
	
	@Resource
	private UserBankService userBankService;
	@Resource
	private UserService userService;
	private User user=new User();

	@RequestMapping("userinfo.html")
	public String userInfo(){
		return "userinfo";
	}
	
	@RequestMapping("usercard.html")
	public String usercard(String name,String idcard,HttpServletRequest request){
		System.out.println(name);
		System.out.println(idcard);
		request.setAttribute("name",name);
		request.setAttribute("idcard", idcard);
		return "usercard";
	}
	@RequestMapping("paymentPassword.html")
	public String payment(String money,HttpServletRequest request){
		request.setAttribute("money", money);
		return "paymentPassword";
	}
	@RequestMapping("demos.html")
	public String demos(){
		return "demos";
	}
	// 厦门银行卡 绑定手机 返回手机验证码
	@RequestMapping(value="/cellphone",method = RequestMethod.POST)
	@ResponseBody
	public Object sendCodes(@RequestParam(value="phones",required=false) String phones) {
		logger.info("输入的手机验证码================="+phones);
		int code=userService.getCode(phones);
		logger.info("返回的Ajax的手机验证码"+code);
		return code;
	}
	

	// 开通厦门卡 以及更新 用户表的状态和密码
	@RequestMapping(value = "/userbank.html", method = RequestMethod.POST)
	public String userbank(@ModelAttribute("userbank") Userbank userbank, HttpServletRequest request,
			HttpSession session) throws Exception {
		String paths = "";
		User user = (User) session.getAttribute("user");//登陆的时候存取的用户信息
		String username = user.getuUsername();// 获取手机号码 是user表的主键 是userbank的外键
		logger.info("厦门银行的银行卡开户姓名:" + userbank.getUbUsername());
		logger.info("厦门银行的银行卡开户证件号:" + userbank.getUbIdcard());
		logger.info("厦门银行的银行卡开户银行卡:" + userbank.getUbBanknum());
		logger.info("厦门银行的银行卡开户人预留手机号:" + userbank.getUbTelephone());
		logger.info("厦门银行的银行卡开户人:" + userbank.getUbPassword());
		logger.info("用户的账户名同时又是厦门银行的外键"+user.getuUsername());
		userbank.setUbUserid(username);
		//添加厦门银行卡数据返回的结果
		Integer Result = userBankService.insertSelective(userbank);
		//更新 用户的状态
		user.setuUsername(username);
		user.setuStatus(1);
		user.setuPaypassword(userbank.getUbPassword());
		Integer AffectedRow = userService.updateByPrimaryKeySelective(user);
		logger.info("厦门银行的受影响的行数=================" + Result);
		logger.debug("微贷网用户的受影响的行数=========" + AffectedRow);
		if (Result > 0 && AffectedRow > 0) {
			paths = "index";
		}else {
			paths = "usercard";
		}
		return paths ;
	}

	// 查询身份证号码是否存在
	@RequestMapping(value = "/IDexist", method = RequestMethod.POST)
	@ResponseBody
	public Object existIdnumber(@RequestParam(value = "Idnumber", required = false) String Idnumber) {
		logger.info("查看身份证号码是否存在" + Idnumber);
		Map<String, Object> map = new HashMap<String, Object>();
		Userbank userbank = userBankService.existIDnumbers(Idnumber);
//		logger.info("让我看看===================="+userbank.toString());
		if (userbank!= null) {
			map.put("Result", "exist");
		} else {
			map.put("Result", "noexist");
		}
		logger.info("========================="+map.get("Result"));
		/*return map;*/
		return JSONArray.toJSONString(map);
	}
}
