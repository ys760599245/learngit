package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Userlend {
    private Integer ulId;

    private String ulUserid;

    private Integer ulBiddataid;

    private BigDecimal ulBidmoney;

    private BigDecimal ulRate;

    private BigDecimal ulInterest;

    private Date ulBiddate;

    public Integer getUlId() {
        return ulId;
    }

    public void setUlId(Integer ulId) {
        this.ulId = ulId;
    }

    public String getUlUserid() {
        return ulUserid;
    }

    public void setUlUserid(String ulUserid) {
        this.ulUserid = ulUserid == null ? null : ulUserid.trim();
    }

    public Integer getUlBiddataid() {
        return ulBiddataid;
    }

    public void setUlBiddataid(Integer ulBiddataid) {
        this.ulBiddataid = ulBiddataid;
    }

    public BigDecimal getUlBidmoney() {
        return ulBidmoney;
    }

    public void setUlBidmoney(BigDecimal ulBidmoney) {
        this.ulBidmoney = ulBidmoney;
    }

    public BigDecimal getUlRate() {
        return ulRate;
    }

    public void setUlRate(BigDecimal ulRate) {
        this.ulRate = ulRate;
    }

    public BigDecimal getUlInterest() {
        return ulInterest;
    }

    public void setUlInterest(BigDecimal ulInterest) {
        this.ulInterest = ulInterest;
    }

    public Date getUlBiddate() {
        return ulBiddate;
    }

    public void setUlBiddate(Date ulBiddate) {
        this.ulBiddate = ulBiddate;
    }
}