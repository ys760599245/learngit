package com.weidai.dao;

import com.weidai.pojo.Userlend;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserlendMapper {
    
}