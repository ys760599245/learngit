package com.weidai.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.weidai.dao.BiddataMapper;
import com.weidai.pojo.Biddata;
import com.weidai.service.BiddataService;

@Service("biddataService")
public class BiddataServiceImpl implements BiddataService {
	
	@Resource 
	private BiddataMapper biddataMapper;
	
	@Override
	public List<Biddata> getBiddata() {
		return biddataMapper.getBiddata();
	}

	@Override
	public List<Biddata> getBiddatas() {
		return biddataMapper.getBiddatas();
	}

	@Override
	public Biddata getBid(Integer order) {
		return biddataMapper.getBid(order);
	}

	@Override
	public List<Biddata> getBidByType(Integer bdTypeid) {
		return biddataMapper.getBidByType(bdTypeid);
	}

}
