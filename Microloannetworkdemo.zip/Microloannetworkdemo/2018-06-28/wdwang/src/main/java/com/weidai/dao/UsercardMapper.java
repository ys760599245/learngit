package com.weidai.dao;

public interface UsercardMapper {

}