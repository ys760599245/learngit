package com.weidai.service;

import java.util.List;

import com.weidai.pojo.Notice;

public interface NoticeService {

	List<Notice> getNotice();
}
