package com.weidai.service;

import java.util.List;

import com.weidai.pojo.Biddata;

public interface BiddataService {
	List<Biddata> getBiddata();
	
	List<Biddata> getBiddatas();
	
	//通过订单编号查询订单详情
	Biddata getBid(Integer order);
	
	//根据类型查询标
	List<Biddata> getBidByType(Integer bdTypeid);
}
