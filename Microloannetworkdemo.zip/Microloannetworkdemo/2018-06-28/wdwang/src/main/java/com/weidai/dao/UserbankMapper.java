package com.weidai.dao;

import org.apache.ibatis.annotations.Param;
import com.weidai.pojo.Userbank;

public interface UserbankMapper {
	/**
	 * 通过主键id删除 用户厦门银行表
	 * 
	 * @param ubId
	 * @return
	 */
	int deleteByPrimaryKey(@Param("ubId") Integer ubId);

	/**
	 * 插入全部
	 * 
	 * @param record
	 * @return
	 */
	int insert(Userbank record);

	/**
	 * 
	 * @param record
	 * @return
	 */
	int insertSelective(Userbank record);

	/**
	 * 通过主键id查询
	 * 
	 * @param ubId
	 * @return
	 */
	Userbank selectByPrimaryKey(@Param("ubId") Integer ubId);

	/**
	 * 动态插入数据 可以插入一部分
	 * 
	 * @param record
	 * @return
	 */
	int updateByPrimaryKeySelective(Userbank record);

	/**
	 * 动态更新 银行卡的数据
	 * 
	 * @param record
	 * @return
	 */
	int updateByPrimaryKey(Userbank record);
	/**
	 * 根据身份证号查询是否 存在
	 * @param ubIdcard
	 * @return
	 */
	
	Userbank existIDnumbers(@Param("ubIdcard")String ubIdcard);
}