package com.weidai.dao;

import com.weidai.pojo.Loan;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface LoanMapper {
    
}