/**
 * 
 */
package com.weidai.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;


import com.weidai.dao.UserMapper;
import com.weidai.pojo.User;
import com.weidai.service.UserService;
import com.weidai.tools.sendsms;

/**
 * @author 76059
 *
 */
@Service("userService")
public class UserServiceImpl implements UserService {
	@Resource
	private UserMapper userMapper;
	int code=0;
	sendsms sendsms=new sendsms();//创建短信接口对象
	@Override
	public int deleteByPrimaryKey(String uUsername) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.deleteByPrimaryKey(uUsername);
	}

	@Override
	public int insert(User record) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.insert(record);
	}

	@Override
	public int insertSelective(User record) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.insertSelective(record);
	}

	@Override
	public User selectByPrimaryKey(String uUsername) throws Exception {
		// TODO Auto-generated method stub
		System.out.println("UserServiceImpl----------让我看看有没有手机号码"+uUsername);
		return userMapper.selectByPrimaryKey(uUsername);
	}

	@Override
	public int updateByPrimaryKeySelective(User record) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(User record) throws Exception {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKey(record);
	}

	@Override
	public User login(String uUsername, String uPassword) throws Exception {
		// TODO Auto-generated method stub
		User user = userMapper.login(uUsername);
		if (null != user) {
			if (!user.getuPassword().equals(uPassword)) {
				return null;
			}
		}
		return user;
	}

	@Override
	public int getCode(String cellphone) {
		if(cellphone!=null&&!cellphone.equals("")){
			code=(int)((Math.random()*9+1)*100000);
			System.out.println("UserServiceImpl"+code);
			System.out.println("UserServiceImpl"+cellphone);
			//sendsms.getPhone(cellphone, code);//发送手机号和本机生成的验证号码
			return code;
		}
		return 0;
	}

}
