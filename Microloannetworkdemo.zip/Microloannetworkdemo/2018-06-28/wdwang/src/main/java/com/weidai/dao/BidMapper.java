package com.weidai.dao;

import com.weidai.pojo.Bid;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BidMapper {
   
}