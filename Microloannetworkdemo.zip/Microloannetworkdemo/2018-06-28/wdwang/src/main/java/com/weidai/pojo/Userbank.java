package com.weidai.pojo;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Userbank implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Integer ubId;

    private String ubUserid;//手机号码 (外键 与User表的手机号码建立主外键关系)

    private String ubUsername;

    private String ubIdcard;

    private String ubBanknum;

    private BigDecimal ucBankmoney;

    private String ubTelephone;//预留的手机号码

    private Integer ubPassword;

    public Integer getUbId() {
        return ubId;
    }

    public void setUbId(Integer ubId) {
        this.ubId = ubId;
    }

    public String getUbUserid() {
        return ubUserid;
    }

    public void setUbUserid(String ubUserid) {
        this.ubUserid = ubUserid == null ? null : ubUserid.trim();
    }

    public String getUbUsername() {
        return ubUsername;
    }

    public void setUbUsername(String ubUsername) {
        this.ubUsername = ubUsername == null ? null : ubUsername.trim();
    }

    public String getUbIdcard() {
        return ubIdcard;
    }

    public void setUbIdcard(String ubIdcard) {
        this.ubIdcard = ubIdcard == null ? null : ubIdcard.trim();
    }

    public String getUbBanknum() {
        return ubBanknum;
    }

    public void setUbBanknum(String ubBanknum) {
        this.ubBanknum = ubBanknum == null ? null : ubBanknum.trim();
    }

    public BigDecimal getUcBankmoney() {
        return ucBankmoney;
    }

    public void setUcBankmoney(BigDecimal ucBankmoney) {
        this.ucBankmoney = ucBankmoney;
    }

    public String getUbTelephone() {
        return ubTelephone;
    }

    public void setUbTelephone(String ubTelephone) {
        this.ubTelephone = ubTelephone == null ? null : ubTelephone.trim();
    }

    public Integer getUbPassword() {
        return ubPassword;
    }

    public void setUbPassword(Integer ubPassword) {
        this.ubPassword = ubPassword;
    }
}