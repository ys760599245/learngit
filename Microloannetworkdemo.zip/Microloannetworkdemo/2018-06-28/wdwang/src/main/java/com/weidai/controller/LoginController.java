/**
 * 
 */
package com.weidai.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.jws.WebParam.Mode;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.weidai.pojo.User;
import com.weidai.service.UserService;
import com.weidai.tools.Constants;
import com.weidai.tools.PasswordMD5;

/**
 * @author 76059 登陆 注册 忘记密码
 */
@Controller
public class LoginController {
	// 进行日志记录
	private Logger logger = Logger.getLogger(LoginController.class);
	@Resource
	private UserService userService;
	private User user=new User();

	public LoginController() {
		logger.info("控制器构建成功");
	}

	// 登陆
	@RequestMapping(value = "/login.html")
	public String login() {
		logger.info("welcome to weidaiwang=========");
		return "login";
	}

	// 登陆处理
	@RequestMapping(value = "/dologin.html", method = RequestMethod.POST)
	public String dologin(@RequestParam String uUsername, @RequestParam String uPassword, HttpSession session,
			HttpServletRequest request) throws Exception {
		logger.info("dologin=========================");
		logger.info("uUsername==================" + uUsername);
		logger.info("uPassword=================" + uPassword);
		user = userService.selectByPrimaryKey(uUsername);
		if (user != null) {
			logger.info("dologin========"+user.getuPassword().equals(PasswordMD5.md5Password(uPassword)));
			if (user.getuPassword().equals(PasswordMD5.md5Password(uPassword))) {
				session.setAttribute("user", user);
				return "redirect:/sys/index.html";
			}else {
				request.setAttribute("error", "密码错误");
				return "login";
			}

		}else {
			request.setAttribute("error","用户名不存在");
			return "login";
		}
	}

	/*// 到主页面上 index.html
	@RequestMapping(value = "/sys/main.html")
	public String main() {
		return "index";
	}*/

	// 跳转到注册页面
	@RequestMapping(value = "/Register.html")
	public String Register() {
		return "register";
	}

	// 返回验证码
	@RequestMapping(value = "/cellphone",method = RequestMethod.POST)
	@ResponseBody
	public Object sendCode(@RequestParam(value = "phone", required = false) String phone, HttpSession session) {
		logger.info("获取发送的手机号码============================="+phone);
		int code=userService.getCode(phone);
		System.out.println("LoginController=============="+code);
	    return code;
	}
	//注册
	@RequestMapping(value="/Register.html",method = RequestMethod.POST)
	public String Register(@RequestParam(value="telephone",required=false) String telephone,@RequestParam(value="password") String
			password,String tjphone) throws Exception{
		User user=new User();
		String passwordmd5=PasswordMD5.md5Password(password);//将密码进行MD5加密
		user.setuUsername(telephone);//注册的手机号
		user.setuPassword(passwordmd5);
		user.setuTelephone(tjphone);//推荐人手机号码
		user.setuRegdate(new Date());//创建的时间
		user.setuPaypassword(123456);
		Integer Result=userService.insertSelective(user);
		logger.info("受影响的行数"+Result);
		if (Result>0) {
			return "login";
		}else {
			return "register";
		}
	}
	//忘记密码
	@RequestMapping(value="/forgetPassword")
	public String forgetPassword(){
		return "modifypwd1";
	}
	
	//头部
	@RequestMapping("/bottom.html")
	public String bottom(){
		return "shunliu-bottom";
	}
	//尾部的页面
	@RequestMapping("/header.html")
	public String header(){
		return "shunliu-header";
	}
	//忘记密码判断手机号码是否存在
	@RequestMapping(value="/phonxist",method=RequestMethod.POST)
	@ResponseBody
	public Object phoneExist(@RequestParam(value="phone",required=false) String phone) throws Exception{
		Map<String, Object> map = new HashMap<String, Object>();
		logger.info("查看手机号码是否存在的手机号码"+phone);
		user=userService.selectByPrimaryKey(phone);
		if (user!=null) {
			map.put("result","exist");
		}else {
			map.put("result", "nothing");
		}
		System.out.println("查看手机号码的返回值"+map.get("result"));
       return map;
	}
	
	//忘记密码获取手机验证码
	@RequestMapping(value="/cellphones",method=RequestMethod.POST)
	@ResponseBody
	public Object sendcodess(@RequestParam(value="phone",required=false) String phone){
		logger.info("忘记密码获取手机验证码的手机号"+phone);
		Integer code=userService.getCode(phone);
		logger.info("忘记密码的验证码"+code);
		return code;
	}

	// 验证身份 跳转到修改密码的界面
	@RequestMapping(value = "/modify.html", method = RequestMethod.POST)
	public String modifys(@RequestParam(value = "phoneNum", required = false) String phoneNum, Model model,HttpSession session) throws Exception {
		System.out.println("获取到当前的手机号码modifys=========================天龙人:" + phoneNum);
	    user = userService.selectByPrimaryKey(phoneNum);
		System.out.println("让我看看你的长度"+user==null);
		System.out.println("让我看看有东西没有:" + user.toString());
		model.addAttribute("phos",user.getuUsername());
		return "modifypwd2";
	}

	// 修改密码的
	@RequestMapping(value = "/modifypwdtwo.html")
	public String modifypwdtwo(@RequestParam(value = "phones", required = false) String phones,
			@RequestParam(value = "pwd", required = false) String pwd) throws Exception {
		String path = null;
		System.out.println("你好我是真的帅我看你出不出来");
		logger.info("修改密码的手机号码" + phones);
		logger.info("修改密码的密码" + pwd);
		if (phones != null && phones != "") {
			String pwdmd5 = PasswordMD5.md5Password(pwd);
			user.setuUsername(phones);
			user.setuPassword(pwdmd5);
			Integer Result = userService.updateByPrimaryKeySelective(user);
			System.out.println("让我看看结果:"+Result);
			if (Result > 0) {
				path = "modifypwd3";
			} else {
				path = "modifypwd2";
			}
		}
		return path;

	}

}
