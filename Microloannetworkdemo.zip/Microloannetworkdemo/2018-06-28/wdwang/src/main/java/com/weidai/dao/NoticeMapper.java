package com.weidai.dao;

import com.weidai.pojo.Notice;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NoticeMapper {
	
	List<Notice> getNotice();
}