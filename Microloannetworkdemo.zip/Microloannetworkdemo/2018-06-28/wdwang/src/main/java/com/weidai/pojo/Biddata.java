package com.weidai.pojo;

import java.math.BigDecimal;
import java.sql.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Biddata {
    private Integer bdId;

    private Integer bdTypeid;

    private String bdTitle;

    private BigDecimal bdLilv;

    private Integer bdTime;

    private BigDecimal bdSum;

    private BigDecimal bdExitsum;

    private String bdRepayment;

    private BigDecimal bdReduce;

    private String bdStatus;
    
    private Date bdCreateDate;
    
    

    public Date getBdCreateDate() {
		return bdCreateDate;
	}

	public void setBdCreateDate(Date bdCreateDate) {
		this.bdCreateDate = bdCreateDate;
	}

	public Integer getBdId() {
        return bdId;
    }

    public void setBdId(Integer bdId) {
        this.bdId = bdId;
    }

    public Integer getBdTypeid() {
        return bdTypeid;
    }

    public void setBdTypeid(Integer bdTypeid) {
        this.bdTypeid = bdTypeid;
    }

    public String getBdTitle() {
        return bdTitle;
    }

    public void setBdTitle(String bdTitle) {
        this.bdTitle = bdTitle == null ? null : bdTitle.trim();
    }

    public BigDecimal getBdLilv() {
        return bdLilv;
    }

    public void setBdLilv(BigDecimal bdLilv) {
        this.bdLilv = bdLilv;
    }

    public Integer getBdTime() {
        return bdTime;
    }

    public void setBdTime(Integer bdTime) {
        this.bdTime = bdTime;
    }

    public BigDecimal getBdSum() {
        return bdSum;
    }

    public void setBdSum(BigDecimal bdSum) {
        this.bdSum = bdSum;
    }

    public BigDecimal getBdExitsum() {
        return bdExitsum;
    }

    public void setBdExitsum(BigDecimal bdExitsum) {
        this.bdExitsum = bdExitsum;
    }

    public String getBdRepayment() {
        return bdRepayment;
    }

    public void setBdRepayment(String bdRepayment) {
        this.bdRepayment = bdRepayment == null ? null : bdRepayment.trim();
    }

    public BigDecimal getBdReduce() {
        return bdReduce;
    }

    public void setBdReduce(BigDecimal bdReduce) {
        this.bdReduce = bdReduce;
    }

    public String getBdStatus() {
        return bdStatus;
    }

    public void setBdStatus(String bdStatus) {
        this.bdStatus = bdStatus == null ? null : bdStatus.trim();
    }
}