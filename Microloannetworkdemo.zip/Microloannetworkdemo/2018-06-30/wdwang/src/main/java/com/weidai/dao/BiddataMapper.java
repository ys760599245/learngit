package com.weidai.dao;

import com.weidai.pojo.Biddata;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BiddataMapper {
	
	//首页查询两个
	List<Biddata> getBiddata();
	//首页查询六个
	List<Biddata> getBiddatas();
	//通过订单编号查询订单详情
	Biddata getBid(Integer order);
	//根据类型查询标
	List<Biddata> getBidByType(Integer bdTypeid);
	//根据类型查询单个表标
	Biddata getbidtoType(Integer bdTypeid);
	//修改订单的可投金额和比率
	int updateBiddata(@Param("bdId")Integer bdId,@Param("bdExitsum")Integer bdExitsum);
}