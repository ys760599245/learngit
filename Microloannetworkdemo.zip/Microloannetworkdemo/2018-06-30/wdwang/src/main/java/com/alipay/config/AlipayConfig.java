﻿package com.alipay.config;

import java.io.FileWriter;
import java.io.IOException;

/* *
 *类名：AlipayConfig
 *功能：基础配置类
 *详细：设置帐户有关信息及返回路径
 *修改日期：2017-04-05
 *说明：
 *以下代码只是为了方便商户测试而提供的样例代码，商户可以根据自己网站的需要，按照技术文档编写,并非一定要使用该代码。
 *该代码仅供学习和研究支付宝接口使用，只是提供一个参考。
 */

public class AlipayConfig {
	
//↓↓↓↓↓↓↓↓↓↓请在这里配置您的基本信息↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// 应用ID,您的APPID，收款账号既是您的APPID对应支付宝账号
	public static String app_id = "2016091400506850";
	
	// 商户私钥，您的PKCS8格式RSA2私钥
    public static String merchant_private_key = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCCsIb/DJAWitxd4DVbOPkKmqJ8E1yimbfY7Au4Ax2ierku5m9MOMD7SkDxZ7d2Q+SUryCAHvX7rHTZp7KHIJ1bPXSVu6r8NPN3xBeZhuGoTy2JHWMb8cjQmclx5rsYJC8eO7ay13S9ItL3XAbkx3zQMN1jq6HvZM3/2HP2YOIdPmggcZ16Eb/D/1d8We4Hx1FgDZUnbpmskgUCP0/7Q4WARUCQiQUBPKkevuQFUWTNbezIKQkUiGs8t8VRzGsdYfJjVPS7HjW1Esh33orpPH1DTTVEfn9kv436KPVTBvrD3QRFFOPGYmwYeyWM8fF12GoFx5O1w51ZQm/h/8ok4FFJAgMBAAECggEAP07KJlTsm67qryMEVctUgLmFynsKnc2/DHrT9nCz81hlyn1gHtlDSreenBJ1AfpDiW8IXGgjGqZg+GrPBbxb3a34guwlGQWBh1vbXsjDGWg5k7lDoG7Qq5RDzERMD5a/qHKevyW17EUpUyAmSr8EDEoPhM/IoxH+5FfzXL9z6Vv3GoT65T3RFIdEmxXjhb4str/qzSgly8XEXLI7fC0V8/34wuTh2zKK0S5mkd+lMI5uwDChOmFdLg5GtvNA3jgfyjq8JShDuS4lnQ+hnwviQl50B2zidbbF40NAluVFdxTOQOlWI5EuosWuMxO31sNGxKRNUFKXG91iwDgKf9QbcQKBgQDFEjtCFSx6acKNh7oZSjRMCN5ZvXM1PTaRhUXQkklKynqfERiWVLAe9sv8QvXlWiX6fxBLg/YgpD4d6QQD5Mg/bpa9HsK1teF2iI69sk4rfcyNHp6uwkJhByEy0HvnThjxIWJaNWk5RZ3418otqc3c6sCVNC/GvT2I9gozcWBw5QKBgQCpxMqKkLdis6dTfPRJLyFqPjCZNgLyzRwmSkXiWVp2DPgpKdp28mC8u/DwlCiPAPCnYFVUApaRl/SYhZQo3Drq6FY1OYp22VWZvalFgyMsw8++L+oSsCvZB5FL3/Jk3FvfSrJwsL315wNCjebR7c2gEGoz8IsogmN4AgohG8ZslQKBgEMW9NOHb8/wx0n1ZfaMG4ezETdN1rXONBCQZXcfBhKPIfWbFVrAVAEGleU4SowdB4bi0QJUV2s/XuJB3JsSvNVTab/ShAjmdW4sCSQtWo1V01hLj0wBWCW+DqBE95mELduROPFq83qK57+6ftrSzwGhbZSd4pHvBM7mrAxdUa69AoGAPrIxhqjZQPdOBTQxV1GzinP7KKncvuRmz/FAC86p7MzvXOxbBPCQL0NNQNvGesGDHp0iBguKpawzpZw3Uju6+oPhSni8nRW4WjXD7Kr4c5DBCODTFiG/n7/+tcG31+3VdAo3Cg0LqmOtPYgARWkINmO5hQMBsW0t5OUD7qQ+TF0CgYEAn28Bd1uAa4U4PfpkxTTNrVpL1dOn1MA9CiG0e2pVoIYRYw+h9X+3GYacq1REdrPDsb7ejbgrH4P+9UenuswrwcCIHrQjtUf/GKsUu7qIavjXBRwNpMcuLHi7Ot6J6TdY6CFkcQlR4UyTp52PRdDF/zglkPHTiKtoM8uDyFMuDdU=";
	
	// 支付宝公钥,查看地址：https://openhome.alipay.com/platform/keyManage.htm 对应APPID下的支付宝公钥。
    public static String alipay_public_key = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAsW6S+Z+crK38RU+h2hPgWde/kf1HfYmwzxNCN8OySkiV47TSvJRzcQjGEA6+KO6Io5DQJuT6GaWzoW9Zh/25opdnUoyda3bumomOhU6/SHNKXwqdvudOfMLLeEDFXDQNrTKEJeLYvwTa6TJgGekqsVFNZ3TfiZvAaIg7tJwudg3Nj85eKYpwaJkljSTDEiQp9KL0Tu3WcC5NCOGMkSAOFVmVb/iUtDQpT05V6x0G8a6A9pcmIFZOTY3xJ4UYiYrYxVGL6fl8XfPyjU4+BvX9vAU2KPZl9jc6lBwyJtg/fOTL/C7LA3AVt47I1YxWkX8k+hPHiNuGHs7b2dosJUlhGQIDAQAB";

	// 服务器异步通知页面路径  需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String notify_url = "http://工程公网访问地址/alipay.trade.page.pay-JAVA-UTF-8/notify_url.jsp";

	// 页面跳转同步通知页面路径 需http://格式的完整路径，不能加?id=123这类自定义参数，必须外网可以正常访问
	public static String return_url = "http://127.0.0.1:8080/wdwang/transfer.jsp";

	// 签名方式
	public static String sign_type = "RSA2";
	
	// 字符编码格式
	public static String charset = "utf-8";
	
	// 支付宝网关
	public static String gatewayUrl = "https://openapi.alipaydev.com/gateway.do";
	
	// 支付宝网关
	public static String log_path = "C:\\";


//↑↑↑↑↑↑↑↑↑↑请在这里配置您的基本信息↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑

    /** 
     * 写日志，方便测试（看网站需求，也可以改成把记录存入数据库）
     * @param sWord 要写入日志里的文本内容
     */
    public static void logResult(String sWord) {
        FileWriter writer = null;
        try {
            writer = new FileWriter(log_path + "alipay_log_" + System.currentTimeMillis()+".txt");
            writer.write(sWord);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (writer != null) {
                try {
                    writer.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}

