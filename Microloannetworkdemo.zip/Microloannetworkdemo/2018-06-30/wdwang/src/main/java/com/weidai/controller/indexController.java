package com.weidai.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weidai.pojo.Biddata;
import com.weidai.pojo.Notice;
import com.weidai.pojo.User;
import com.weidai.service.BiddataService;
import com.weidai.service.NoticeService;

@Controller
@RequestMapping("/sys")
public class indexController {
	
	@Resource
	private NoticeService noticeService;
	@Resource
	private BiddataService biddataService;
	
	
	//异常页面
	@RequestMapping("/error.html")
	public String error(){
		return "error";
	}
	//首页信息展示
	@RequestMapping("/index.html")
	public String index(HttpSession session){
		List<Notice> nList = noticeService.getNotice();
		List<Biddata> bList = biddataService.getBiddata();
		List<Biddata> blists=biddataService.getBiddatas();
		session.setAttribute("notice", nList);
		session.setAttribute("biddata", bList);
		session.setAttribute("biddatas", blists);
		return "index";
	}
	//X-智投
	@RequestMapping("/x_tou.html")
	public String x_tou(HttpSession session){
		Biddata data=biddataService.getbidtoType(1);
		session.setAttribute("xtou", data);
		return "x-tou";
	}
	//优选智投列表
	@RequestMapping("/zhitou.html")
	public String zhitou(HttpSession session){
		List<Biddata> zhitou = biddataService.getBidByType(2);
		session.setAttribute("zhitou", zhitou);
		return "zhitou";
	}
	//散标列表
	@RequestMapping("/sanbiao.html")
	public String sanbiao(HttpSession session){
		List<Biddata> sanbiao = biddataService.getBidByType(3);
		session.setAttribute("sanbiao", sanbiao);
		return "sanbiao";
	}
	//我要借款
	@RequestMapping("/loan.html")
	public String loan(){
		
		return "loan";
	}
	//车贷
	@RequestMapping("/carloan.html")
	public String carloan(){
		
		return "carloan";
	}
	//订单详情显示
	@RequestMapping("buy.html")
	public String buy(HttpServletRequest request,String order){
		 Biddata biddata = biddataService.getBid(Integer.parseInt(order));
		 request.setAttribute("bidinfo", biddata);
		return "buy";
	}
	//支付成功页面
	@RequestMapping("seccess.html")
	public String buyseccess(){
		return "paySuccess";
		
	}
	//计算利率
	@RequestMapping("calcultor.html")
	public String calcultor(){
		return "calcultor";
	}
	//头部引入
	@RequestMapping("header.html")
	public String header(){
		return "shunliu-header";
	}
	//尾部引入
	@RequestMapping("bottom.html")
	public String bottom(){
		return "shunliu-bottom";
	}
}
