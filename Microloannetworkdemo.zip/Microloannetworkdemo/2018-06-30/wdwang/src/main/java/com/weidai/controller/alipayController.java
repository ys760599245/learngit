package com.weidai.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.weidai.pojo.Biddata;
import com.weidai.pojo.User;
import com.weidai.pojo.Userlend;
import com.weidai.service.BiddataService;
import com.weidai.service.UserLendService;
import com.weidai.service.UserService;

@Controller
@RequestMapping("/pay")
public class alipayController {
	
	@Resource
	private BiddataService biddataService;
	@Resource
	private UserService userService;
	@Resource
	private UserLendService userLendService;
	
	@RequestMapping("/alipay.html")
	public String alipay(String bidId,String bidmoney,String bidmonth,String lilv,HttpServletRequest request,HttpSession session){
		Integer num = (int)((Math.random()*9+1)*10000); 
		request.setAttribute("WIDout_trade_no", num);
		request.setAttribute("WIDtotal_amount", bidmoney);
		request.setAttribute("WIDsubject","微贷投资" );
		request.setAttribute("WIDbody", "");
		User user =  (User) session.getAttribute("user");
		Integer bidmoneyt=Integer.parseInt(bidmoney);
		Double lilvt=Double.parseDouble(lilv);
		Integer bidmontht=Integer.parseInt(bidmonth);
		Double xi=bidmoneyt*(lilvt/100)/12*bidmontht;
		Userlend userlend=new Userlend();
		userlend.setUlBiddataid(Integer.parseInt(bidId));
		userlend.setUlBidmoney(Integer.parseInt(bidmoney));
		userlend.setUlRate(Double.parseDouble(lilv));
		userlend.setUlInterest(xi);
		userService.updateBymoney(user.getuUsername(),Integer.parseInt(bidmoney));
		userLendService.addUserlend(userlend);
		biddataService.updateBiddata(Integer.parseInt(bidId), bidmoneyt);
		return "alipay.trade.page.pay";
	}
	
}
