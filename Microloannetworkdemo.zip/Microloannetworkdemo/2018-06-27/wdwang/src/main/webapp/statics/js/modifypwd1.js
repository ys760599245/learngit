/**
 * Created by 76059 on 2018/6/24.
 */
// 成员变量
var InterValobj;// time变量 控制时间
var count = 60;// 间隔函数 1秒执行
var curCount;// 当前剩余秒数
var code = "";// 验证码
var codeLength = 6;// 验证码的长度
var code = null;// 从后台获取的验证码
var flag=false;

/* 手机号码 */

var path = $("#path").val();
$("#phoneNum").blur(function() {
	var phone = $("#phoneNum").val();
	$.ajax({
		url : path + "/phonxist",
		type : "POST",
		data : {
			"phone" : phone
		},
		datatype : "json",
		success : function(data) {
			if (data != null && data != "") {
				if (data.result == "exist") {
					$("#hint1").html("该手机已注册");
					flag=true;
					$("#temp1").val(flag);
				} else if (data.result == "nothing") {
					$("#hint1").html("该手机号未被注册过");
					flag=false;
					$("#temp1").val(flag);
				}
			}
		},
		error : function(data) {
			alert("手机号是否存在执行错误")
		},
	})
});
/* 手机号码的验证 */
/*function phoneNum() {
	var phoneCode = $("#phoneNum").val();
	var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
	if (!myreg.test(phoneCode)) {
		$(".input-out #hint1").html("手机号码格式不正确");
		return false;
	} else {
		$("#hint1").html("");
		return true;
	}
}*/
/* 身份证的格式验证 */
$("#credit").blur(function() {
	idnumber();
});
// 身份证的验证
function idnumber() {
	var Idnumber = $("#credit").val();
	/* 验证身份证的提示框 */
	var myreg = /^[1-9]\d{7}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}$|^[1-9]\d{5}[1-9]\d{3}((0\d)|(1[0-2]))(([0|1|2]\d)|3[0-1])\d{3}([0-9]|X)$/;
	if (!myreg.test(Idnumber)) {
		$("#creditId").html("身份证格式不正确");
		return false;
	} else {
		$("#creditId").html("");
		return true;
	}
}
/* 数字验证码 */
$("#Promt").click(function() {
	var randomnumber = Math.floor((Math.random() * 9 + 1) * 1000);
	/* alert(randomnumber); */
	$(this).html("<em>" + randomnumber + "</em>");
});
/* 验证数字验证码是否争正确 */
function imageCodes() {
	/* VerificationCode输入框的值 */
	var VerificationCode = $("#imgCode").val();
	/* alert("我是数字输入框的" + VerificationCode); */
	if (VerificationCode == "") {
		$("#P2").html("验证码不能为空");
		return false;
	} else if (VerificationCode != $("#Promt").text().trim()) {
		$("#P2").html("验证输入不匹配");
		return false;
	} else {
		$("#P2").html("");
		return true;
	}
	/**/
}
/* 当输入数字验证码失去光标的时候触发事件 */
$("#imgCode").blur(function() {
	imageCodes();
});
// 发送验证码 倒计时
function sendMessages() {
	curCount = count;
	// 设置button效果开始计时
	$("#getCode").attr("disabled", "true");
	$("#getCode").val("重新获取" + curCount + "(秒)");
	InterValobj = window.setInterval(SetRemainTimes, 1000);// 启动计时器 1秒执行一次
}
// timer处理函数
function SetRemainTimes() {
	if (curCount == 0) {
		window.clearInterval(InterValobj);// 停止计时器
		$("#getCode").removeAttr("disabled");// 启用按钮
		$("#getCode").val("重新发送验证码");
		code = "";// 清除验证码 如果不清除 过时间后输入的验证码依然有效
	} else {
		curCount--;
		$("#getCode").val("重新获取" + curCount + "(秒)");
	}
}
// 点击获取手机验证码的倒计时
$("#getCode").click(function() {
	var phonenums = $("#phoneNum").val();

	$.ajax({
		type : "POST",
		url : path + "/cellphones",// 请求的url
		data : "phone=" + phonenums,
		dataType : "json",
		success : function(data) {// data 返回的数据 json类型
			if (data != "" && data != null) {
				sendMessages();
			}
			code = data;// 将值赋给code
			$("#temp2").val(code);
		},
		error : function(data) {
			alert("执行错误");
		}
	});
})
// 手机发送的验证码的判断是否正确
$(".code").blur(function() {
	codejudge();
});
// 判断验证码
function codejudge() {
	var codeinput = $("#code").val();// 输入的验证码
	var codes=$("#temp2").val();
	if (codeinput == ""||codeinput == null) {
		$("#warn").html("输入的验证码不能为空");
		return false;
	} else if (codeinput != codes) {
		$("#warn").html("输入的验证码不正确");
		return false;
	} else {
		$("#warn").html("");
		return true;
	}
}
$("#submit").click(function() {
	 //true为存在该手机号 false为不存在手机号;
	 var panduan=$("#temp1").val();
	 if(panduan==false){
		 window.location.reload();
	 }else if (idnumber() != true) {
		// 身份证
		idnumber();
	} else if (imageCodes() != true) {
		// 图片验证码
		imageCodes();
	} else if (codejudge() != true) {
		// 手机验证码
		codejudge();
	} else {
		if (confirm("是否提交")) {
			$("#userForm").submit();
		}
	}
})
