/**
 * Created by panunlin on 2016/8/29 0029.
 */
var action = {
    rootPath: urlbase + '/account',
    timeout: 2000,
    method: 'post', //default method
    interface: {
        userInfo: '/userInfo',
        receivableDetail: '/receivableDetail4Calendar',
        zichanAll: '/assets/accountFlowList',
        zichanAllExport: '/assets/exportFlowExcel',
        zichanChongzhi: '/assets/rechargeRecordList',
        zichanTixian: '/assets/withdrawalRecordList',
        cancelTixian: '/assets/cancelWithdrawal',
        touziAll: '/tender/tenderDetailList',
        touziAllExport: '/tender/exportTenderExcel',
        touziYouxuan: '/tender/tenderDetailList',
        touziHuikuanPlan: '/tender/investorRecoverList',
        collectedDetail: '/receivableDetail4List',
        shoukuanDaishou: '/receivables/receivablesDetailList',
        shoukuanDaishouExport: '/receivables/exportReceivablesExcel',
        shoukuanYishou: '/receivables/receivedDetailList',
        shoukuanYishouExport: '/receivables/exportReceivedExcel',
        zhaiquanKezhuan: '/debtRight/canTransferList',
        zhaiquanZhuanzhong: '/debtRight/transferingList',
        zhaiquanYizhuan: '/debtRight/transferedList',
        zhaiquanYizhuanXplan: '/transfered/xplan',
        zhaiquanYijie: '/debtRight/undertakeList',
        zidongToubiao: "/tender/autoTenderList",
        zidongToubiaoExport: "/tender/exportAutoTenderExcel",
        redPackageList: '/redPackage/list',
        redPackageCount: '/redPackage/count',
        innerMessageList: '/systemMessageList',   ///account/innerMessageList
        inviteRecord: '/invitationList',  //
        sendMessage: '/getMessageSwitch',//获取消息开关
        updateMessageSwitch: '/updateMessageSwitch',
        summaryInviteInfo: '/summaryInvitationInfo',
        assetPacketList: '/list/assetPacketList',
        bidList: '/list/bidList',
        transferList: '/list/transferList',
        viewTransferedBid: '/bid/showTransferDetail',
        interestRateCouponlist: '/interestRateCouponlist',
        interestRateCouponRecovery: '/interestRateCouponRecovery',
        bidInterestRateCouponRecovery: '/bidInterestRateCouponRecovery',
        couponSummaryCount: '/couponSummaryCount',
        useableCount: '/redPackage/useableCount',
        authUserExist: '/regs/authUserExist',
        personalSafety: '/personal/safety',
        sendMobileCode: '/getBackPasswd/sendMobileCode.json',
        verifyCode: '/getBackPasswd/verifyCode',
        resetLoginPasswd: '/getBackPasswd/resetLoginPasswd',
        sendMessage: '/getMessageSwitch',
        queryVipWindow: '/vip/queryVipWindow',
        neverShowWindow: "/vip/neverShowWindow",
        receivedXPlanDetailList: "/receivables/receivedXPlanDetailList",
        exportReceivedXPlanExcel: '/receivables/exportReceivedXPlanExcel',
        tenderDetailXPlanList: '/tender/tenderDetailXPlanList',
        getTenderDetailXPlanBidInfo: '/tender/getTenderDetailXPlanBidInfo',
        getTenderDetailXPlanInfo: '/tender/getTenderDetailXPlanInfo',
        openOrCloseExpireRemind: '/bid/openOrCloseExpireRemind',
        getTransferedAgreementInfoList: '/debtRight/getTransferedAgreementInfoList',
        verifyResetPasswd: '/getBackPasswd/verifyResetPasswd',
        userAssetListHOLD: '/tender/userAssetList/HOLD',//X智投投资详情持有中
        userAssetListFINISH: '/tender/userAssetList/FINISH',//X智投投资详情已到期
        xplan: '/transfered/xplan',//X智投投资详情已到期
    }
}

var centerNavSetting = {
    "iconfont": [],
    "icon": ["&#xe60e;", "&#xe648;", "&#xe607;", "&#xe608;", "&#xe60c;", "&#xe649;", "&#xe611;", "&#xe601;", "&#xe647;", "&#xe60b;"/*,"&#xe60b;"*/, "&#xe60a;"],
    "name": ["账户总览", "资金管理", "出借记录", "收款明细", "银行卡", "债权转让", "自动投标", "个人资料", "我的红包", "邀请有礼"/*, "邀请奖励"*/, "消息管理"],
    "href": ["/account/accountInfo", "/account/assets/accountFlow", "/account/tender/tenderDetailAll", "/account/receivables/receivablesDetail",
        "/account/bank", "/account/debtRight/canTransfer", "/account/tender/autoTenderIndex", "/account/personal/safety", "/account/addRateRedPacket", "/goldFinancialPlannerIndex/entry"/*, "/account/myInvitation"*/, "/account/myMessage"
    ]
};

// module.exports = action;