$(document).ready(function() {
    suspend();
    suspend1();
    suspend2();
    drop_down();
    floatBtn1();
});

function suspend() {
    $('.actived-a1:eq(1)').mouseover(function() {
        $('.wdpc-header-01:eq(0)').slideDown(400);
        $('.wdpc-header-01:eq(0)').css('border-top', '1px solid rgba(1,1,1,0.1)');
        $('.touming').css('display', 'block');
    }).mouseout(function() {
        $('.wdpc-header-01').hide();
        $('.touming').css('display', 'none');
    });
    $('.wdpc-header-01').mouseover(function() {
        $(this).show();
        $('.wdpc-header').css('background-color', '#fff');
        $('.actived-a1').css('color', '#171717');
        $('.actived-x').css('border-bottom', '3px solid #171717');
        $('.weidaiwang').css('color', '#22A7FF');
        $('.header-ax').css('color', '#8a8a8a');
        $('.a-a').css('color', '#8a8a8a');
        $('.span-x').css('color', '#8a8a8a');
        $('.kf-font').css('color', '#8a8a8a');
        $('.kf-font1').css('color', '#8a8a8a');
        $('.zhanghu').css('color', '#3c3c3c');
        $('.gricon').css('background-color', 'red');
        $('.gricon').css('background', 'url(images/gr1.png)');
        $('.kficon').css('background', 'url(images/kf1.png)');
        $('.wxicon').css('background', 'url(images/wx1.png)');
        $('.touming').css('display', 'block');
    }).mouseout(function() {
        $(this).hide();
        $('.wdpc-header').css('background-color', '');
        $('.actived-a1').css({ 'color': '', 'font-weight': '' });
        $('.actived-x').css('border-bottom', '');
        $('.weidaiwang').css('color', '');
        $('.header-ax').css('color', '');
        $('.a-a').css('color', '');
        $('.span-x').css('color', '');
        $('.kf-font').css('color', '');
        $('.kf-font1').css('color', '');
        $('.zhanghu').css('color', '');
        $('.gricon').css('background', '');
        $('.kficon').css('background', '');
        $('.wxicon').css('background', '');
        $('.touming').css('display', '');
    });
}

function suspend1() {
    $('.actived-a1:eq(3)').mouseover(function() {
        $('.wdpc-header-01:eq(1)').slideDown(400);
        $('.touming').css('display', 'block');
        $('.wdpc-header-01').css('border-top', '1px solid rgba(1,1,1,0.1)');
    }).mouseout(function() {
        $('.wdpc-header-01').hide();
        $('.touming').css('display', 'none');
    });
    $('.wdpc-header-01:eq(1)').mouseover(function() {
        $(this).show();
    }).mouseout(function() {
        $(this).hide();
    });
    $('.actived-a1:eq(4)').mouseover(function() {
        $('.wdpc-header-01:eq(2)').slideDown(400);
        $('.touming').css('display', 'block');
        $('.wdpc-header-01').css('border-top', '1px solid rgba(1,1,1,0.1)');
    }).mouseout(function() {
        $('.wdpc-header-01').hide();
        $('.touming').css('display', 'none');
    });
    $('.wdpc-header-01:eq(2)').mouseover(function() {
        $(this).show();
    }).mouseout(function() {
        $(this).hide();
    });
}

function suspend2() {
    $('.style-icon-01:eq(0)').mouseover(function() {
        $('.style-xxx-02:eq(0)').css('color', '#22A7FF');
        $('.style-xxx-03:eq(0)').css('color', '#22A7FF');
    }).mouseout(function() {
        $('.style-xxx-02').css('color', '');
        $('.style-xxx-03').css('color', '');
    });
    $('.style-icon-01:eq(1)').mouseover(function() {
        $('.style-xxx-02:eq(1)').css('color', '#22A7FF');
        $('.style-xxx-03:eq(1)').css('color', '#22A7FF');
    }).mouseout(function() {
        $('.style-xxx-02').css('color', '');
        $('.style-xxx-03').css('color', '');
    });
    $('.style-icon-01:eq(2)').mouseover(function() {
        $('.style-xxx-02:eq(2)').css('color', '#22A7FF');
        $('.style-xxx-03:eq(2)').css('color', '#22A7FF');
    }).mouseout(function() {
        $('.style-xxx-02').css('color', '');
        $('.style-xxx-03').css('color', '');
    });
    $('.style-icon-01:eq(3)').mouseover(function() {
        $('.style-xxx-02:eq(3)').css('color', '#22A7FF');
        $('.style-xxx-03:eq(3)').css('color', '#22A7FF');
    }).mouseout(function() {
        $('.style-xxx-02').css('color', '');
        $('.style-xxx-03').css('color', '');
    });
    $('.style-icon-01:eq(4)').mouseover(function() {
        $('.style-xxx-02:eq(4)').css('color', '#22A7FF');
        $('.style-xxx-03:eq(4)').css('color', '#22A7FF');
    }).mouseout(function() {
        $('.style-xxx-02').css('color', '');
        $('.style-xxx-03').css('color', '');
    });
    $('.clear-fix-01').mouseover(function() {
        $(this).css('color', '#22A7FF');
    }).mouseout(function() {
        $(this).css('color', '');
    })
}

function drop_down() {
    $('.gd-header-a1 > div > ul > a > li:eq(1)').mouseover(function() {
        $('.gd-drop-down').slideDown(300);
        $('.touming').css('display','block');
        $('.gb-drop-dowm-a1 > ul:eq(0)').css('display','block');
        $('.gb-drop-dowm-a1 > ul:eq(1)').css('display','none');
        $('.gb-drop-dowm-a1 > ul:eq(2)').css('display','none');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
    $('.gd-drop-down').mouseover(function() {
        $(this).show();
        $('.touming').css('display','block');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
    $('.gd-header-a1 > div > ul > a > li:eq(3)').mouseover(function() {
        $('.gd-drop-down').slideDown(300);
        $('.touming').css('display','block');
        $('.gb-drop-dowm-a1 > ul:eq(0)').css('display','none');
        $('.gb-drop-dowm-a1 > ul:eq(1)').css('display','block');
        $('.gb-drop-dowm-a1 > ul:eq(2)').css('display','none');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
    $('.gd-drop-down').mouseover(function() {
        $(this).show();
        $('.touming').css('display','block');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
    $('.gd-header-a1 > div > ul > a > li:eq(4)').mouseover(function() {
        $('.gd-drop-down').slideDown(300);
        $('.touming').css('display','block');
        $('.gb-drop-dowm-a1 > ul:eq(0)').css('display','none');
        $('.gb-drop-dowm-a1 > ul:eq(1)').css('display','none');
        $('.gb-drop-dowm-a1 > ul:eq(2)').css('display','block');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
    $('.gd-drop-down').mouseover(function() {
        $(this).show();
        $('.touming').css('display','block');
    }).mouseout(function() {
        $('.gd-drop-down').hide();
        $('.touming').css('display','none');
    });
}

function floatBtn1() {
    $('.floatBtn1 > ul > a > li:eq(0)').mouseover(function() {
        $('.floatBtn1-ax > i').css('display','none');
        $('.floatBtn1-ax > span').css('display','block');
        $('.floatBtn1-ax > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax > span').css('display','none');
        $('.floatBtn1-ax > i').css('display','block');
    });
    $('.floatBtn1 > ul > a > li:eq(1)').mouseover(function() {
        $('.floatBtn1-ax1 > i').css('display','none');
        $('.floatBtn1-ax1 > span').css('display','block');
        $('.floatBtn1-ax1 > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax1 > span').css('display','none');
        $('.floatBtn1-ax1 > i').css('display','block');
    });
    $('.floatBtn1 > ul > a > li:eq(2)').mouseover(function() {
        $('.floatBtn1-ax2 > i').css('display','none');
        $('.floatBtn1-ax2 > span').css('display','block');
        $('.floatBtn1-ax2 > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax2 > span').css('display','none');
        $('.floatBtn1-ax2 > i').css('display','block');
    });
    $('.floatBtn1 > ul > a > li:eq(3)').mouseover(function() {
        $('.floatBtn1-ax3 > i').css('display','none');
        $('.floatBtn1-ax3 > span').css('display','block');
        $('.floatBtn1-ax3 > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax3 > span').css('display','none');
        $('.floatBtn1-ax3 > i').css('display','block');
    });
    $('.floatBtn1 > ul > a > li:eq(4)').mouseover(function() {
        $('.floatBtn1-ax4> i').css('display','none');
        $('.floatBtn1-ax4 > span').css('display','block');
        $('.floatBtn1-ax4 > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax4 > span').css('display','none');
        $('.floatBtn1-ax4 > i').css('display','block');
    });
    $('.floatBtn1 > ul > a > li:eq(5)').mouseover(function() {
        $('.floatBtn1-ax5 > i').css('display','none');
        $('.floatBtn1-ax5 > span').css('display','block');
        $('.floatBtn1-ax5 > span').css('z-index','0');
    }).mouseout(function() {
        $('.floatBtn1-ax5 > span').css('display','none');
        $('.floatBtn1-ax5 > i').css('display','block');
    });
}

window.onscroll = function() {
    var t = document.documentElement.scrollTop || document.body.scrollTop;
    var uptop = document.getElementsByClassName("gd-header")[0];
    var fhdb =  document.getElementById('fhdb');
    if (t >= 550) {
        uptop.style.display = 'block';
    } else {
        uptop.style.display = 'none';
    }
    if(t >= 400) {
        fhdb.style.display = 'block';
    }else {
        fhdb.style.display = 'none'; 
    }
}