package com.weidai.pojo;

import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Notice {
    private Integer nId;

    private String nContent;

    private Date nCreatedate;

    public Integer getnId() {
        return nId;
    }

    public void setnId(Integer nId) {
        this.nId = nId;
    }

    public String getnContent() {
        return nContent;
    }

    public void setnContent(String nContent) {
        this.nContent = nContent == null ? null : nContent.trim();
    }

    public Date getnCreatedate() {
        return nCreatedate;
    }

    public void setnCreatedate(Date nCreatedate) {
        this.nCreatedate = nCreatedate;
    }
}