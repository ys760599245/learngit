package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Loan {
    private Integer lId;

    private String lName;

    private String lTelephone;

    private BigDecimal lMoney;

    private Integer lLoantime;

    private BigDecimal lIbterest;

    private Date lLoandate;

    private Integer lStatus;

    public Integer getlId() {
        return lId;
    }

    public void setlId(Integer lId) {
        this.lId = lId;
    }

    public String getlName() {
        return lName;
    }

    public void setlName(String lName) {
        this.lName = lName == null ? null : lName.trim();
    }

    public String getlTelephone() {
        return lTelephone;
    }

    public void setlTelephone(String lTelephone) {
        this.lTelephone = lTelephone == null ? null : lTelephone.trim();
    }

    public BigDecimal getlMoney() {
        return lMoney;
    }

    public void setlMoney(BigDecimal lMoney) {
        this.lMoney = lMoney;
    }

    public Integer getlLoantime() {
        return lLoantime;
    }

    public void setlLoantime(Integer lLoantime) {
        this.lLoantime = lLoantime;
    }

    public BigDecimal getlIbterest() {
        return lIbterest;
    }

    public void setlIbterest(BigDecimal lIbterest) {
        this.lIbterest = lIbterest;
    }

    public Date getlLoandate() {
        return lLoandate;
    }

    public void setlLoandate(Date lLoandate) {
        this.lLoandate = lLoandate;
    }

    public Integer getlStatus() {
        return lStatus;
    }

    public void setlStatus(Integer lStatus) {
        this.lStatus = lStatus;
    }
}