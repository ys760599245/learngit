package com.weidai.pojo;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Usergrant {
    private Integer ugId;

    private String ugStatus;

    public Integer getUgId() {
        return ugId;
    }

    public void setUgId(Integer ugId) {
        this.ugId = ugId;
    }

    public String getUgStatus() {
        return ugStatus;
    }

    public void setUgStatus(String ugStatus) {
        this.ugStatus = ugStatus == null ? null : ugStatus.trim();
    }
}