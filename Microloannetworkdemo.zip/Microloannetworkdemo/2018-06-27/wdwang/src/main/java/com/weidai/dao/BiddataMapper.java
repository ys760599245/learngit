package com.weidai.dao;

import com.weidai.pojo.Biddata;
import com.weidai.pojo.BiddataExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface BiddataMapper {

}