package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class BiddataExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public BiddataExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andBdIdIsNull() {
            addCriterion("bd_id is null");
            return (Criteria) this;
        }

        public Criteria andBdIdIsNotNull() {
            addCriterion("bd_id is not null");
            return (Criteria) this;
        }

        public Criteria andBdIdEqualTo(Integer value) {
            addCriterion("bd_id =", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdNotEqualTo(Integer value) {
            addCriterion("bd_id <>", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdGreaterThan(Integer value) {
            addCriterion("bd_id >", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("bd_id >=", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdLessThan(Integer value) {
            addCriterion("bd_id <", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdLessThanOrEqualTo(Integer value) {
            addCriterion("bd_id <=", value, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdIn(List<Integer> values) {
            addCriterion("bd_id in", values, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdNotIn(List<Integer> values) {
            addCriterion("bd_id not in", values, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdBetween(Integer value1, Integer value2) {
            addCriterion("bd_id between", value1, value2, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdIdNotBetween(Integer value1, Integer value2) {
            addCriterion("bd_id not between", value1, value2, "bdId");
            return (Criteria) this;
        }

        public Criteria andBdTypeidIsNull() {
            addCriterion("bd_typeid is null");
            return (Criteria) this;
        }

        public Criteria andBdTypeidIsNotNull() {
            addCriterion("bd_typeid is not null");
            return (Criteria) this;
        }

        public Criteria andBdTypeidEqualTo(Integer value) {
            addCriterion("bd_typeid =", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidNotEqualTo(Integer value) {
            addCriterion("bd_typeid <>", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidGreaterThan(Integer value) {
            addCriterion("bd_typeid >", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidGreaterThanOrEqualTo(Integer value) {
            addCriterion("bd_typeid >=", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidLessThan(Integer value) {
            addCriterion("bd_typeid <", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidLessThanOrEqualTo(Integer value) {
            addCriterion("bd_typeid <=", value, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidIn(List<Integer> values) {
            addCriterion("bd_typeid in", values, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidNotIn(List<Integer> values) {
            addCriterion("bd_typeid not in", values, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidBetween(Integer value1, Integer value2) {
            addCriterion("bd_typeid between", value1, value2, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTypeidNotBetween(Integer value1, Integer value2) {
            addCriterion("bd_typeid not between", value1, value2, "bdTypeid");
            return (Criteria) this;
        }

        public Criteria andBdTitleIsNull() {
            addCriterion("bd_title is null");
            return (Criteria) this;
        }

        public Criteria andBdTitleIsNotNull() {
            addCriterion("bd_title is not null");
            return (Criteria) this;
        }

        public Criteria andBdTitleEqualTo(String value) {
            addCriterion("bd_title =", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleNotEqualTo(String value) {
            addCriterion("bd_title <>", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleGreaterThan(String value) {
            addCriterion("bd_title >", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleGreaterThanOrEqualTo(String value) {
            addCriterion("bd_title >=", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleLessThan(String value) {
            addCriterion("bd_title <", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleLessThanOrEqualTo(String value) {
            addCriterion("bd_title <=", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleLike(String value) {
            addCriterion("bd_title like", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleNotLike(String value) {
            addCriterion("bd_title not like", value, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleIn(List<String> values) {
            addCriterion("bd_title in", values, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleNotIn(List<String> values) {
            addCriterion("bd_title not in", values, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleBetween(String value1, String value2) {
            addCriterion("bd_title between", value1, value2, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdTitleNotBetween(String value1, String value2) {
            addCriterion("bd_title not between", value1, value2, "bdTitle");
            return (Criteria) this;
        }

        public Criteria andBdLilvIsNull() {
            addCriterion("bd_lilv is null");
            return (Criteria) this;
        }

        public Criteria andBdLilvIsNotNull() {
            addCriterion("bd_lilv is not null");
            return (Criteria) this;
        }

        public Criteria andBdLilvEqualTo(BigDecimal value) {
            addCriterion("bd_lilv =", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvNotEqualTo(BigDecimal value) {
            addCriterion("bd_lilv <>", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvGreaterThan(BigDecimal value) {
            addCriterion("bd_lilv >", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_lilv >=", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvLessThan(BigDecimal value) {
            addCriterion("bd_lilv <", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvLessThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_lilv <=", value, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvIn(List<BigDecimal> values) {
            addCriterion("bd_lilv in", values, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvNotIn(List<BigDecimal> values) {
            addCriterion("bd_lilv not in", values, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_lilv between", value1, value2, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdLilvNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_lilv not between", value1, value2, "bdLilv");
            return (Criteria) this;
        }

        public Criteria andBdTimeIsNull() {
            addCriterion("bd_time is null");
            return (Criteria) this;
        }

        public Criteria andBdTimeIsNotNull() {
            addCriterion("bd_time is not null");
            return (Criteria) this;
        }

        public Criteria andBdTimeEqualTo(Integer value) {
            addCriterion("bd_time =", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeNotEqualTo(Integer value) {
            addCriterion("bd_time <>", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeGreaterThan(Integer value) {
            addCriterion("bd_time >", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("bd_time >=", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeLessThan(Integer value) {
            addCriterion("bd_time <", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeLessThanOrEqualTo(Integer value) {
            addCriterion("bd_time <=", value, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeIn(List<Integer> values) {
            addCriterion("bd_time in", values, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeNotIn(List<Integer> values) {
            addCriterion("bd_time not in", values, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeBetween(Integer value1, Integer value2) {
            addCriterion("bd_time between", value1, value2, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdTimeNotBetween(Integer value1, Integer value2) {
            addCriterion("bd_time not between", value1, value2, "bdTime");
            return (Criteria) this;
        }

        public Criteria andBdSumIsNull() {
            addCriterion("bd_sum is null");
            return (Criteria) this;
        }

        public Criteria andBdSumIsNotNull() {
            addCriterion("bd_sum is not null");
            return (Criteria) this;
        }

        public Criteria andBdSumEqualTo(BigDecimal value) {
            addCriterion("bd_sum =", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumNotEqualTo(BigDecimal value) {
            addCriterion("bd_sum <>", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumGreaterThan(BigDecimal value) {
            addCriterion("bd_sum >", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_sum >=", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumLessThan(BigDecimal value) {
            addCriterion("bd_sum <", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumLessThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_sum <=", value, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumIn(List<BigDecimal> values) {
            addCriterion("bd_sum in", values, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumNotIn(List<BigDecimal> values) {
            addCriterion("bd_sum not in", values, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_sum between", value1, value2, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdSumNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_sum not between", value1, value2, "bdSum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumIsNull() {
            addCriterion("bd_exitsum is null");
            return (Criteria) this;
        }

        public Criteria andBdExitsumIsNotNull() {
            addCriterion("bd_exitsum is not null");
            return (Criteria) this;
        }

        public Criteria andBdExitsumEqualTo(BigDecimal value) {
            addCriterion("bd_exitsum =", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumNotEqualTo(BigDecimal value) {
            addCriterion("bd_exitsum <>", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumGreaterThan(BigDecimal value) {
            addCriterion("bd_exitsum >", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_exitsum >=", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumLessThan(BigDecimal value) {
            addCriterion("bd_exitsum <", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumLessThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_exitsum <=", value, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumIn(List<BigDecimal> values) {
            addCriterion("bd_exitsum in", values, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumNotIn(List<BigDecimal> values) {
            addCriterion("bd_exitsum not in", values, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_exitsum between", value1, value2, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdExitsumNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_exitsum not between", value1, value2, "bdExitsum");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentIsNull() {
            addCriterion("bd_repayment is null");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentIsNotNull() {
            addCriterion("bd_repayment is not null");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentEqualTo(String value) {
            addCriterion("bd_repayment =", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentNotEqualTo(String value) {
            addCriterion("bd_repayment <>", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentGreaterThan(String value) {
            addCriterion("bd_repayment >", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentGreaterThanOrEqualTo(String value) {
            addCriterion("bd_repayment >=", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentLessThan(String value) {
            addCriterion("bd_repayment <", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentLessThanOrEqualTo(String value) {
            addCriterion("bd_repayment <=", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentLike(String value) {
            addCriterion("bd_repayment like", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentNotLike(String value) {
            addCriterion("bd_repayment not like", value, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentIn(List<String> values) {
            addCriterion("bd_repayment in", values, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentNotIn(List<String> values) {
            addCriterion("bd_repayment not in", values, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentBetween(String value1, String value2) {
            addCriterion("bd_repayment between", value1, value2, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdRepaymentNotBetween(String value1, String value2) {
            addCriterion("bd_repayment not between", value1, value2, "bdRepayment");
            return (Criteria) this;
        }

        public Criteria andBdReduceIsNull() {
            addCriterion("bd_reduce is null");
            return (Criteria) this;
        }

        public Criteria andBdReduceIsNotNull() {
            addCriterion("bd_reduce is not null");
            return (Criteria) this;
        }

        public Criteria andBdReduceEqualTo(BigDecimal value) {
            addCriterion("bd_reduce =", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceNotEqualTo(BigDecimal value) {
            addCriterion("bd_reduce <>", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceGreaterThan(BigDecimal value) {
            addCriterion("bd_reduce >", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_reduce >=", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceLessThan(BigDecimal value) {
            addCriterion("bd_reduce <", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceLessThanOrEqualTo(BigDecimal value) {
            addCriterion("bd_reduce <=", value, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceIn(List<BigDecimal> values) {
            addCriterion("bd_reduce in", values, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceNotIn(List<BigDecimal> values) {
            addCriterion("bd_reduce not in", values, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_reduce between", value1, value2, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdReduceNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("bd_reduce not between", value1, value2, "bdReduce");
            return (Criteria) this;
        }

        public Criteria andBdStatusIsNull() {
            addCriterion("bd_status is null");
            return (Criteria) this;
        }

        public Criteria andBdStatusIsNotNull() {
            addCriterion("bd_status is not null");
            return (Criteria) this;
        }

        public Criteria andBdStatusEqualTo(String value) {
            addCriterion("bd_status =", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusNotEqualTo(String value) {
            addCriterion("bd_status <>", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusGreaterThan(String value) {
            addCriterion("bd_status >", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusGreaterThanOrEqualTo(String value) {
            addCriterion("bd_status >=", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusLessThan(String value) {
            addCriterion("bd_status <", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusLessThanOrEqualTo(String value) {
            addCriterion("bd_status <=", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusLike(String value) {
            addCriterion("bd_status like", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusNotLike(String value) {
            addCriterion("bd_status not like", value, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusIn(List<String> values) {
            addCriterion("bd_status in", values, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusNotIn(List<String> values) {
            addCriterion("bd_status not in", values, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusBetween(String value1, String value2) {
            addCriterion("bd_status between", value1, value2, "bdStatus");
            return (Criteria) this;
        }

        public Criteria andBdStatusNotBetween(String value1, String value2) {
            addCriterion("bd_status not between", value1, value2, "bdStatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}