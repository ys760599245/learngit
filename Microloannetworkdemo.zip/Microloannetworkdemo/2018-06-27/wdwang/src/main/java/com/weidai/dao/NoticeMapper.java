package com.weidai.dao;

import com.weidai.pojo.Notice;
import com.weidai.pojo.NoticeExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface NoticeMapper {
   
}