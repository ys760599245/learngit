package com.weidai.pojo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUUsernameIsNull() {
            addCriterion("u_username is null");
            return (Criteria) this;
        }

        public Criteria andUUsernameIsNotNull() {
            addCriterion("u_username is not null");
            return (Criteria) this;
        }

        public Criteria andUUsernameEqualTo(String value) {
            addCriterion("u_username =", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameNotEqualTo(String value) {
            addCriterion("u_username <>", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameGreaterThan(String value) {
            addCriterion("u_username >", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("u_username >=", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameLessThan(String value) {
            addCriterion("u_username <", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameLessThanOrEqualTo(String value) {
            addCriterion("u_username <=", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameLike(String value) {
            addCriterion("u_username like", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameNotLike(String value) {
            addCriterion("u_username not like", value, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameIn(List<String> values) {
            addCriterion("u_username in", values, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameNotIn(List<String> values) {
            addCriterion("u_username not in", values, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameBetween(String value1, String value2) {
            addCriterion("u_username between", value1, value2, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUUsernameNotBetween(String value1, String value2) {
            addCriterion("u_username not between", value1, value2, "uUsername");
            return (Criteria) this;
        }

        public Criteria andUPasswordIsNull() {
            addCriterion("u_password is null");
            return (Criteria) this;
        }

        public Criteria andUPasswordIsNotNull() {
            addCriterion("u_password is not null");
            return (Criteria) this;
        }

        public Criteria andUPasswordEqualTo(String value) {
            addCriterion("u_password =", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordNotEqualTo(String value) {
            addCriterion("u_password <>", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordGreaterThan(String value) {
            addCriterion("u_password >", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("u_password >=", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordLessThan(String value) {
            addCriterion("u_password <", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordLessThanOrEqualTo(String value) {
            addCriterion("u_password <=", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordLike(String value) {
            addCriterion("u_password like", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordNotLike(String value) {
            addCriterion("u_password not like", value, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordIn(List<String> values) {
            addCriterion("u_password in", values, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordNotIn(List<String> values) {
            addCriterion("u_password not in", values, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordBetween(String value1, String value2) {
            addCriterion("u_password between", value1, value2, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUPasswordNotBetween(String value1, String value2) {
            addCriterion("u_password not between", value1, value2, "uPassword");
            return (Criteria) this;
        }

        public Criteria andUTelephoneIsNull() {
            addCriterion("u_telephone is null");
            return (Criteria) this;
        }

        public Criteria andUTelephoneIsNotNull() {
            addCriterion("u_telephone is not null");
            return (Criteria) this;
        }

        public Criteria andUTelephoneEqualTo(String value) {
            addCriterion("u_telephone =", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneNotEqualTo(String value) {
            addCriterion("u_telephone <>", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneGreaterThan(String value) {
            addCriterion("u_telephone >", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneGreaterThanOrEqualTo(String value) {
            addCriterion("u_telephone >=", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneLessThan(String value) {
            addCriterion("u_telephone <", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneLessThanOrEqualTo(String value) {
            addCriterion("u_telephone <=", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneLike(String value) {
            addCriterion("u_telephone like", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneNotLike(String value) {
            addCriterion("u_telephone not like", value, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneIn(List<String> values) {
            addCriterion("u_telephone in", values, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneNotIn(List<String> values) {
            addCriterion("u_telephone not in", values, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneBetween(String value1, String value2) {
            addCriterion("u_telephone between", value1, value2, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUTelephoneNotBetween(String value1, String value2) {
            addCriterion("u_telephone not between", value1, value2, "uTelephone");
            return (Criteria) this;
        }

        public Criteria andUSafeIsNull() {
            addCriterion("u_safe is null");
            return (Criteria) this;
        }

        public Criteria andUSafeIsNotNull() {
            addCriterion("u_safe is not null");
            return (Criteria) this;
        }

        public Criteria andUSafeEqualTo(String value) {
            addCriterion("u_safe =", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeNotEqualTo(String value) {
            addCriterion("u_safe <>", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeGreaterThan(String value) {
            addCriterion("u_safe >", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeGreaterThanOrEqualTo(String value) {
            addCriterion("u_safe >=", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeLessThan(String value) {
            addCriterion("u_safe <", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeLessThanOrEqualTo(String value) {
            addCriterion("u_safe <=", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeLike(String value) {
            addCriterion("u_safe like", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeNotLike(String value) {
            addCriterion("u_safe not like", value, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeIn(List<String> values) {
            addCriterion("u_safe in", values, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeNotIn(List<String> values) {
            addCriterion("u_safe not in", values, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeBetween(String value1, String value2) {
            addCriterion("u_safe between", value1, value2, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUSafeNotBetween(String value1, String value2) {
            addCriterion("u_safe not between", value1, value2, "uSafe");
            return (Criteria) this;
        }

        public Criteria andUCreditIsNull() {
            addCriterion("u_credit is null");
            return (Criteria) this;
        }

        public Criteria andUCreditIsNotNull() {
            addCriterion("u_credit is not null");
            return (Criteria) this;
        }

        public Criteria andUCreditEqualTo(Integer value) {
            addCriterion("u_credit =", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditNotEqualTo(Integer value) {
            addCriterion("u_credit <>", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditGreaterThan(Integer value) {
            addCriterion("u_credit >", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditGreaterThanOrEqualTo(Integer value) {
            addCriterion("u_credit >=", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditLessThan(Integer value) {
            addCriterion("u_credit <", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditLessThanOrEqualTo(Integer value) {
            addCriterion("u_credit <=", value, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditIn(List<Integer> values) {
            addCriterion("u_credit in", values, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditNotIn(List<Integer> values) {
            addCriterion("u_credit not in", values, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditBetween(Integer value1, Integer value2) {
            addCriterion("u_credit between", value1, value2, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUCreditNotBetween(Integer value1, Integer value2) {
            addCriterion("u_credit not between", value1, value2, "uCredit");
            return (Criteria) this;
        }

        public Criteria andUBalanceIsNull() {
            addCriterion("u_balance is null");
            return (Criteria) this;
        }

        public Criteria andUBalanceIsNotNull() {
            addCriterion("u_balance is not null");
            return (Criteria) this;
        }

        public Criteria andUBalanceEqualTo(Integer value) {
            addCriterion("u_balance =", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceNotEqualTo(Integer value) {
            addCriterion("u_balance <>", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceGreaterThan(Integer value) {
            addCriterion("u_balance >", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceGreaterThanOrEqualTo(Integer value) {
            addCriterion("u_balance >=", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceLessThan(Integer value) {
            addCriterion("u_balance <", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceLessThanOrEqualTo(Integer value) {
            addCriterion("u_balance <=", value, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceIn(List<Integer> values) {
            addCriterion("u_balance in", values, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceNotIn(List<Integer> values) {
            addCriterion("u_balance not in", values, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceBetween(Integer value1, Integer value2) {
            addCriterion("u_balance between", value1, value2, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUBalanceNotBetween(Integer value1, Integer value2) {
            addCriterion("u_balance not between", value1, value2, "uBalance");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordIsNull() {
            addCriterion("u_paypassword is null");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordIsNotNull() {
            addCriterion("u_paypassword is not null");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordEqualTo(Integer value) {
            addCriterion("u_paypassword =", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordNotEqualTo(Integer value) {
            addCriterion("u_paypassword <>", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordGreaterThan(Integer value) {
            addCriterion("u_paypassword >", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordGreaterThanOrEqualTo(Integer value) {
            addCriterion("u_paypassword >=", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordLessThan(Integer value) {
            addCriterion("u_paypassword <", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordLessThanOrEqualTo(Integer value) {
            addCriterion("u_paypassword <=", value, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordIn(List<Integer> values) {
            addCriterion("u_paypassword in", values, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordNotIn(List<Integer> values) {
            addCriterion("u_paypassword not in", values, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordBetween(Integer value1, Integer value2) {
            addCriterion("u_paypassword between", value1, value2, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUPaypasswordNotBetween(Integer value1, Integer value2) {
            addCriterion("u_paypassword not between", value1, value2, "uPaypassword");
            return (Criteria) this;
        }

        public Criteria andUStatusIsNull() {
            addCriterion("u_status is null");
            return (Criteria) this;
        }

        public Criteria andUStatusIsNotNull() {
            addCriterion("u_status is not null");
            return (Criteria) this;
        }

        public Criteria andUStatusEqualTo(Integer value) {
            addCriterion("u_status =", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusNotEqualTo(Integer value) {
            addCriterion("u_status <>", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusGreaterThan(Integer value) {
            addCriterion("u_status >", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("u_status >=", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusLessThan(Integer value) {
            addCriterion("u_status <", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusLessThanOrEqualTo(Integer value) {
            addCriterion("u_status <=", value, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusIn(List<Integer> values) {
            addCriterion("u_status in", values, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusNotIn(List<Integer> values) {
            addCriterion("u_status not in", values, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusBetween(Integer value1, Integer value2) {
            addCriterion("u_status between", value1, value2, "uStatus");
            return (Criteria) this;
        }

        public Criteria andUStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("u_status not between", value1, value2, "uStatus");
            return (Criteria) this;
        }

        public Criteria andURegdateIsNull() {
            addCriterion("u_regdate is null");
            return (Criteria) this;
        }

        public Criteria andURegdateIsNotNull() {
            addCriterion("u_regdate is not null");
            return (Criteria) this;
        }

        public Criteria andURegdateEqualTo(Date value) {
            addCriterion("u_regdate =", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateNotEqualTo(Date value) {
            addCriterion("u_regdate <>", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateGreaterThan(Date value) {
            addCriterion("u_regdate >", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateGreaterThanOrEqualTo(Date value) {
            addCriterion("u_regdate >=", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateLessThan(Date value) {
            addCriterion("u_regdate <", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateLessThanOrEqualTo(Date value) {
            addCriterion("u_regdate <=", value, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateIn(List<Date> values) {
            addCriterion("u_regdate in", values, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateNotIn(List<Date> values) {
            addCriterion("u_regdate not in", values, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateBetween(Date value1, Date value2) {
            addCriterion("u_regdate between", value1, value2, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andURegdateNotBetween(Date value1, Date value2) {
            addCriterion("u_regdate not between", value1, value2, "uRegdate");
            return (Criteria) this;
        }

        public Criteria andUModifydateIsNull() {
            addCriterion("u_modifydate is null");
            return (Criteria) this;
        }

        public Criteria andUModifydateIsNotNull() {
            addCriterion("u_modifydate is not null");
            return (Criteria) this;
        }

        public Criteria andUModifydateEqualTo(Date value) {
            addCriterion("u_modifydate =", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateNotEqualTo(Date value) {
            addCriterion("u_modifydate <>", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateGreaterThan(Date value) {
            addCriterion("u_modifydate >", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateGreaterThanOrEqualTo(Date value) {
            addCriterion("u_modifydate >=", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateLessThan(Date value) {
            addCriterion("u_modifydate <", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateLessThanOrEqualTo(Date value) {
            addCriterion("u_modifydate <=", value, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateIn(List<Date> values) {
            addCriterion("u_modifydate in", values, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateNotIn(List<Date> values) {
            addCriterion("u_modifydate not in", values, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateBetween(Date value1, Date value2) {
            addCriterion("u_modifydate between", value1, value2, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUModifydateNotBetween(Date value1, Date value2) {
            addCriterion("u_modifydate not between", value1, value2, "uModifydate");
            return (Criteria) this;
        }

        public Criteria andUEmailIsNull() {
            addCriterion("u_email is null");
            return (Criteria) this;
        }

        public Criteria andUEmailIsNotNull() {
            addCriterion("u_email is not null");
            return (Criteria) this;
        }

        public Criteria andUEmailEqualTo(String value) {
            addCriterion("u_email =", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailNotEqualTo(String value) {
            addCriterion("u_email <>", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailGreaterThan(String value) {
            addCriterion("u_email >", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailGreaterThanOrEqualTo(String value) {
            addCriterion("u_email >=", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailLessThan(String value) {
            addCriterion("u_email <", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailLessThanOrEqualTo(String value) {
            addCriterion("u_email <=", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailLike(String value) {
            addCriterion("u_email like", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailNotLike(String value) {
            addCriterion("u_email not like", value, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailIn(List<String> values) {
            addCriterion("u_email in", values, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailNotIn(List<String> values) {
            addCriterion("u_email not in", values, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailBetween(String value1, String value2) {
            addCriterion("u_email between", value1, value2, "uEmail");
            return (Criteria) this;
        }

        public Criteria andUEmailNotBetween(String value1, String value2) {
            addCriterion("u_email not between", value1, value2, "uEmail");
            return (Criteria) this;
        }

        public Criteria andULoadnoteIsNull() {
            addCriterion("u_loadnote is null");
            return (Criteria) this;
        }

        public Criteria andULoadnoteIsNotNull() {
            addCriterion("u_loadnote is not null");
            return (Criteria) this;
        }

        public Criteria andULoadnoteEqualTo(Integer value) {
            addCriterion("u_loadnote =", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteNotEqualTo(Integer value) {
            addCriterion("u_loadnote <>", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteGreaterThan(Integer value) {
            addCriterion("u_loadnote >", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteGreaterThanOrEqualTo(Integer value) {
            addCriterion("u_loadnote >=", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteLessThan(Integer value) {
            addCriterion("u_loadnote <", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteLessThanOrEqualTo(Integer value) {
            addCriterion("u_loadnote <=", value, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteIn(List<Integer> values) {
            addCriterion("u_loadnote in", values, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteNotIn(List<Integer> values) {
            addCriterion("u_loadnote not in", values, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteBetween(Integer value1, Integer value2) {
            addCriterion("u_loadnote between", value1, value2, "uLoadnote");
            return (Criteria) this;
        }

        public Criteria andULoadnoteNotBetween(Integer value1, Integer value2) {
            addCriterion("u_loadnote not between", value1, value2, "uLoadnote");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}