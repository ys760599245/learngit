package com.weidai.tools;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import com.sun.org.apache.xml.internal.security.utils.Base64;
/**
 * jdk1.8版本MD5加密
 * @author Admin
 *
 */
public class JDKMD5 {
	public static String md5jdk(String password) {

        try {
            // 得到一个信息摘要器
            MessageDigest digest = MessageDigest.getInstance("md5");
            //通过MD5计算摘要
            byte[] result = digest.digest(password.getBytes());
            //base64编码算法
            //String str = Base64.getEncoder().encodeToString(result);
            String str = Base64.encode(result);//.getEncoder().encodeToString(result);
            //解码
           // byte[] bytes = Base64.getDecoder().decode(str);
            // 标准的md5加密后的结果	
            return str;
            
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return "";
        }

    }
}
