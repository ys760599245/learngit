package com.weidai.dao;

import com.weidai.pojo.Userbank;
import com.weidai.pojo.UserbankExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UserbankMapper {
   
}