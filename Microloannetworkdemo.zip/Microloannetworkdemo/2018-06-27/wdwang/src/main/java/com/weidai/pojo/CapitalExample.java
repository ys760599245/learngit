package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CapitalExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CapitalExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCaIdIsNull() {
            addCriterion("ca_id is null");
            return (Criteria) this;
        }

        public Criteria andCaIdIsNotNull() {
            addCriterion("ca_id is not null");
            return (Criteria) this;
        }

        public Criteria andCaIdEqualTo(Integer value) {
            addCriterion("ca_id =", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdNotEqualTo(Integer value) {
            addCriterion("ca_id <>", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdGreaterThan(Integer value) {
            addCriterion("ca_id >", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ca_id >=", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdLessThan(Integer value) {
            addCriterion("ca_id <", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdLessThanOrEqualTo(Integer value) {
            addCriterion("ca_id <=", value, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdIn(List<Integer> values) {
            addCriterion("ca_id in", values, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdNotIn(List<Integer> values) {
            addCriterion("ca_id not in", values, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdBetween(Integer value1, Integer value2) {
            addCriterion("ca_id between", value1, value2, "caId");
            return (Criteria) this;
        }

        public Criteria andCaIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ca_id not between", value1, value2, "caId");
            return (Criteria) this;
        }

        public Criteria andCaUsernameIsNull() {
            addCriterion("ca_username is null");
            return (Criteria) this;
        }

        public Criteria andCaUsernameIsNotNull() {
            addCriterion("ca_username is not null");
            return (Criteria) this;
        }

        public Criteria andCaUsernameEqualTo(String value) {
            addCriterion("ca_username =", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameNotEqualTo(String value) {
            addCriterion("ca_username <>", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameGreaterThan(String value) {
            addCriterion("ca_username >", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("ca_username >=", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameLessThan(String value) {
            addCriterion("ca_username <", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameLessThanOrEqualTo(String value) {
            addCriterion("ca_username <=", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameLike(String value) {
            addCriterion("ca_username like", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameNotLike(String value) {
            addCriterion("ca_username not like", value, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameIn(List<String> values) {
            addCriterion("ca_username in", values, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameNotIn(List<String> values) {
            addCriterion("ca_username not in", values, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameBetween(String value1, String value2) {
            addCriterion("ca_username between", value1, value2, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaUsernameNotBetween(String value1, String value2) {
            addCriterion("ca_username not between", value1, value2, "caUsername");
            return (Criteria) this;
        }

        public Criteria andCaMoneyIsNull() {
            addCriterion("ca_money is null");
            return (Criteria) this;
        }

        public Criteria andCaMoneyIsNotNull() {
            addCriterion("ca_money is not null");
            return (Criteria) this;
        }

        public Criteria andCaMoneyEqualTo(BigDecimal value) {
            addCriterion("ca_money =", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyNotEqualTo(BigDecimal value) {
            addCriterion("ca_money <>", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyGreaterThan(BigDecimal value) {
            addCriterion("ca_money >", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ca_money >=", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyLessThan(BigDecimal value) {
            addCriterion("ca_money <", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ca_money <=", value, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyIn(List<BigDecimal> values) {
            addCriterion("ca_money in", values, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyNotIn(List<BigDecimal> values) {
            addCriterion("ca_money not in", values, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ca_money between", value1, value2, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaMoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ca_money not between", value1, value2, "caMoney");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeIsNull() {
            addCriterion("ca_createtime is null");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeIsNotNull() {
            addCriterion("ca_createtime is not null");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeEqualTo(Date value) {
            addCriterion("ca_createtime =", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeNotEqualTo(Date value) {
            addCriterion("ca_createtime <>", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeGreaterThan(Date value) {
            addCriterion("ca_createtime >", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeGreaterThanOrEqualTo(Date value) {
            addCriterion("ca_createtime >=", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeLessThan(Date value) {
            addCriterion("ca_createtime <", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeLessThanOrEqualTo(Date value) {
            addCriterion("ca_createtime <=", value, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeIn(List<Date> values) {
            addCriterion("ca_createtime in", values, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeNotIn(List<Date> values) {
            addCriterion("ca_createtime not in", values, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeBetween(Date value1, Date value2) {
            addCriterion("ca_createtime between", value1, value2, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaCreatetimeNotBetween(Date value1, Date value2) {
            addCriterion("ca_createtime not between", value1, value2, "caCreatetime");
            return (Criteria) this;
        }

        public Criteria andCaTypeIsNull() {
            addCriterion("ca_type is null");
            return (Criteria) this;
        }

        public Criteria andCaTypeIsNotNull() {
            addCriterion("ca_type is not null");
            return (Criteria) this;
        }

        public Criteria andCaTypeEqualTo(String value) {
            addCriterion("ca_type =", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeNotEqualTo(String value) {
            addCriterion("ca_type <>", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeGreaterThan(String value) {
            addCriterion("ca_type >", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeGreaterThanOrEqualTo(String value) {
            addCriterion("ca_type >=", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeLessThan(String value) {
            addCriterion("ca_type <", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeLessThanOrEqualTo(String value) {
            addCriterion("ca_type <=", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeLike(String value) {
            addCriterion("ca_type like", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeNotLike(String value) {
            addCriterion("ca_type not like", value, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeIn(List<String> values) {
            addCriterion("ca_type in", values, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeNotIn(List<String> values) {
            addCriterion("ca_type not in", values, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeBetween(String value1, String value2) {
            addCriterion("ca_type between", value1, value2, "caType");
            return (Criteria) this;
        }

        public Criteria andCaTypeNotBetween(String value1, String value2) {
            addCriterion("ca_type not between", value1, value2, "caType");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}