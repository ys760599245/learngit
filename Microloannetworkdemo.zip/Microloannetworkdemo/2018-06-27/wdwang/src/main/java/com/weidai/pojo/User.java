package com.weidai.pojo;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class User implements Serializable {
    @Override
	public String toString() {
		return "User [uUsername=" + uUsername + ", uPassword=" + uPassword + ", uTelephone=" + uTelephone + ", uSafe="
				+ uSafe + ", uCredit=" + uCredit + ", uBalance=" + uBalance + ", uPaypassword=" + uPaypassword
				+ ", uStatus=" + uStatus + ", uRegdate=" + uRegdate + ", uModifydate=" + uModifydate + ", uEmail="
				+ uEmail + ", uLoadnote=" + uLoadnote + "]";
	}
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String uUsername;

    private String uPassword;

    public User(String uUsername, String uPassword, String uTelephone, String uSafe, Integer uCredit, Integer uBalance,
			Integer uPaypassword, Integer uStatus, Date uRegdate, Date uModifydate, String uEmail, Integer uLoadnote) {
		super();
		this.uUsername = uUsername;
		this.uPassword = uPassword;
		this.uTelephone = uTelephone;
		this.uSafe = uSafe;
		this.uCredit = uCredit;
		this.uBalance = uBalance;
		this.uPaypassword = uPaypassword;
		this.uStatus = uStatus;
		this.uRegdate = uRegdate;
		this.uModifydate = uModifydate;
		this.uEmail = uEmail;
		this.uLoadnote = uLoadnote;
	}

	public User() {
		super();
	}
	private String uTelephone;

    private String uSafe;

    private Integer uCredit;

    private Integer uBalance;

    private Integer uPaypassword;

    private Integer uStatus;

    private Date uRegdate;

    private Date uModifydate;

    private String uEmail;

    private Integer uLoadnote;

    public String getuUsername() {
        return uUsername;
    }

    public void setuUsername(String uUsername) {
        this.uUsername = uUsername == null ? null : uUsername.trim();
    }

    public String getuPassword() {
        return uPassword;
    }

    public void setuPassword(String uPassword) {
        this.uPassword = uPassword == null ? null : uPassword.trim();
    }

    public String getuTelephone() {
        return uTelephone;
    }

    public void setuTelephone(String uTelephone) {
        this.uTelephone = uTelephone == null ? null : uTelephone.trim();
    }

    public String getuSafe() {
        return uSafe;
    }

    public void setuSafe(String uSafe) {
        this.uSafe = uSafe == null ? null : uSafe.trim();
    }

    public Integer getuCredit() {
        return uCredit;
    }

    public void setuCredit(Integer uCredit) {
        this.uCredit = uCredit;
    }

    public Integer getuBalance() {
        return uBalance;
    }

    public void setuBalance(Integer uBalance) {
        this.uBalance = uBalance;
    }

    public Integer getuPaypassword() {
        return uPaypassword;
    }

    public void setuPaypassword(Integer uPaypassword) {
        this.uPaypassword = uPaypassword;
    }

    public Integer getuStatus() {
        return uStatus;
    }

    public void setuStatus(Integer uStatus) {
        this.uStatus = uStatus;
    }

    public Date getuRegdate() {
        return uRegdate;
    }

    public void setuRegdate(Date uRegdate) {
        this.uRegdate = uRegdate;
    }

    public Date getuModifydate() {
        return uModifydate;
    }

    public void setuModifydate(Date uModifydate) {
        this.uModifydate = uModifydate;
    }

    public String getuEmail() {
        return uEmail;
    }

    public void setuEmail(String uEmail) {
        this.uEmail = uEmail == null ? null : uEmail.trim();
    }

    public Integer getuLoadnote() {
        return uLoadnote;
    }

    public void setuLoadnote(Integer uLoadnote) {
        this.uLoadnote = uLoadnote;
    }
}