package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Carloan {
    private Integer clId;

    private String clName;

    private String clTelephone;

    private BigDecimal clMoney;

    private Integer clCarloantime;

    private BigDecimal clIbterest;

    private String clCarnumber;

    private String clAddress;

    private Date clCarloandate;

    private Integer clStatus;

    public Integer getClId() {
        return clId;
    }

    public void setClId(Integer clId) {
        this.clId = clId;
    }

    public String getClName() {
        return clName;
    }

    public void setClName(String clName) {
        this.clName = clName == null ? null : clName.trim();
    }

    public String getClTelephone() {
        return clTelephone;
    }

    public void setClTelephone(String clTelephone) {
        this.clTelephone = clTelephone == null ? null : clTelephone.trim();
    }

    public BigDecimal getClMoney() {
        return clMoney;
    }

    public void setClMoney(BigDecimal clMoney) {
        this.clMoney = clMoney;
    }

    public Integer getClCarloantime() {
        return clCarloantime;
    }

    public void setClCarloantime(Integer clCarloantime) {
        this.clCarloantime = clCarloantime;
    }

    public BigDecimal getClIbterest() {
        return clIbterest;
    }

    public void setClIbterest(BigDecimal clIbterest) {
        this.clIbterest = clIbterest;
    }

    public String getClCarnumber() {
        return clCarnumber;
    }

    public void setClCarnumber(String clCarnumber) {
        this.clCarnumber = clCarnumber == null ? null : clCarnumber.trim();
    }

    public String getClAddress() {
        return clAddress;
    }

    public void setClAddress(String clAddress) {
        this.clAddress = clAddress == null ? null : clAddress.trim();
    }

    public Date getClCarloandate() {
        return clCarloandate;
    }

    public void setClCarloandate(Date clCarloandate) {
        this.clCarloandate = clCarloandate;
    }

    public Integer getClStatus() {
        return clStatus;
    }

    public void setClStatus(Integer clStatus) {
        this.clStatus = clStatus;
    }
}