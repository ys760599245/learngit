package com.weidai.dao;

import com.weidai.pojo.Carloan;
import com.weidai.pojo.CarloanExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface CarloanMapper {
   
}