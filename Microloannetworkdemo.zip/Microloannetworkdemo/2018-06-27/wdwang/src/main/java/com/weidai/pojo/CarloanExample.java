package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class CarloanExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public CarloanExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andClIdIsNull() {
            addCriterion("cl_id is null");
            return (Criteria) this;
        }

        public Criteria andClIdIsNotNull() {
            addCriterion("cl_id is not null");
            return (Criteria) this;
        }

        public Criteria andClIdEqualTo(Integer value) {
            addCriterion("cl_id =", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdNotEqualTo(Integer value) {
            addCriterion("cl_id <>", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdGreaterThan(Integer value) {
            addCriterion("cl_id >", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("cl_id >=", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdLessThan(Integer value) {
            addCriterion("cl_id <", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdLessThanOrEqualTo(Integer value) {
            addCriterion("cl_id <=", value, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdIn(List<Integer> values) {
            addCriterion("cl_id in", values, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdNotIn(List<Integer> values) {
            addCriterion("cl_id not in", values, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdBetween(Integer value1, Integer value2) {
            addCriterion("cl_id between", value1, value2, "clId");
            return (Criteria) this;
        }

        public Criteria andClIdNotBetween(Integer value1, Integer value2) {
            addCriterion("cl_id not between", value1, value2, "clId");
            return (Criteria) this;
        }

        public Criteria andClNameIsNull() {
            addCriterion("cl_name is null");
            return (Criteria) this;
        }

        public Criteria andClNameIsNotNull() {
            addCriterion("cl_name is not null");
            return (Criteria) this;
        }

        public Criteria andClNameEqualTo(String value) {
            addCriterion("cl_name =", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameNotEqualTo(String value) {
            addCriterion("cl_name <>", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameGreaterThan(String value) {
            addCriterion("cl_name >", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameGreaterThanOrEqualTo(String value) {
            addCriterion("cl_name >=", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameLessThan(String value) {
            addCriterion("cl_name <", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameLessThanOrEqualTo(String value) {
            addCriterion("cl_name <=", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameLike(String value) {
            addCriterion("cl_name like", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameNotLike(String value) {
            addCriterion("cl_name not like", value, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameIn(List<String> values) {
            addCriterion("cl_name in", values, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameNotIn(List<String> values) {
            addCriterion("cl_name not in", values, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameBetween(String value1, String value2) {
            addCriterion("cl_name between", value1, value2, "clName");
            return (Criteria) this;
        }

        public Criteria andClNameNotBetween(String value1, String value2) {
            addCriterion("cl_name not between", value1, value2, "clName");
            return (Criteria) this;
        }

        public Criteria andClTelephoneIsNull() {
            addCriterion("cl_telephone is null");
            return (Criteria) this;
        }

        public Criteria andClTelephoneIsNotNull() {
            addCriterion("cl_telephone is not null");
            return (Criteria) this;
        }

        public Criteria andClTelephoneEqualTo(String value) {
            addCriterion("cl_telephone =", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneNotEqualTo(String value) {
            addCriterion("cl_telephone <>", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneGreaterThan(String value) {
            addCriterion("cl_telephone >", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneGreaterThanOrEqualTo(String value) {
            addCriterion("cl_telephone >=", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneLessThan(String value) {
            addCriterion("cl_telephone <", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneLessThanOrEqualTo(String value) {
            addCriterion("cl_telephone <=", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneLike(String value) {
            addCriterion("cl_telephone like", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneNotLike(String value) {
            addCriterion("cl_telephone not like", value, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneIn(List<String> values) {
            addCriterion("cl_telephone in", values, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneNotIn(List<String> values) {
            addCriterion("cl_telephone not in", values, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneBetween(String value1, String value2) {
            addCriterion("cl_telephone between", value1, value2, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClTelephoneNotBetween(String value1, String value2) {
            addCriterion("cl_telephone not between", value1, value2, "clTelephone");
            return (Criteria) this;
        }

        public Criteria andClMoneyIsNull() {
            addCriterion("cl_money is null");
            return (Criteria) this;
        }

        public Criteria andClMoneyIsNotNull() {
            addCriterion("cl_money is not null");
            return (Criteria) this;
        }

        public Criteria andClMoneyEqualTo(BigDecimal value) {
            addCriterion("cl_money =", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyNotEqualTo(BigDecimal value) {
            addCriterion("cl_money <>", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyGreaterThan(BigDecimal value) {
            addCriterion("cl_money >", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("cl_money >=", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyLessThan(BigDecimal value) {
            addCriterion("cl_money <", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("cl_money <=", value, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyIn(List<BigDecimal> values) {
            addCriterion("cl_money in", values, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyNotIn(List<BigDecimal> values) {
            addCriterion("cl_money not in", values, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cl_money between", value1, value2, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClMoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cl_money not between", value1, value2, "clMoney");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeIsNull() {
            addCriterion("cl_carloantime is null");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeIsNotNull() {
            addCriterion("cl_carloantime is not null");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeEqualTo(Integer value) {
            addCriterion("cl_carloantime =", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeNotEqualTo(Integer value) {
            addCriterion("cl_carloantime <>", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeGreaterThan(Integer value) {
            addCriterion("cl_carloantime >", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("cl_carloantime >=", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeLessThan(Integer value) {
            addCriterion("cl_carloantime <", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeLessThanOrEqualTo(Integer value) {
            addCriterion("cl_carloantime <=", value, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeIn(List<Integer> values) {
            addCriterion("cl_carloantime in", values, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeNotIn(List<Integer> values) {
            addCriterion("cl_carloantime not in", values, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeBetween(Integer value1, Integer value2) {
            addCriterion("cl_carloantime between", value1, value2, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClCarloantimeNotBetween(Integer value1, Integer value2) {
            addCriterion("cl_carloantime not between", value1, value2, "clCarloantime");
            return (Criteria) this;
        }

        public Criteria andClIbterestIsNull() {
            addCriterion("cl_ibterest is null");
            return (Criteria) this;
        }

        public Criteria andClIbterestIsNotNull() {
            addCriterion("cl_ibterest is not null");
            return (Criteria) this;
        }

        public Criteria andClIbterestEqualTo(BigDecimal value) {
            addCriterion("cl_ibterest =", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestNotEqualTo(BigDecimal value) {
            addCriterion("cl_ibterest <>", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestGreaterThan(BigDecimal value) {
            addCriterion("cl_ibterest >", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("cl_ibterest >=", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestLessThan(BigDecimal value) {
            addCriterion("cl_ibterest <", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestLessThanOrEqualTo(BigDecimal value) {
            addCriterion("cl_ibterest <=", value, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestIn(List<BigDecimal> values) {
            addCriterion("cl_ibterest in", values, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestNotIn(List<BigDecimal> values) {
            addCriterion("cl_ibterest not in", values, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cl_ibterest between", value1, value2, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClIbterestNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("cl_ibterest not between", value1, value2, "clIbterest");
            return (Criteria) this;
        }

        public Criteria andClCarnumberIsNull() {
            addCriterion("cl_carnumber is null");
            return (Criteria) this;
        }

        public Criteria andClCarnumberIsNotNull() {
            addCriterion("cl_carnumber is not null");
            return (Criteria) this;
        }

        public Criteria andClCarnumberEqualTo(String value) {
            addCriterion("cl_carnumber =", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberNotEqualTo(String value) {
            addCriterion("cl_carnumber <>", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberGreaterThan(String value) {
            addCriterion("cl_carnumber >", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberGreaterThanOrEqualTo(String value) {
            addCriterion("cl_carnumber >=", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberLessThan(String value) {
            addCriterion("cl_carnumber <", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberLessThanOrEqualTo(String value) {
            addCriterion("cl_carnumber <=", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberLike(String value) {
            addCriterion("cl_carnumber like", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberNotLike(String value) {
            addCriterion("cl_carnumber not like", value, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberIn(List<String> values) {
            addCriterion("cl_carnumber in", values, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberNotIn(List<String> values) {
            addCriterion("cl_carnumber not in", values, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberBetween(String value1, String value2) {
            addCriterion("cl_carnumber between", value1, value2, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClCarnumberNotBetween(String value1, String value2) {
            addCriterion("cl_carnumber not between", value1, value2, "clCarnumber");
            return (Criteria) this;
        }

        public Criteria andClAddressIsNull() {
            addCriterion("cl_address is null");
            return (Criteria) this;
        }

        public Criteria andClAddressIsNotNull() {
            addCriterion("cl_address is not null");
            return (Criteria) this;
        }

        public Criteria andClAddressEqualTo(String value) {
            addCriterion("cl_address =", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressNotEqualTo(String value) {
            addCriterion("cl_address <>", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressGreaterThan(String value) {
            addCriterion("cl_address >", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressGreaterThanOrEqualTo(String value) {
            addCriterion("cl_address >=", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressLessThan(String value) {
            addCriterion("cl_address <", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressLessThanOrEqualTo(String value) {
            addCriterion("cl_address <=", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressLike(String value) {
            addCriterion("cl_address like", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressNotLike(String value) {
            addCriterion("cl_address not like", value, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressIn(List<String> values) {
            addCriterion("cl_address in", values, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressNotIn(List<String> values) {
            addCriterion("cl_address not in", values, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressBetween(String value1, String value2) {
            addCriterion("cl_address between", value1, value2, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClAddressNotBetween(String value1, String value2) {
            addCriterion("cl_address not between", value1, value2, "clAddress");
            return (Criteria) this;
        }

        public Criteria andClCarloandateIsNull() {
            addCriterion("cl_carloandate is null");
            return (Criteria) this;
        }

        public Criteria andClCarloandateIsNotNull() {
            addCriterion("cl_carloandate is not null");
            return (Criteria) this;
        }

        public Criteria andClCarloandateEqualTo(Date value) {
            addCriterion("cl_carloandate =", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateNotEqualTo(Date value) {
            addCriterion("cl_carloandate <>", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateGreaterThan(Date value) {
            addCriterion("cl_carloandate >", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateGreaterThanOrEqualTo(Date value) {
            addCriterion("cl_carloandate >=", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateLessThan(Date value) {
            addCriterion("cl_carloandate <", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateLessThanOrEqualTo(Date value) {
            addCriterion("cl_carloandate <=", value, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateIn(List<Date> values) {
            addCriterion("cl_carloandate in", values, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateNotIn(List<Date> values) {
            addCriterion("cl_carloandate not in", values, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateBetween(Date value1, Date value2) {
            addCriterion("cl_carloandate between", value1, value2, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClCarloandateNotBetween(Date value1, Date value2) {
            addCriterion("cl_carloandate not between", value1, value2, "clCarloandate");
            return (Criteria) this;
        }

        public Criteria andClStatusIsNull() {
            addCriterion("cl_status is null");
            return (Criteria) this;
        }

        public Criteria andClStatusIsNotNull() {
            addCriterion("cl_status is not null");
            return (Criteria) this;
        }

        public Criteria andClStatusEqualTo(Integer value) {
            addCriterion("cl_status =", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusNotEqualTo(Integer value) {
            addCriterion("cl_status <>", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusGreaterThan(Integer value) {
            addCriterion("cl_status >", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("cl_status >=", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusLessThan(Integer value) {
            addCriterion("cl_status <", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusLessThanOrEqualTo(Integer value) {
            addCriterion("cl_status <=", value, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusIn(List<Integer> values) {
            addCriterion("cl_status in", values, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusNotIn(List<Integer> values) {
            addCriterion("cl_status not in", values, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusBetween(Integer value1, Integer value2) {
            addCriterion("cl_status between", value1, value2, "clStatus");
            return (Criteria) this;
        }

        public Criteria andClStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("cl_status not between", value1, value2, "clStatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}