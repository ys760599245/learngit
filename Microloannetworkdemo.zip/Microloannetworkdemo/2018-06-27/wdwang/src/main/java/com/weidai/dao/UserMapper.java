package com.weidai.dao;

import org.apache.ibatis.annotations.Param;

import com.weidai.pojo.User;


public interface UserMapper {
	/**
	 * 根据手机号码删除用户
	 * @param uUsername
	 * @return
	 */
    int deleteByPrimaryKey(@Param("uUsername") String uUsername);
    /**
     * 添加用户 全部数据必须插入一遍
     * @param record
     * @return
     */

    int insert(User record);
      /**
       * 有选择性的插入数据
       * @param record
       * @return
       */
    int insertSelective(User record);
     /**
      * 通过手机号码查询是否有该用户
      * @param uUsername
      * @return
      */
    User selectByPrimaryKey(@Param("uUsername") String uUsername);
     /**
      * 更新新的model中不为空的字段。
      * 有选择性的更新
      * @param record
      * @return
      */
    int updateByPrimaryKeySelective(User record);
     /**
      * 将为空的字段在数据库中置为NULL
      * @param record
      * @return
      */
    int updateByPrimaryKey(User record);
    /**
     * 通过手机号码和密码登陆
     * @param uUsername
     * @param uPassword
     * @return
     */
     User login(@Param("uUsername") String uUsername);
}