package com.weidai.service;

import org.apache.ibatis.annotations.Param;

import com.weidai.pojo.User;

public interface UserService {
	/**
	 * 根据手机号码删除用户
	 * @param uUsername
	 * @return
	 */
    int deleteByPrimaryKey(String uUsername) throws Exception;
    /**
     * 添加用户 全部数据必须插入一遍
     * @param record
     * @return
     */

    int insert(User record) throws Exception;
      /**
       * 有选择性的插入数据
       * @param record
       * @return
       */
    int insertSelective(User record) throws Exception;
     /**
      * 通过手机号码查询是否有该用户
      * @param uUsername
      * @return
      */
    User selectByPrimaryKey(String uUsername) throws Exception;
     /**
      * 更新新的model中不为空的字段。
      * 有选择性的更新
      * @param record
      * @return
      */
    int updateByPrimaryKeySelective(User record) throws Exception;
     /**
      * 将为空的字段在数据库中置为NULL
      * @param record
      * @return
      */
    int updateByPrimaryKey(User record) throws Exception;
    /**
     * 通过手机号码和密码登陆
     * @param uUsername
     * @param uPassword
     * @return
     */
     User login(String uUsername, String uPassword) throws Exception;
     /**
 	 * 短信接口
 	 * @param phone
 	 */
 	 int getCode(String cellphone);
}
