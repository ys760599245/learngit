package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Capital {
    private Integer caId;

    private String caUsername;

    private BigDecimal caMoney;

    private Date caCreatetime;

    private String caType;

    public Integer getCaId() {
        return caId;
    }

    public void setCaId(Integer caId) {
        this.caId = caId;
    }

    public String getCaUsername() {
        return caUsername;
    }

    public void setCaUsername(String caUsername) {
        this.caUsername = caUsername == null ? null : caUsername.trim();
    }

    public BigDecimal getCaMoney() {
        return caMoney;
    }

    public void setCaMoney(BigDecimal caMoney) {
        this.caMoney = caMoney;
    }

    public Date getCaCreatetime() {
        return caCreatetime;
    }

    public void setCaCreatetime(Date caCreatetime) {
        this.caCreatetime = caCreatetime;
    }

    public String getCaType() {
        return caType;
    }

    public void setCaType(String caType) {
        this.caType = caType == null ? null : caType.trim();
    }
}