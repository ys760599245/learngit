package com.weidai.pojo;

/**
 * 
 * 
 * @author wcyong
 * 
 * @date 2018-06-20
 */
public class Bid {
    private Integer bId;

    private String bType;

    public Integer getbId() {
        return bId;
    }

    public void setbId(Integer bId) {
        this.bId = bId;
    }

    public String getbType() {
        return bType;
    }

    public void setbType(String bType) {
        this.bType = bType == null ? null : bType.trim();
    }
}