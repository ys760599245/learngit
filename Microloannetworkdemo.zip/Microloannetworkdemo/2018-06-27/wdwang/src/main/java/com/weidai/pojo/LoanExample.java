package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class LoanExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public LoanExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andLIdIsNull() {
            addCriterion("l_id is null");
            return (Criteria) this;
        }

        public Criteria andLIdIsNotNull() {
            addCriterion("l_id is not null");
            return (Criteria) this;
        }

        public Criteria andLIdEqualTo(Integer value) {
            addCriterion("l_id =", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdNotEqualTo(Integer value) {
            addCriterion("l_id <>", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdGreaterThan(Integer value) {
            addCriterion("l_id >", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("l_id >=", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdLessThan(Integer value) {
            addCriterion("l_id <", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdLessThanOrEqualTo(Integer value) {
            addCriterion("l_id <=", value, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdIn(List<Integer> values) {
            addCriterion("l_id in", values, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdNotIn(List<Integer> values) {
            addCriterion("l_id not in", values, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdBetween(Integer value1, Integer value2) {
            addCriterion("l_id between", value1, value2, "lId");
            return (Criteria) this;
        }

        public Criteria andLIdNotBetween(Integer value1, Integer value2) {
            addCriterion("l_id not between", value1, value2, "lId");
            return (Criteria) this;
        }

        public Criteria andLNameIsNull() {
            addCriterion("l_name is null");
            return (Criteria) this;
        }

        public Criteria andLNameIsNotNull() {
            addCriterion("l_name is not null");
            return (Criteria) this;
        }

        public Criteria andLNameEqualTo(String value) {
            addCriterion("l_name =", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameNotEqualTo(String value) {
            addCriterion("l_name <>", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameGreaterThan(String value) {
            addCriterion("l_name >", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameGreaterThanOrEqualTo(String value) {
            addCriterion("l_name >=", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameLessThan(String value) {
            addCriterion("l_name <", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameLessThanOrEqualTo(String value) {
            addCriterion("l_name <=", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameLike(String value) {
            addCriterion("l_name like", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameNotLike(String value) {
            addCriterion("l_name not like", value, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameIn(List<String> values) {
            addCriterion("l_name in", values, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameNotIn(List<String> values) {
            addCriterion("l_name not in", values, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameBetween(String value1, String value2) {
            addCriterion("l_name between", value1, value2, "lName");
            return (Criteria) this;
        }

        public Criteria andLNameNotBetween(String value1, String value2) {
            addCriterion("l_name not between", value1, value2, "lName");
            return (Criteria) this;
        }

        public Criteria andLTelephoneIsNull() {
            addCriterion("l_telephone is null");
            return (Criteria) this;
        }

        public Criteria andLTelephoneIsNotNull() {
            addCriterion("l_telephone is not null");
            return (Criteria) this;
        }

        public Criteria andLTelephoneEqualTo(String value) {
            addCriterion("l_telephone =", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneNotEqualTo(String value) {
            addCriterion("l_telephone <>", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneGreaterThan(String value) {
            addCriterion("l_telephone >", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneGreaterThanOrEqualTo(String value) {
            addCriterion("l_telephone >=", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneLessThan(String value) {
            addCriterion("l_telephone <", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneLessThanOrEqualTo(String value) {
            addCriterion("l_telephone <=", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneLike(String value) {
            addCriterion("l_telephone like", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneNotLike(String value) {
            addCriterion("l_telephone not like", value, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneIn(List<String> values) {
            addCriterion("l_telephone in", values, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneNotIn(List<String> values) {
            addCriterion("l_telephone not in", values, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneBetween(String value1, String value2) {
            addCriterion("l_telephone between", value1, value2, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLTelephoneNotBetween(String value1, String value2) {
            addCriterion("l_telephone not between", value1, value2, "lTelephone");
            return (Criteria) this;
        }

        public Criteria andLMoneyIsNull() {
            addCriterion("l_money is null");
            return (Criteria) this;
        }

        public Criteria andLMoneyIsNotNull() {
            addCriterion("l_money is not null");
            return (Criteria) this;
        }

        public Criteria andLMoneyEqualTo(BigDecimal value) {
            addCriterion("l_money =", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyNotEqualTo(BigDecimal value) {
            addCriterion("l_money <>", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyGreaterThan(BigDecimal value) {
            addCriterion("l_money >", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("l_money >=", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyLessThan(BigDecimal value) {
            addCriterion("l_money <", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("l_money <=", value, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyIn(List<BigDecimal> values) {
            addCriterion("l_money in", values, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyNotIn(List<BigDecimal> values) {
            addCriterion("l_money not in", values, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("l_money between", value1, value2, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLMoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("l_money not between", value1, value2, "lMoney");
            return (Criteria) this;
        }

        public Criteria andLLoantimeIsNull() {
            addCriterion("l_loantime is null");
            return (Criteria) this;
        }

        public Criteria andLLoantimeIsNotNull() {
            addCriterion("l_loantime is not null");
            return (Criteria) this;
        }

        public Criteria andLLoantimeEqualTo(Integer value) {
            addCriterion("l_loantime =", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeNotEqualTo(Integer value) {
            addCriterion("l_loantime <>", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeGreaterThan(Integer value) {
            addCriterion("l_loantime >", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("l_loantime >=", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeLessThan(Integer value) {
            addCriterion("l_loantime <", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeLessThanOrEqualTo(Integer value) {
            addCriterion("l_loantime <=", value, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeIn(List<Integer> values) {
            addCriterion("l_loantime in", values, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeNotIn(List<Integer> values) {
            addCriterion("l_loantime not in", values, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeBetween(Integer value1, Integer value2) {
            addCriterion("l_loantime between", value1, value2, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLLoantimeNotBetween(Integer value1, Integer value2) {
            addCriterion("l_loantime not between", value1, value2, "lLoantime");
            return (Criteria) this;
        }

        public Criteria andLIbterestIsNull() {
            addCriterion("l_ibterest is null");
            return (Criteria) this;
        }

        public Criteria andLIbterestIsNotNull() {
            addCriterion("l_ibterest is not null");
            return (Criteria) this;
        }

        public Criteria andLIbterestEqualTo(BigDecimal value) {
            addCriterion("l_ibterest =", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestNotEqualTo(BigDecimal value) {
            addCriterion("l_ibterest <>", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestGreaterThan(BigDecimal value) {
            addCriterion("l_ibterest >", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("l_ibterest >=", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestLessThan(BigDecimal value) {
            addCriterion("l_ibterest <", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestLessThanOrEqualTo(BigDecimal value) {
            addCriterion("l_ibterest <=", value, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestIn(List<BigDecimal> values) {
            addCriterion("l_ibterest in", values, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestNotIn(List<BigDecimal> values) {
            addCriterion("l_ibterest not in", values, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("l_ibterest between", value1, value2, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLIbterestNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("l_ibterest not between", value1, value2, "lIbterest");
            return (Criteria) this;
        }

        public Criteria andLLoandateIsNull() {
            addCriterion("l_loandate is null");
            return (Criteria) this;
        }

        public Criteria andLLoandateIsNotNull() {
            addCriterion("l_loandate is not null");
            return (Criteria) this;
        }

        public Criteria andLLoandateEqualTo(Date value) {
            addCriterion("l_loandate =", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateNotEqualTo(Date value) {
            addCriterion("l_loandate <>", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateGreaterThan(Date value) {
            addCriterion("l_loandate >", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateGreaterThanOrEqualTo(Date value) {
            addCriterion("l_loandate >=", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateLessThan(Date value) {
            addCriterion("l_loandate <", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateLessThanOrEqualTo(Date value) {
            addCriterion("l_loandate <=", value, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateIn(List<Date> values) {
            addCriterion("l_loandate in", values, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateNotIn(List<Date> values) {
            addCriterion("l_loandate not in", values, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateBetween(Date value1, Date value2) {
            addCriterion("l_loandate between", value1, value2, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLLoandateNotBetween(Date value1, Date value2) {
            addCriterion("l_loandate not between", value1, value2, "lLoandate");
            return (Criteria) this;
        }

        public Criteria andLStatusIsNull() {
            addCriterion("l_status is null");
            return (Criteria) this;
        }

        public Criteria andLStatusIsNotNull() {
            addCriterion("l_status is not null");
            return (Criteria) this;
        }

        public Criteria andLStatusEqualTo(Integer value) {
            addCriterion("l_status =", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusNotEqualTo(Integer value) {
            addCriterion("l_status <>", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusGreaterThan(Integer value) {
            addCriterion("l_status >", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusGreaterThanOrEqualTo(Integer value) {
            addCriterion("l_status >=", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusLessThan(Integer value) {
            addCriterion("l_status <", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusLessThanOrEqualTo(Integer value) {
            addCriterion("l_status <=", value, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusIn(List<Integer> values) {
            addCriterion("l_status in", values, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusNotIn(List<Integer> values) {
            addCriterion("l_status not in", values, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusBetween(Integer value1, Integer value2) {
            addCriterion("l_status between", value1, value2, "lStatus");
            return (Criteria) this;
        }

        public Criteria andLStatusNotBetween(Integer value1, Integer value2) {
            addCriterion("l_status not between", value1, value2, "lStatus");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}