package com.weidai.pojo;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class UserlendExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public UserlendExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andUlIdIsNull() {
            addCriterion("ul_id is null");
            return (Criteria) this;
        }

        public Criteria andUlIdIsNotNull() {
            addCriterion("ul_id is not null");
            return (Criteria) this;
        }

        public Criteria andUlIdEqualTo(Integer value) {
            addCriterion("ul_id =", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdNotEqualTo(Integer value) {
            addCriterion("ul_id <>", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdGreaterThan(Integer value) {
            addCriterion("ul_id >", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("ul_id >=", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdLessThan(Integer value) {
            addCriterion("ul_id <", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdLessThanOrEqualTo(Integer value) {
            addCriterion("ul_id <=", value, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdIn(List<Integer> values) {
            addCriterion("ul_id in", values, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdNotIn(List<Integer> values) {
            addCriterion("ul_id not in", values, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdBetween(Integer value1, Integer value2) {
            addCriterion("ul_id between", value1, value2, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlIdNotBetween(Integer value1, Integer value2) {
            addCriterion("ul_id not between", value1, value2, "ulId");
            return (Criteria) this;
        }

        public Criteria andUlUseridIsNull() {
            addCriterion("ul_userid is null");
            return (Criteria) this;
        }

        public Criteria andUlUseridIsNotNull() {
            addCriterion("ul_userid is not null");
            return (Criteria) this;
        }

        public Criteria andUlUseridEqualTo(String value) {
            addCriterion("ul_userid =", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridNotEqualTo(String value) {
            addCriterion("ul_userid <>", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridGreaterThan(String value) {
            addCriterion("ul_userid >", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridGreaterThanOrEqualTo(String value) {
            addCriterion("ul_userid >=", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridLessThan(String value) {
            addCriterion("ul_userid <", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridLessThanOrEqualTo(String value) {
            addCriterion("ul_userid <=", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridLike(String value) {
            addCriterion("ul_userid like", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridNotLike(String value) {
            addCriterion("ul_userid not like", value, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridIn(List<String> values) {
            addCriterion("ul_userid in", values, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridNotIn(List<String> values) {
            addCriterion("ul_userid not in", values, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridBetween(String value1, String value2) {
            addCriterion("ul_userid between", value1, value2, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlUseridNotBetween(String value1, String value2) {
            addCriterion("ul_userid not between", value1, value2, "ulUserid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidIsNull() {
            addCriterion("ul_biddataid is null");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidIsNotNull() {
            addCriterion("ul_biddataid is not null");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidEqualTo(Integer value) {
            addCriterion("ul_biddataid =", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidNotEqualTo(Integer value) {
            addCriterion("ul_biddataid <>", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidGreaterThan(Integer value) {
            addCriterion("ul_biddataid >", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidGreaterThanOrEqualTo(Integer value) {
            addCriterion("ul_biddataid >=", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidLessThan(Integer value) {
            addCriterion("ul_biddataid <", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidLessThanOrEqualTo(Integer value) {
            addCriterion("ul_biddataid <=", value, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidIn(List<Integer> values) {
            addCriterion("ul_biddataid in", values, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidNotIn(List<Integer> values) {
            addCriterion("ul_biddataid not in", values, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidBetween(Integer value1, Integer value2) {
            addCriterion("ul_biddataid between", value1, value2, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBiddataidNotBetween(Integer value1, Integer value2) {
            addCriterion("ul_biddataid not between", value1, value2, "ulBiddataid");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyIsNull() {
            addCriterion("ul_bidmoney is null");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyIsNotNull() {
            addCriterion("ul_bidmoney is not null");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyEqualTo(BigDecimal value) {
            addCriterion("ul_bidmoney =", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyNotEqualTo(BigDecimal value) {
            addCriterion("ul_bidmoney <>", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyGreaterThan(BigDecimal value) {
            addCriterion("ul_bidmoney >", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_bidmoney >=", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyLessThan(BigDecimal value) {
            addCriterion("ul_bidmoney <", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_bidmoney <=", value, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyIn(List<BigDecimal> values) {
            addCriterion("ul_bidmoney in", values, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyNotIn(List<BigDecimal> values) {
            addCriterion("ul_bidmoney not in", values, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_bidmoney between", value1, value2, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidmoneyNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_bidmoney not between", value1, value2, "ulBidmoney");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeIsNull() {
            addCriterion("ul_bidtime is null");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeIsNotNull() {
            addCriterion("ul_bidtime is not null");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeEqualTo(Integer value) {
            addCriterion("ul_bidtime =", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeNotEqualTo(Integer value) {
            addCriterion("ul_bidtime <>", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeGreaterThan(Integer value) {
            addCriterion("ul_bidtime >", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeGreaterThanOrEqualTo(Integer value) {
            addCriterion("ul_bidtime >=", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeLessThan(Integer value) {
            addCriterion("ul_bidtime <", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeLessThanOrEqualTo(Integer value) {
            addCriterion("ul_bidtime <=", value, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeIn(List<Integer> values) {
            addCriterion("ul_bidtime in", values, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeNotIn(List<Integer> values) {
            addCriterion("ul_bidtime not in", values, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeBetween(Integer value1, Integer value2) {
            addCriterion("ul_bidtime between", value1, value2, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlBidtimeNotBetween(Integer value1, Integer value2) {
            addCriterion("ul_bidtime not between", value1, value2, "ulBidtime");
            return (Criteria) this;
        }

        public Criteria andUlRateIsNull() {
            addCriterion("ul_rate is null");
            return (Criteria) this;
        }

        public Criteria andUlRateIsNotNull() {
            addCriterion("ul_rate is not null");
            return (Criteria) this;
        }

        public Criteria andUlRateEqualTo(BigDecimal value) {
            addCriterion("ul_rate =", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateNotEqualTo(BigDecimal value) {
            addCriterion("ul_rate <>", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateGreaterThan(BigDecimal value) {
            addCriterion("ul_rate >", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_rate >=", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateLessThan(BigDecimal value) {
            addCriterion("ul_rate <", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_rate <=", value, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateIn(List<BigDecimal> values) {
            addCriterion("ul_rate in", values, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateNotIn(List<BigDecimal> values) {
            addCriterion("ul_rate not in", values, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_rate between", value1, value2, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlRateNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_rate not between", value1, value2, "ulRate");
            return (Criteria) this;
        }

        public Criteria andUlInterestIsNull() {
            addCriterion("ul_interest is null");
            return (Criteria) this;
        }

        public Criteria andUlInterestIsNotNull() {
            addCriterion("ul_interest is not null");
            return (Criteria) this;
        }

        public Criteria andUlInterestEqualTo(BigDecimal value) {
            addCriterion("ul_interest =", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestNotEqualTo(BigDecimal value) {
            addCriterion("ul_interest <>", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestGreaterThan(BigDecimal value) {
            addCriterion("ul_interest >", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestGreaterThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_interest >=", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestLessThan(BigDecimal value) {
            addCriterion("ul_interest <", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestLessThanOrEqualTo(BigDecimal value) {
            addCriterion("ul_interest <=", value, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestIn(List<BigDecimal> values) {
            addCriterion("ul_interest in", values, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestNotIn(List<BigDecimal> values) {
            addCriterion("ul_interest not in", values, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_interest between", value1, value2, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlInterestNotBetween(BigDecimal value1, BigDecimal value2) {
            addCriterion("ul_interest not between", value1, value2, "ulInterest");
            return (Criteria) this;
        }

        public Criteria andUlBiddateIsNull() {
            addCriterion("ul_biddate is null");
            return (Criteria) this;
        }

        public Criteria andUlBiddateIsNotNull() {
            addCriterion("ul_biddate is not null");
            return (Criteria) this;
        }

        public Criteria andUlBiddateEqualTo(Date value) {
            addCriterion("ul_biddate =", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateNotEqualTo(Date value) {
            addCriterion("ul_biddate <>", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateGreaterThan(Date value) {
            addCriterion("ul_biddate >", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateGreaterThanOrEqualTo(Date value) {
            addCriterion("ul_biddate >=", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateLessThan(Date value) {
            addCriterion("ul_biddate <", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateLessThanOrEqualTo(Date value) {
            addCriterion("ul_biddate <=", value, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateIn(List<Date> values) {
            addCriterion("ul_biddate in", values, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateNotIn(List<Date> values) {
            addCriterion("ul_biddate not in", values, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateBetween(Date value1, Date value2) {
            addCriterion("ul_biddate between", value1, value2, "ulBiddate");
            return (Criteria) this;
        }

        public Criteria andUlBiddateNotBetween(Date value1, Date value2) {
            addCriterion("ul_biddate not between", value1, value2, "ulBiddate");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    /**
     * 
     * 
     * @author wcyong
     * 
     * @date 2018-06-20
     */
    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}