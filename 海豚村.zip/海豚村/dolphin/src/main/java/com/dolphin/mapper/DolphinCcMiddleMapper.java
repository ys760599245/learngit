package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCcMiddle;

public interface DolphinCcMiddleMapper {
    int insert(DolphinCcMiddle record);

    int insertSelective(DolphinCcMiddle record);
}