package com.dolphin.mapper;

import com.dolphin.pojo.DolphinSpecification;

public interface DolphinSpecificationMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinSpecification record);

    int insertSelective(DolphinSpecification record);

    DolphinSpecification selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinSpecification record);

    int updateByPrimaryKeyWithBLOBs(DolphinSpecification record);

    int updateByPrimaryKey(DolphinSpecification record);
}