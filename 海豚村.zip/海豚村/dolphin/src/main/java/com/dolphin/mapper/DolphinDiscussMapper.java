package com.dolphin.mapper;

import com.dolphin.pojo.DolphinDiscuss;

public interface DolphinDiscussMapper {
    int deleteByPrimaryKey(Long orderid);

    int insert(DolphinDiscuss record);

    int insertSelective(DolphinDiscuss record);

    DolphinDiscuss selectByPrimaryKey(Long orderid);

    int updateByPrimaryKeySelective(DolphinDiscuss record);

    int updateByPrimaryKey(DolphinDiscuss record);
}