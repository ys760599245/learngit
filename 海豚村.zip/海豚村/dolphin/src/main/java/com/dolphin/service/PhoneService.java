package com.dolphin.service;

public interface PhoneService {

	/**
	 * 短信接口
	 * @param phone
	 */
	public int getCode(String cellphone);
	
}
