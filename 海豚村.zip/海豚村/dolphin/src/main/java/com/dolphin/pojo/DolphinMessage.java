package com.dolphin.pojo;

import java.util.Date;

public class DolphinMessage {
    private Long id;

    private Long sendid;

    private String messagecontent;

    private Date sendtime;

    private String messagetitle;

    private Long recipientid;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getSendid() {
        return sendid;
    }

    public void setSendid(Long sendid) {
        this.sendid = sendid;
    }

    public String getMessagecontent() {
        return messagecontent;
    }

    public void setMessagecontent(String messagecontent) {
        this.messagecontent = messagecontent == null ? null : messagecontent.trim();
    }

    public Date getSendtime() {
        return sendtime;
    }

    public void setSendtime(Date sendtime) {
        this.sendtime = sendtime;
    }

    public String getMessagetitle() {
        return messagetitle;
    }

    public void setMessagetitle(String messagetitle) {
        this.messagetitle = messagetitle == null ? null : messagetitle.trim();
    }

    public Long getRecipientid() {
        return recipientid;
    }

    public void setRecipientid(Long recipientid) {
        this.recipientid = recipientid;
    }
}