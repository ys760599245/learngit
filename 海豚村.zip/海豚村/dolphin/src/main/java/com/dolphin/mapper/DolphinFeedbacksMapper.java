package com.dolphin.mapper;

import com.dolphin.pojo.DolphinFeedbacks;

public interface DolphinFeedbacksMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinFeedbacks record);

    int insertSelective(DolphinFeedbacks record);

    DolphinFeedbacks selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinFeedbacks record);

    int updateByPrimaryKey(DolphinFeedbacks record);
}