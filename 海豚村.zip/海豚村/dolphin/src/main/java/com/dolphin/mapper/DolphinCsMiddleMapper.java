package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCsMiddle;

public interface DolphinCsMiddleMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCsMiddle record);

    int insertSelective(DolphinCsMiddle record);

    DolphinCsMiddle selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCsMiddle record);

    int updateByPrimaryKey(DolphinCsMiddle record);
}