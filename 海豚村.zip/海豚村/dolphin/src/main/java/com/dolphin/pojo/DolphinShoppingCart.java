package com.dolphin.pojo;

public class DolphinShoppingCart {
    private Long id;

    private Long userid;

    private Double postagemoney;

    private Double commoditytotalprice;

    private Double tariffamount;

    private Double freightamout;

    private Double freightdiscounts;

    private Double activitydiscouts;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public Double getPostagemoney() {
        return postagemoney;
    }

    public void setPostagemoney(Double postagemoney) {
        this.postagemoney = postagemoney;
    }

    public Double getCommoditytotalprice() {
        return commoditytotalprice;
    }

    public void setCommoditytotalprice(Double commoditytotalprice) {
        this.commoditytotalprice = commoditytotalprice;
    }

    public Double getTariffamount() {
        return tariffamount;
    }

    public void setTariffamount(Double tariffamount) {
        this.tariffamount = tariffamount;
    }

    public Double getFreightamout() {
        return freightamout;
    }

    public void setFreightamout(Double freightamout) {
        this.freightamout = freightamout;
    }

    public Double getFreightdiscounts() {
        return freightdiscounts;
    }

    public void setFreightdiscounts(Double freightdiscounts) {
        this.freightdiscounts = freightdiscounts;
    }

    public Double getActivitydiscouts() {
        return activitydiscouts;
    }

    public void setActivitydiscouts(Double activitydiscouts) {
        this.activitydiscouts = activitydiscouts;
    }
}