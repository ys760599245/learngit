package com.dolphin.mapper;

import com.dolphin.pojo.DolphinWarehouse;

public interface DolphinWarehouseMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinWarehouse record);

    int insertSelective(DolphinWarehouse record);

    DolphinWarehouse selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinWarehouse record);

    int updateByPrimaryKey(DolphinWarehouse record);
}