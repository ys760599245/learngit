package com.dolphin.service;

import org.apache.ibatis.annotations.Param;

import com.dolphin.pojo.DolphinUser;

public interface DolphinUserService {

	public DolphinUser dologin(@Param("phone")String phone,
			                 @Param("password")String password);
	public DolphinUser seleUser(String phone);
}
