package com.dolphin.pojo;

import java.util.Date;

public class DolphinSpecification {
    private Long id;

    private String specificationname;

    private Date createdtime;

    private Long createdby;

    private Date updatetime;

    private Long updatedtime;

    private String paramdata;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSpecificationname() {
        return specificationname;
    }

    public void setSpecificationname(String specificationname) {
        this.specificationname = specificationname == null ? null : specificationname.trim();
    }

    public Date getCreatedtime() {
        return createdtime;
    }

    public void setCreatedtime(Date createdtime) {
        this.createdtime = createdtime;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getUpdatetime() {
        return updatetime;
    }

    public void setUpdatetime(Date updatetime) {
        this.updatetime = updatetime;
    }

    public Long getUpdatedtime() {
        return updatedtime;
    }

    public void setUpdatedtime(Long updatedtime) {
        this.updatedtime = updatedtime;
    }

    public String getParamdata() {
        return paramdata;
    }

    public void setParamdata(String paramdata) {
        this.paramdata = paramdata == null ? null : paramdata.trim();
    }
}