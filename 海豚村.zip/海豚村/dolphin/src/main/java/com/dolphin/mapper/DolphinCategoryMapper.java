package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCategory;

public interface DolphinCategoryMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCategory record);

    int insertSelective(DolphinCategory record);

    DolphinCategory selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCategory record);

    int updateByPrimaryKey(DolphinCategory record);
}