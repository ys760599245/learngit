package com.dolphin.mapper;

import com.dolphin.pojo.DolphinShoppingCart;

public interface DolphinShoppingCartMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinShoppingCart record);

    int insertSelective(DolphinShoppingCart record);

    DolphinShoppingCart selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinShoppingCart record);

    int updateByPrimaryKey(DolphinShoppingCart record);
}