package com.dolphin.pojo;

public class DolphinCsMiddle {
    private Long id;

    private Long categoryid;

    private Long specificationid;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCategoryid() {
        return categoryid;
    }

    public void setCategoryid(Long categoryid) {
        this.categoryid = categoryid;
    }

    public Long getSpecificationid() {
        return specificationid;
    }

    public void setSpecificationid(Long specificationid) {
        this.specificationid = specificationid;
    }
}