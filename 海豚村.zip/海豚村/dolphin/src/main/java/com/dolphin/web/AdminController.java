package com.dolphin.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ImportResource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.dolphin.pojo.DolphinUser;
import com.dolphin.service.DolphinUserService;
import com.dolphin.service.PhoneService;

@Controller
@RequestMapping("/admin")
public class AdminController {
     
	
	@Autowired
	@Qualifier("PhoneService")
	private PhoneService phoneService;
	
	@Autowired
	@Qualifier("dolphinUserService")
	private DolphinUserService dolphinUserService;

	@RequestMapping("/login.html")
	public String login() {
		return "login";
	}
	

	@RequestMapping(value = "/dologin.html", method = RequestMethod.GET)
	public String dologin(@RequestParam(value = "phone", required = false) String phone,
			@RequestParam(value = "code", required = false) String code,
			@RequestParam(value = "password", required = false) String password, HttpServletRequest request,
			HttpSession session) {
		    //调用service方法 进行用户匹配
			DolphinUser dolphinUser = dolphinUserService.dologin(phone, password);
			System.out.println(dolphinUser);
			System.out.println(phone);
			if (null != dolphinUser) {// 登录成功
				return "redirect:/admin/index.html";
			} else {
				request.setAttribute("error", "用户名或密码不正确");
				return "login";
			}
		
	}

	@ResponseBody
	@RequestMapping("/cellphone.html")
	public Object phone(@RequestParam(value="phone",required=false)  String phone,
			            HttpSession session){
			int code=phoneService.getCode(phone);
			System.out.println("这是获取的验证码======="+code);
			return code;
	}
	@ResponseBody
	@RequestMapping("/cellsphone.html")
	public boolean phones(@RequestParam(value="phone",required=false)String phone,
            HttpSession session){
		System.out.println("失去焦点"+phone);
		   DolphinUser seleUser=dolphinUserService.seleUser(phone);
		   if(seleUser!=null){
			   return true;
		   }else{
			   System.out.println(seleUser);
			   return false;
		   }
				
		
	}
	@RequestMapping("/index.html")
	public String index() {
		return "index";
	}

}
