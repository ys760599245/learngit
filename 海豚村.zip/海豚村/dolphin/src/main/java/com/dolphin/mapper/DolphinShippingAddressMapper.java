package com.dolphin.mapper;

import com.dolphin.pojo.DolphinShippingAddress;

public interface DolphinShippingAddressMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinShippingAddress record);

    int insertSelective(DolphinShippingAddress record);

    DolphinShippingAddress selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinShippingAddress record);

    int updateByPrimaryKey(DolphinShippingAddress record);
}