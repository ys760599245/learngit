package com.dolphin.mapper;

import com.dolphin.pojo.DolphinProvider;

public interface DolphinProviderMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinProvider record);

    int insertSelective(DolphinProvider record);

    DolphinProvider selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinProvider record);

    int updateByPrimaryKey(DolphinProvider record);
}