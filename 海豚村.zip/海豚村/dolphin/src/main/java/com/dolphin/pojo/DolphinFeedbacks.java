package com.dolphin.pojo;

import java.util.Date;

public class DolphinFeedbacks {
    private Long id;

    private Long userid;

    private String buyermessage;

    private String buyernick;

    private Integer status;

    private Date discusstime;

    private String discusstitle;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getBuyermessage() {
        return buyermessage;
    }

    public void setBuyermessage(String buyermessage) {
        this.buyermessage = buyermessage == null ? null : buyermessage.trim();
    }

    public String getBuyernick() {
        return buyernick;
    }

    public void setBuyernick(String buyernick) {
        this.buyernick = buyernick == null ? null : buyernick.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Date getDiscusstime() {
        return discusstime;
    }

    public void setDiscusstime(Date discusstime) {
        this.discusstime = discusstime;
    }

    public String getDiscusstitle() {
        return discusstitle;
    }

    public void setDiscusstitle(String discusstitle) {
        this.discusstitle = discusstitle == null ? null : discusstitle.trim();
    }
}