package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCategoryParam;

public interface DolphinCategoryParamMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCategoryParam record);

    int insertSelective(DolphinCategoryParam record);

    DolphinCategoryParam selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCategoryParam record);

    int updateByPrimaryKeyWithBLOBs(DolphinCategoryParam record);

    int updateByPrimaryKey(DolphinCategoryParam record);
}