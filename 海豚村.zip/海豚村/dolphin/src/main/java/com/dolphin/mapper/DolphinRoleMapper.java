package com.dolphin.mapper;

import com.dolphin.pojo.DolphinRole;

public interface DolphinRoleMapper {
    int insert(DolphinRole record);

    int insertSelective(DolphinRole record);
}