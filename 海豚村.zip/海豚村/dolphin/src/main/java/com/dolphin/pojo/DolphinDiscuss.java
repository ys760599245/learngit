package com.dolphin.pojo;

import java.util.Date;

public class DolphinDiscuss {
    private Long orderid;

    private Long userid;

    private String buyermessage;

    private String buyernick;

    private Integer buyerrate;

    private String imageurl;

    private Date discusstime;

    private String discusstitle;

    private String discusslabel;

    public Long getOrderid() {
        return orderid;
    }

    public void setOrderid(Long orderid) {
        this.orderid = orderid;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public String getBuyermessage() {
        return buyermessage;
    }

    public void setBuyermessage(String buyermessage) {
        this.buyermessage = buyermessage == null ? null : buyermessage.trim();
    }

    public String getBuyernick() {
        return buyernick;
    }

    public void setBuyernick(String buyernick) {
        this.buyernick = buyernick == null ? null : buyernick.trim();
    }

    public Integer getBuyerrate() {
        return buyerrate;
    }

    public void setBuyerrate(Integer buyerrate) {
        this.buyerrate = buyerrate;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl == null ? null : imageurl.trim();
    }

    public Date getDiscusstime() {
        return discusstime;
    }

    public void setDiscusstime(Date discusstime) {
        this.discusstime = discusstime;
    }

    public String getDiscusstitle() {
        return discusstitle;
    }

    public void setDiscusstitle(String discusstitle) {
        this.discusstitle = discusstitle == null ? null : discusstitle.trim();
    }

    public String getDiscusslabel() {
        return discusslabel;
    }

    public void setDiscusslabel(String discusslabel) {
        this.discusslabel = discusslabel == null ? null : discusslabel.trim();
    }
}