package com.dolphin.pojo;

import java.util.Date;

public class DolphinCoupon {
    private Long id;

    private Long userid;

    private Date starttime;

    private Date endtime;

    private String coupontitle;

    private Integer status;

    private Long outccategory;

    private Integer coupondiscount;

    private Integer meetconditions;

    private Integer coupontype;

    private String imageurl;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserid() {
        return userid;
    }

    public void setUserid(Long userid) {
        this.userid = userid;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public String getCoupontitle() {
        return coupontitle;
    }

    public void setCoupontitle(String coupontitle) {
        this.coupontitle = coupontitle == null ? null : coupontitle.trim();
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Long getOutccategory() {
        return outccategory;
    }

    public void setOutccategory(Long outccategory) {
        this.outccategory = outccategory;
    }

    public Integer getCoupondiscount() {
        return coupondiscount;
    }

    public void setCoupondiscount(Integer coupondiscount) {
        this.coupondiscount = coupondiscount;
    }

    public Integer getMeetconditions() {
        return meetconditions;
    }

    public void setMeetconditions(Integer meetconditions) {
        this.meetconditions = meetconditions;
    }

    public Integer getCoupontype() {
        return coupontype;
    }

    public void setCoupontype(Integer coupontype) {
        this.coupontype = coupontype;
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl == null ? null : imageurl.trim();
    }
}