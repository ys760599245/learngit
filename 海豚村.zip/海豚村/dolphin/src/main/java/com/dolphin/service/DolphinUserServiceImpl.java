package com.dolphin.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dolphin.mapper.DolphinUserMapper;
import com.dolphin.pojo.DolphinUser;

@Service("dolphinUserService")
public class DolphinUserServiceImpl implements DolphinUserService{
	 @Autowired
	 private DolphinUserMapper dolphinUserMapper;
	 
	 public DolphinUser dologin(String phone, String password) {
		DolphinUser dolphinUser = null;
		dolphinUser = dolphinUserMapper.dologin(phone,password);
		//匹配密码
		if(null!=dolphinUser){
			if(!dolphinUser.getPassword().equals(password)){	
				System.out.println(dolphinUser.getPassword());
			}
		}
		return dolphinUser;
	}

	public DolphinUser seleUser(String phone) {
		DolphinUser dolphinUser;
		dolphinUser=dolphinUserMapper.selectUser(phone);
		if(dolphinUser!=null){
			System.out.println("此号码已经被注册!");
		}else if(dolphinUser==null){
			System.out.println("此号码还未注册！");
		}
		return dolphinUser;
	}
       
}
