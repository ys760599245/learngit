package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCoupon;

public interface DolphinCouponMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCoupon record);

    int insertSelective(DolphinCoupon record);

    DolphinCoupon selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCoupon record);

    int updateByPrimaryKey(DolphinCoupon record);
}