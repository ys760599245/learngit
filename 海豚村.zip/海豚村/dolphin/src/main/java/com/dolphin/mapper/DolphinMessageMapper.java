package com.dolphin.mapper;

import com.dolphin.pojo.DolphinMessage;

public interface DolphinMessageMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinMessage record);

    int insertSelective(DolphinMessage record);

    DolphinMessage selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinMessage record);

    int updateByPrimaryKey(DolphinMessage record);
}