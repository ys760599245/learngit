package com.dolphin.mapper;

import org.apache.ibatis.annotations.Param;

import com.dolphin.pojo.DolphinUser;

public interface DolphinUserMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinUser record);

    int insertSelective(DolphinUser record);

    DolphinUser selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinUser record);

    int updateByPrimaryKey(DolphinUser record);
    //用户密码登录
	DolphinUser dologin( @Param("phone")String phone,
			             @Param("password")String password);
	//查询是否有这用户
	DolphinUser selectUser(@Param("phone")String phone);
}