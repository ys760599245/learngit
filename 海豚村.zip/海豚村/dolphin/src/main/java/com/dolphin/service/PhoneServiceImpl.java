package com.dolphin.service;

import org.springframework.stereotype.Service;

import com.dolphin.utils.sendsms;
@Service("PhoneService")
public class PhoneServiceImpl implements PhoneService{

	int code=0;
	sendsms sendsms=new sendsms();
	
	public int getCode(String cellphone) {
		if(cellphone!=null&&!cellphone.equals("")){
			code=(int)((Math.random()*9+1)*100000);
			System.out.println("PhoneServiceImpl"+code);
			System.out.println("PhoneServiceImpl"+cellphone);
			/*sendsms.getPhone(cellphone, code);*/
			return code;
		}
		return 0;
	}
}
