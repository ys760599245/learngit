package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCountry;

public interface DolphinCountryMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCountry record);

    int insertSelective(DolphinCountry record);

    DolphinCountry selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCountry record);

    int updateByPrimaryKey(DolphinCountry record);
}