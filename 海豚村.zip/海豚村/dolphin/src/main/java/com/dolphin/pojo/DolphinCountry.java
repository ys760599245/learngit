package com.dolphin.pojo;

public class DolphinCountry {
    private Long id;

    private String countryname;

    private String imageurl;

    private Integer continent;

    private String boutiqueimgurl;

    private String boutiquename;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCountryname() {
        return countryname;
    }

    public void setCountryname(String countryname) {
        this.countryname = countryname == null ? null : countryname.trim();
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl == null ? null : imageurl.trim();
    }

    public Integer getContinent() {
        return continent;
    }

    public void setContinent(Integer continent) {
        this.continent = continent;
    }

    public String getBoutiqueimgurl() {
        return boutiqueimgurl;
    }

    public void setBoutiqueimgurl(String boutiqueimgurl) {
        this.boutiqueimgurl = boutiqueimgurl == null ? null : boutiqueimgurl.trim();
    }

    public String getBoutiquename() {
        return boutiquename;
    }

    public void setBoutiquename(String boutiquename) {
        this.boutiquename = boutiquename == null ? null : boutiquename.trim();
    }
}