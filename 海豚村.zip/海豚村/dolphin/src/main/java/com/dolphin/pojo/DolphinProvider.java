package com.dolphin.pojo;

import java.util.Date;

public class DolphinProvider {
    private Long id;

    private String providername;

    private String providertitle;

    private String supplierdescription;

    private String imageurl;

    private String mainproducts;

    private Long countryid;

    private String address;

    private String providerimageurl;

    private String slogan;

    private String supplierbarcode;

    private Date createdtime;

    private Long createdby;

    private Date updatedtime;

    private Long updateby;

    private String foreignname;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getProvidername() {
        return providername;
    }

    public void setProvidername(String providername) {
        this.providername = providername == null ? null : providername.trim();
    }

    public String getProvidertitle() {
        return providertitle;
    }

    public void setProvidertitle(String providertitle) {
        this.providertitle = providertitle == null ? null : providertitle.trim();
    }

    public String getSupplierdescription() {
        return supplierdescription;
    }

    public void setSupplierdescription(String supplierdescription) {
        this.supplierdescription = supplierdescription == null ? null : supplierdescription.trim();
    }

    public String getImageurl() {
        return imageurl;
    }

    public void setImageurl(String imageurl) {
        this.imageurl = imageurl == null ? null : imageurl.trim();
    }

    public String getMainproducts() {
        return mainproducts;
    }

    public void setMainproducts(String mainproducts) {
        this.mainproducts = mainproducts == null ? null : mainproducts.trim();
    }

    public Long getCountryid() {
        return countryid;
    }

    public void setCountryid(Long countryid) {
        this.countryid = countryid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address == null ? null : address.trim();
    }

    public String getProviderimageurl() {
        return providerimageurl;
    }

    public void setProviderimageurl(String providerimageurl) {
        this.providerimageurl = providerimageurl == null ? null : providerimageurl.trim();
    }

    public String getSlogan() {
        return slogan;
    }

    public void setSlogan(String slogan) {
        this.slogan = slogan == null ? null : slogan.trim();
    }

    public String getSupplierbarcode() {
        return supplierbarcode;
    }

    public void setSupplierbarcode(String supplierbarcode) {
        this.supplierbarcode = supplierbarcode == null ? null : supplierbarcode.trim();
    }

    public Date getCreatedtime() {
        return createdtime;
    }

    public void setCreatedtime(Date createdtime) {
        this.createdtime = createdtime;
    }

    public Long getCreatedby() {
        return createdby;
    }

    public void setCreatedby(Long createdby) {
        this.createdby = createdby;
    }

    public Date getUpdatedtime() {
        return updatedtime;
    }

    public void setUpdatedtime(Date updatedtime) {
        this.updatedtime = updatedtime;
    }

    public Long getUpdateby() {
        return updateby;
    }

    public void setUpdateby(Long updateby) {
        this.updateby = updateby;
    }

    public String getForeignname() {
        return foreignname;
    }

    public void setForeignname(String foreignname) {
        this.foreignname = foreignname == null ? null : foreignname.trim();
    }
}