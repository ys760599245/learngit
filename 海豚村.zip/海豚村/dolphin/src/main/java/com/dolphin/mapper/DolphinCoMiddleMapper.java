package com.dolphin.mapper;

import com.dolphin.pojo.DolphinCoMiddle;

public interface DolphinCoMiddleMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DolphinCoMiddle record);

    int insertSelective(DolphinCoMiddle record);

    DolphinCoMiddle selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DolphinCoMiddle record);

    int updateByPrimaryKey(DolphinCoMiddle record);
}