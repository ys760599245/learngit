/*
 SlidesJS 3.0.4 http://slidesjs.com
 (c) 2013 by Nathan Searles http://nathansearles.com
 Updated: June 26th, 2013
 Apache License: http://www.apache.org/licenses/LICENSE-2.0
 */
(function () {
    (function (e, t, n) {
        var r, i, s;
        s = "slidesjs";
        i = {
            width: 940,
            height: 528,
            start: 1,
            navigation: {active: !0, effect: "slide"},
            pagination: {active: !0, effect: "slide"},
            play: {
                active: !1,
                effect: "slide",
                interval: 5e3,
                auto: !1,
                swap: !0,
                pauseOnHover: !1,
                restartDelay: 2500
            },
            effect: {slide: {speed: 500}, fade: {speed: 300, crossfade: !0}},
            callback: {
                loaded: function () {
                }, start: function () {
                }, complete: function () {
                }
            }
        };
        r = function () {
            function t(t, n) {
                this.element = t;
                this.options = e.extend(!0, {}, i, n);
                this._defaults = i;
                this._name = s;
                this.init()
            }

            return t
        }();
        r.prototype.init = function () {
            var n, r, i, s, o, u, a = this;
            n = e(this.element);
            this.data = e.data(this);
            e.data(this, "animating", !1);
            e.data(this, "total", n.children().not(".slidesjs-navigation", n).length);
            e.data(this, "current", this.options.start - 1);
            e.data(this, "vendorPrefix", this._getVendorPrefix());
            if (typeof TouchEvent != "undefined") {
                e.data(this, "touch", !0);
                this.options.effect.slide.speed = this.options.effect.slide.speed / 2
            }
            n.css({overflow: "hidden"});
            n.slidesContainer = n.children().not(".slidesjs-navigation", n).wrapAll("<div class='slidesjs-container'>", n).parent().css({
                overflow: "hidden",
                position: "relative"
            });
            e(".slidesjs-container", n).wrapInner("<div class='slidesjs-control'>", n).children();
            e(".slidesjs-control", n).css({position: "relative", left: 0});
            e(".slidesjs-control", n).children().addClass("slidesjs-slide").css({
                position: "absolute",
                top: 0,
                left: 0,
                width: "100%",
                zIndex: 0,
                display: "none",
                webkitBackfaceVisibility: "hidden"
            });
            e.each(e(".slidesjs-control", n).children(), function (t) {
                var n;
                n = e(this);
                return n.attr("slidesjs-index", t)
            });
            if (this.data.touch) {
                e(".slidesjs-control", n).on("touchstart", function (e) {
                    return a._touchstart(e)
                });
                e(".slidesjs-control", n).on("touchmove", function (e) {
                    return a._touchmove(e)
                });
                e(".slidesjs-control", n).on("touchend", function (e) {
                    return a._touchend(e)
                })
            }
            n.fadeIn(0);
            this.update();
            this.data.touch && this._setuptouch();
            e(".slidesjs-control", n).children(":eq(" + this.data.current + ")").eq(0).fadeIn(0, function () {
                return e(this).css({zIndex: 10})
            });
            if (this.options.navigation.active) {
                o = e("<a>", {
                    "class": "slidesjs-previous slidesjs-navigation",
                    href: "#",
                    title: "Previous",
                    text: "Previous"
                }).appendTo(n);
                r = e("<a>", {
                    "class": "slidesjs-next slidesjs-navigation",
                    href: "#",
                    title: "Next",
                    text: "Next"
                }).appendTo(n)
            }
            e(".slidesjs-next", n).click(function (e) {
                e.preventDefault();
                a.stop(!0);
                return a.next(a.options.navigation.effect)
            });
            e(".slidesjs-previous", n).click(function (e) {
                e.preventDefault();
                a.stop(!0);
                return a.previous(a.options.navigation.effect)
            });
            if (this.options.play.active) {
                s = e("<a>", {
                    "class": "slidesjs-play slidesjs-navigation",
                    href: "#",
                    title: "Play",
                    text: "Play"
                }).appendTo(n);
                u = e("<a>", {
                    "class": "slidesjs-stop slidesjs-navigation",
                    href: "#",
                    title: "Stop",
                    text: "Stop"
                }).appendTo(n);
                s.click(function (e) {
                    e.preventDefault();
                    return a.play(!0)
                });
                u.click(function (e) {
                    e.preventDefault();
                    return a.stop(!0)
                });
                this.options.play.swap && u.css({display: "none"})
            }
            if (this.options.pagination.active) {
                i = e("<ul>", {"class": "slidesjs-pagination"}).appendTo(n);
                e.each(new Array(this.data.total), function (t) {
                    var n, r;
                    n = e("<li>", {"class": "slidesjs-pagination-item"}).appendTo(i);
                    r = e("<a>", {href: "#", "data-slidesjs-item": t, html: t + 1}).appendTo(n);
                    return r.click(function (t) {
                        t.preventDefault();
                        a.stop(!0);
                        return a.goto(e(t.currentTarget).attr("data-slidesjs-item") * 1 + 1)
                    })
                })
            }
            e(t).bind("resize", function () {
                return a.update()
            });
            this._setActive();
            this.options.play.auto && this.play();
            return this.options.callback.loaded(this.options.start)
        };
        r.prototype._setActive = function (t) {
            var n, r;
            n = e(this.element);
            this.data = e.data(this);
            r = t > -1 ? t : this.data.current;
            e(".active", n).removeClass("active");
            return e(".slidesjs-pagination li:eq(" + r + ") a", n).addClass("active")
        };
        r.prototype.update = function () {
            var t, n, r;
            t = e(this.element);
            this.data = e.data(this);
            e(".slidesjs-control", t).children(":not(:eq(" + this.data.current + "))").css({
                display: "none",
                left: 0,
                zIndex: 0
            });
            r = t.width();
            n = this.options.height / this.options.width * r;
            this.options.width = r;
            this.options.height = n;
            return e(".slidesjs-control, .slidesjs-container", t).css({width: r, height: n})
        };
        r.prototype.next = function (t) {
            var n;
            n = e(this.element);
            this.data = e.data(this);
            e.data(this, "direction", "next");
            t === void 0 && (t = this.options.navigation.effect);
            return t === "fade" ? this._fade() : this._slide()
        };
        r.prototype.previous = function (t) {
            var n;
            n = e(this.element);
            this.data = e.data(this);
            e.data(this, "direction", "previous");
            t === void 0 && (t = this.options.navigation.effect);
            return t === "fade" ? this._fade() : this._slide()
        };
        r.prototype.goto = function (t) {
            var n, r;
            n = e(this.element);
            this.data = e.data(this);
            r === void 0 && (r = this.options.pagination.effect);
            t > this.data.total ? t = this.data.total : t < 1 && (t = 1);
            if (typeof t == "number")return r === "fade" ? this._fade(t) : this._slide(t);
            if (typeof t == "string") {
                if (t === "first")return r === "fade" ? this._fade(0) : this._slide(0);
                if (t === "last")return r === "fade" ? this._fade(this.data.total) : this._slide(this.data.total)
            }
        };
        r.prototype._setuptouch = function () {
            var t, n, r, i;
            t = e(this.element);
            this.data = e.data(this);
            i = e(".slidesjs-control", t);
            n = this.data.current + 1;
            r = this.data.current - 1;
            r < 0 && (r = this.data.total - 1);
            n > this.data.total - 1 && (n = 0);
            i.children(":eq(" + n + ")").css({display: "block", left: this.options.width});
            return i.children(":eq(" + r + ")").css({display: "block", left: -this.options.width})
        };
        r.prototype._touchstart = function (t) {
            var n, r;
            n = e(this.element);
            this.data = e.data(this);
            r = t.originalEvent.touches[0];
            this._setuptouch();
            e.data(this, "touchtimer", Number(new Date));
            e.data(this, "touchstartx", r.pageX);
            e.data(this, "touchstarty", r.pageY);
            return t.stopPropagation()
        };
        r.prototype._touchend = function (t) {
            var n, r, i, s, o, u, a, f = this;
            n = e(this.element);
            this.data = e.data(this);
            u = t.originalEvent.touches[0];
            s = e(".slidesjs-control", n);
            if (s.position().left > this.options.width * .5 || s.position().left > this.options.width * .1 && Number(new Date) - this.data.touchtimer < 250) {
                e.data(this, "direction", "previous");
                this._slide()
            } else if (s.position().left < -(this.options.width * .5) || s.position().left < -(this.options.width * .1) && Number(new Date) - this.data.touchtimer < 250) {
                e.data(this, "direction", "next");
                this._slide()
            } else {
                i = this.data.vendorPrefix;
                a = i + "Transform";
                r = i + "TransitionDuration";
                o = i + "TransitionTimingFunction";
                s[0].style[a] = "translateX(0px)";
                s[0].style[r] = this.options.effect.slide.speed * .85 + "ms"
            }
            s.on("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd", function () {
                i = f.data.vendorPrefix;
                a = i + "Transform";
                r = i + "TransitionDuration";
                o = i + "TransitionTimingFunction";
                s[0].style[a] = "";
                s[0].style[r] = "";
                return s[0].style[o] = ""
            });
            return t.stopPropagation()
        };
        r.prototype._touchmove = function (t) {
            var n, r, i, s, o;
            n = e(this.element);
            this.data = e.data(this);
            s = t.originalEvent.touches[0];
            r = this.data.vendorPrefix;
            i = e(".slidesjs-control", n);
            o = r + "Transform";
            e.data(this, "scrolling", Math.abs(s.pageX - this.data.touchstartx) < Math.abs(s.pageY - this.data.touchstarty));
            if (!this.data.animating && !this.data.scrolling) {
                t.preventDefault();
                this._setuptouch();
                i[0].style[o] = "translateX(" + (s.pageX - this.data.touchstartx) + "px)"
            }
            return t.stopPropagation()
        };
        r.prototype.play = function (t) {
            var n, r, i, s = this;
            n = e(this.element);
            this.data = e.data(this);
            if (!this.data.playInterval) {
                if (t) {
                    r = this.data.current;
                    this.data.direction = "next";
                    this.options.play.effect === "fade" ? this._fade() : this._slide()
                }
                e.data(this, "playInterval", setInterval(function () {
                    r = s.data.current;
                    s.data.direction = "next";
                    return s.options.play.effect === "fade" ? s._fade() : s._slide()
                }, this.options.play.interval));
                i = e(".slidesjs-container", n);
                if (this.options.play.pauseOnHover) {
                    i.unbind();
                    i.bind("mouseenter", function () {
                        return s.stop()
                    });
                    i.bind("mouseleave", function () {
                        return s.options.play.restartDelay ? e.data(s, "restartDelay", setTimeout(function () {
                            return s.play(!0)
                        }, s.options.play.restartDelay)) : s.play()
                    })
                }
                e.data(this, "playing", !0);
                e(".slidesjs-play", n).addClass("slidesjs-playing");
                if (this.options.play.swap) {
                    e(".slidesjs-play", n).hide();
                    return e(".slidesjs-stop", n).show()
                }
            }
        };
        r.prototype.stop = function (t) {
            var n;
            n = e(this.element);
            this.data = e.data(this);
            clearInterval(this.data.playInterval);
            this.options.play.pauseOnHover && t && e(".slidesjs-container", n).unbind();
            e.data(this, "playInterval", null);
            e.data(this, "playing", !1);
            e(".slidesjs-play", n).removeClass("slidesjs-playing");
            if (this.options.play.swap) {
                e(".slidesjs-stop", n).hide();
                return e(".slidesjs-play", n).show()
            }
        };
        r.prototype._slide = function (t) {
            var n, r, i, s, o, u, a, f, l, c, h = this;
            n = e(this.element);
            this.data = e.data(this);
            if (!this.data.animating && t !== this.data.current + 1) {
                e.data(this, "animating", !0);
                r = this.data.current;
                if (t > -1) {
                    t -= 1;
                    c = t > r ? 1 : -1;
                    i = t > r ? -this.options.width : this.options.width;
                    o = t
                } else {
                    c = this.data.direction === "next" ? 1 : -1;
                    i = this.data.direction === "next" ? -this.options.width : this.options.width;
                    o = r + c
                }
                o === -1 && (o = this.data.total - 1);
                o === this.data.total && (o = 0);
                this._setActive(o);
                a = e(".slidesjs-control", n);
                t > -1 && a.children(":not(:eq(" + r + "))").css({display: "none", left: 0, zIndex: 0});
                a.children(":eq(" + o + ")").css({display: "block", left: c * this.options.width, zIndex: 10});
                this.options.callback.start(r + 1);
                if (this.data.vendorPrefix) {
                    u = this.data.vendorPrefix;
                    l = u + "Transform";
                    s = u + "TransitionDuration";
                    f = u + "TransitionTimingFunction";
                    a[0].style[l] = "translateX(" + i + "px)";
                    a[0].style[s] = this.options.effect.slide.speed + "ms";
                    return a.on("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd", function () {
                        a[0].style[l] = "";
                        a[0].style[s] = "";
                        a.children(":eq(" + o + ")").css({left: 0});
                        a.children(":eq(" + r + ")").css({display: "none", left: 0, zIndex: 0});
                        e.data(h, "current", o);
                        e.data(h, "animating", !1);
                        a.unbind("transitionend webkitTransitionEnd oTransitionEnd otransitionend MSTransitionEnd");
                        a.children(":not(:eq(" + o + "))").css({display: "none", left: 0, zIndex: 0});
                        h.data.touch && h._setuptouch();
                        return h.options.callback.complete(o + 1)
                    })
                }
                return a.stop().animate({left: i}, this.options.effect.slide.speed, function () {
                    a.css({left: 0});
                    a.children(":eq(" + o + ")").css({left: 0});
                    return a.children(":eq(" + r + ")").css({
                        display: "none",
                        left: 0,
                        zIndex: 0
                    }, e.data(h, "current", o), e.data(h, "animating", !1), h.options.callback.complete(o + 1))
                })
            }
        };
        r.prototype._fade = function (t) {
            var n, r, i, s, o, u = this;
            n = e(this.element);
            this.data = e.data(this);
            if (!this.data.animating && t !== this.data.current + 1) {
                e.data(this, "animating", !0);
                r = this.data.current;
                if (t) {
                    t -= 1;
                    o = t > r ? 1 : -1;
                    i = t
                } else {
                    o = this.data.direction === "next" ? 1 : -1;
                    i = r + o
                }
                i === -1 && (i = this.data.total - 1);
                i === this.data.total && (i = 0);
                this._setActive(i);
                s = e(".slidesjs-control", n);
                s.children(":eq(" + i + ")").css({display: "none", left: 0, zIndex: 10});
                this.options.callback.start(r + 1);
                if (this.options.effect.fade.crossfade) {
                    s.children(":eq(" + this.data.current + ")").stop().fadeOut(this.options.effect.fade.speed);
                    return s.children(":eq(" + i + ")").stop().fadeIn(this.options.effect.fade.speed, function () {
                        s.children(":eq(" + i + ")").css({zIndex: 0});
                        e.data(u, "animating", !1);
                        e.data(u, "current", i);
                        return u.options.callback.complete(i + 1)
                    })
                }
                return s.children(":eq(" + r + ")").stop().fadeOut(this.options.effect.fade.speed, function () {
                    s.children(":eq(" + i + ")").stop().fadeIn(u.options.effect.fade.speed, function () {
                        return s.children(":eq(" + i + ")").css({zIndex: 10})
                    });
                    e.data(u, "animating", !1);
                    e.data(u, "current", i);
                    return u.options.callback.complete(i + 1)
                })
            }
        };
        r.prototype._getVendorPrefix = function () {
            var e, t, r, i, s;
            e = n.body || n.documentElement;
            r = e.style;
            i = "transition";
            s = ["Moz", "Webkit", "Khtml", "O", "ms"];
            i = i.charAt(0).toUpperCase() + i.substr(1);
            t = 0;
            while (t < s.length) {
                if (typeof r[s[t] + i] == "string")return s[t];
                t++
            }
            return !1
        };
        return e.fn[s] = function (t) {
            return this.each(function () {
                if (!e.data(this, "plugin_" + s))return e.data(this, "plugin_" + s, new r(this, t))
            })
        }
    })(jQuery, window, document)
}).call(this);
/*! Lazy Load 1.9.1 - MIT license - Copyright 2010-2013 Mika Tuupola */
!function (a, b, c, d) {
    var e = a(b);
    a.fn.lazyload = function (f) {
        function g() {
            var b = 0;
            i.each(function () {
                var c = a(this);
                if (!j.skip_invisible || c.is(":visible"))if (a.abovethetop(this, j) || a.leftofbegin(this, j)); else if (a.belowthefold(this, j) || a.rightoffold(this, j)) {
                    if (++b > j.failure_limit)return !1
                } else c.trigger("appear"), b = 0
            })
        }

        var h, i = this, j = {
            threshold: 0,
            failure_limit: 0,
            event: "scroll",
            effect: "show",
            container: b,
            data_attribute: "original",
            skip_invisible: !0,
            appear: null,
            load: null,
            placeholder: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
        };
        return f && (d !== f.failurelimit && (f.failure_limit = f.failurelimit, delete f.failurelimit), d !== f.effectspeed && (f.effect_speed = f.effectspeed, delete f.effectspeed), a.extend(j, f)), h = j.container === d || j.container === b ? e : a(j.container), 0 === j.event.indexOf("scroll") && h.bind(j.event, function () {
            return g()
        }), this.each(function () {
            var b = this, c = a(b);
            b.loaded = !1, (c.attr("src") === d || c.attr("src") === !1) && c.is("img") && c.attr("src", j.placeholder), c.one("appear", function () {
                if (!this.loaded) {
                    if (j.appear) {
                        var d = i.length;
                        j.appear.call(b, d, j)
                    }
                    a("<img />").bind("load", function () {
                        var d = c.attr("data-" + j.data_attribute);
                        c.hide(), c.is("img") ? c.attr("src", d) : c.css("background-image", "url('" + d + "')"), c[j.effect](j.effect_speed), b.loaded = !0;
                        var e = a.grep(i, function (a) {
                            return !a.loaded
                        });
                        if (i = a(e), j.load) {
                            var f = i.length;
                            j.load.call(b, f, j)
                        }
                    }).attr("src", c.attr("data-" + j.data_attribute))
                }
            }), 0 !== j.event.indexOf("scroll") && c.bind(j.event, function () {
                b.loaded || c.trigger("appear")
            })
        }), e.bind("resize", function () {
            g()
        }), /(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion) && e.bind("pageshow", function (b) {
            b.originalEvent && b.originalEvent.persisted && i.each(function () {
                a(this).trigger("appear")
            })
        }), a(c).ready(function () {
            g()
        }), this
    }, a.belowthefold = function (c, f) {
        var g;
        return g = f.container === d || f.container === b ? (b.innerHeight ? b.innerHeight : e.height()) + e.scrollTop() : a(f.container).offset().top + a(f.container).height(), g <= a(c).offset().top - f.threshold
    }, a.rightoffold = function (c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.width() + e.scrollLeft() : a(f.container).offset().left + a(f.container).width(), g <= a(c).offset().left - f.threshold
    }, a.abovethetop = function (c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.scrollTop() : a(f.container).offset().top, g >= a(c).offset().top + f.threshold + a(c).height()
    }, a.leftofbegin = function (c, f) {
        var g;
        return g = f.container === d || f.container === b ? e.scrollLeft() : a(f.container).offset().left, g >= a(c).offset().left + f.threshold + a(c).width()
    }, a.inviewport = function (b, c) {
        return !(a.rightoffold(b, c) || a.leftofbegin(b, c) || a.belowthefold(b, c) || a.abovethetop(b, c))
    }, a.extend(a.expr[":"], {
        "below-the-fold": function (b) {
            return a.belowthefold(b, {threshold: 0})
        }, "above-the-top": function (b) {
            return !a.belowthefold(b, {threshold: 0})
        }, "right-of-screen": function (b) {
            return a.rightoffold(b, {threshold: 0})
        }, "left-of-screen": function (b) {
            return !a.rightoffold(b, {threshold: 0})
        }, "in-viewport": function (b) {
            return a.inviewport(b, {threshold: 0})
        }, "above-the-fold": function (b) {
            return !a.belowthefold(b, {threshold: 0})
        }, "right-of-fold": function (b) {
            return a.rightoffold(b, {threshold: 0})
        }, "left-of-fold": function (b) {
            return !a.rightoffold(b, {threshold: 0})
        }
    })
}(jQuery, window, document);
//**************************************************************
// jQZoom allows you to realize a small magnifier window,close
// to the image or images on your web page easily.
//
// jqZoom version 2.2
// Author Doc. Ing. Renzi Marco(www.mind-projects.it)
// First Release on Dec 05 2007
// i'm looking for a job,pick me up!!!
// mail: renzi.mrc@gmail.com
//**************************************************************
!function (a) {
    a.fn.jqueryzoom = function (b) {
        var c = {xzoom: 200, yzoom: 200, offset: 10, position: "right", lens: 1, preload: 1};
        b && a.extend(c, b);
        var d = "";
        a(this).hover(function () {
            function i(a) {
                this.x = a.pageX, this.y = a.pageY
            }

            var b = a(this).offset().left, e = a(this).offset().top, f = a(this).children("img").get(0).offsetWidth, g = a(this).children("img").get(0).offsetHeight;
            d = a(this).children("img").attr("alt");
            var h = a(this).children("img").attr("jqimg");
            a(this).children("img").attr("alt", ""), 0 == a("div.zoomdiv").get().length && (a(this).after("<div class='zoomdiv'><img class='bigimg' src='" + h + "'/></div>"), a(this).append("<div class='jqZoomPup'>&nbsp;</div>")), "right" == c.position ? leftpos = b + f + c.offset + c.xzoom > screen.width ? b - c.offset - c.xzoom : b + f + c.offset : (leftpos = b - c.xzoom - c.offset, 0 > leftpos && (leftpos = b + f + c.offset)), a("div.zoomdiv").css({
                top: e,
                left: leftpos
            }), a("div.zoomdiv").width(c.xzoom), a("div.zoomdiv").height(c.yzoom), a("div.zoomdiv").show(), c.lens || a(this).css("cursor", "crosshair"), a(document.body).mousemove(function (d) {
                mouse = new i(d);
                var h = a(".bigimg").get(0).offsetWidth, j = a(".bigimg").get(0).offsetHeight, k = "x", l = "y";
                if (isNaN(l) | isNaN(k)) {
                    var l = h / f, k = j / g;
                    a("div.jqZoomPup").width(c.xzoom / l), a("div.jqZoomPup").height(c.yzoom / k), c.lens && a("div.jqZoomPup").css("visibility", "visible")
                }
                xpos = mouse.x - a("div.jqZoomPup").width() / 2 - b, ypos = mouse.y - a("div.jqZoomPup").height() / 2 - e, c.lens && (xpos = mouse.x - a("div.jqZoomPup").width() / 2 < b ? 0 : mouse.x + a("div.jqZoomPup").width() / 2 > f + b ? f - a("div.jqZoomPup").width() - 2 : xpos, ypos = mouse.y - a("div.jqZoomPup").height() / 2 < e ? 0 : mouse.y + a("div.jqZoomPup").height() / 2 > g + e ? g - a("div.jqZoomPup").height() - 2 : ypos), c.lens && a("div.jqZoomPup").css({
                    top: ypos,
                    left: xpos
                }), scrolly = ypos, a("div.zoomdiv").get(0).scrollTop = scrolly * k, scrollx = xpos, a("div.zoomdiv").get(0).scrollLeft = scrollx * l
            })
        }, function () {
            a(this).children("img").attr("alt", d), a(document.body).unbind("mousemove"), c.lens && a("div.jqZoomPup").remove(), a("div.zoomdiv").remove()
        }), count = 0, c.preload && (a("body").append("<div style='display:none;' class='jqPreload" + count + "'>haituncun</div>"), a(this).each(function () {
            var b = a(this).children("img").attr("jqimg"), c = jQuery("div.jqPreload" + count).html();
            jQuery("div.jqPreload" + count).html(c + '<img src="' + b + '">')
        }))
    }
}(jQuery);
/**
 * easyDialog v2.0
 * Url : http://stylechen.com/easydialog-v2.0.html
 * Author : chenmnkken@gmail.com
 * Date : 2011-08-30
 */
(function (j, o) {
    var d = j.document, p = d.documentElement, w = function () {
        var m = d.body, s = !-[1,], q = s && /msie 6/.test(navigator.userAgent.toLowerCase()), n = 1, t = "cache" + (+new Date + "").slice(-8), l = {}, e = function () {
        };
        e.prototype = {
            getOptions: function (a) {
                var b, c = {}, f = {
                    container: null,
                    overlay: !0,
                    drag: !0,
                    fixed: !0,
                    follow: null,
                    followX: 0,
                    followY: 0,
                    autoClose: 0,
                    lock: !1,
                    callback: null
                };
                for (b in f)c[b] = a[b] !== o ? a[b] : f[b];
                e.data("options", c);
                return c
            }, setBodyBg: function () {
                if (m.currentStyle.backgroundAttachment !==
                    "fixed")m.style.backgroundImage = "url(about:blank)", m.style.backgroundAttachment = "fixed"
            }, appendIframe: function (a) {
                a.innerHTML = '<iframe style="position:absolute;left:0;top:0;width:100%;height:100%;z-index:-1;border:0 none;filter:alpha(opacity=0)"></iframe>'
            }, setFollow: function (a, b, c, f) {
                b = typeof b === "string" ? d.getElementById(b) : b;
                a = a.style;
                a.position = "absolute";
                a.left = e.getOffset(b, "left") + c + "px";
                a.top = e.getOffset(b, "top") + f + "px"
            }, setPosition: function (a, b) {
                var c = a.style;
                c.position = q ? "absolute" : b ? "fixed" :
                    "absolute";
                b ? (q ? c.setExpression("top", 'fuckIE6=document.documentElement.scrollTop+document.documentElement.clientHeight/2+"px"') : c.top = "50%", c.left = "50%") : (q && c.removeExpression("top"), c.top = p.clientHeight / 2 + e.getScroll("top") + "px", c.left = p.clientWidth / 2 + e.getScroll("left") + "px")
            }, createOverlay: function () {
                var a = d.createElement("div"), b = a.style;
                b.cssText = "margin:0;padding:0;border:none;width:100%;height:100%;background:#333;opacity:0.6;filter:alpha(opacity=60);z-index:9999;position:fixed;top:0;left:0;";
                if (q)m.style.height = "100%", b.position = "absolute", b.setExpression("top", 'fuckIE6=document.documentElement.scrollTop+"px"');
                a.id = "overlay";
                return a
            }, createDialogBox: function () {
                var a = d.createElement("div");
                a.style.cssText = "margin:0;padding:0;border:none;z-index:10000;";
                a.id = "easyDialogBox";
                return a
            }, createDialogWrap: function (a) {
                var b = typeof a.yesFn === "function" ? '<button class="btn_highlight" id="easyDialogYesBtn">' + (typeof a.yesText === "string" ? a.yesText : "\u786e\u5b9a") + "</button>" : "", c = typeof a.noFn ===
                    "function" || a.noFn === !0 ? '<button class="btn_normal" id="easyDialogNoBtn">' + (typeof a.noText === "string" ? a.noText : "\u53d6\u6d88") + "</button>" : "", a = ['<div class="easyDialog_content">', a.header ? '<h4 class="easyDialog_title" id="easyDialogTitle"><a href="javascript:void(0)" title="\u5173\u95ed\u7a97\u53e3" class="close_btn" id="closeBtn">&times;</a>' + a.header + "</h4>" : "", '<div class="easyDialog_text">' + a.content + "</div>", b === "" && c === "" ? "" : '<div class="easyDialog_footer">' + c + b + "</div>", "</div>"].join(""),
                    b = d.getElementById("easyDialogWrapper");
                if (!b)b = d.createElement("div"), b.id = "easyDialogWrapper", b.className = "easyDialog_wrapper";
                b.innerHTML = a.replace(/<[\/]*script[\s\S]*?>/ig, "");
                return b
            }
        };
        e.data = function (a, b, c) {
            if (typeof a === "string")return b !== o && (l[a] = b), l[a]; else if (typeof a === "object")return a = a === j ? 0 : a.nodeType === 9 ? 1 : a[t] ? a[t] : a[t] = ++n, a = l[a] ? l[a] : l[a] = {}, c !== o && (a[b] = c), a[b]
        };
        e.removeData = function (a, b) {
            if (typeof a === "string")delete l[a]; else if (typeof a === "object") {
                var c = a === j ? 0 : a.nodeType ===
                9 ? 1 : a[t];
                if (c !== o) {
                    var e = function (a) {
                        for (var b in a)return !1;
                        return !0
                    }, g = function () {
                        delete l[c];
                        if (!(c <= 1))try {
                            delete a[t]
                        } catch (b) {
                            a.removeAttribute(t)
                        }
                    };
                    b ? (delete l[c][b], e(l[c]) && g()) : g()
                }
            }
        };
        e.event = {
            bind: function (a, b, c) {
                var f = e.data(a, "e" + b) || e.data(a, "e" + b, []);
                f.push(c);
                f.length === 1 && (c = this.eventHandler(a), e.data(a, b + "Handler", c), a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent && a.attachEvent("on" + b, c))
            }, unbind: function (a, b, c) {
                var f = e.data(a, "e" + b);
                if (f) {
                    if (c)for (var g = f.length - 1,
                                   d = f[g]; g >= 0; g--)d === c && f.splice(g, 1); else f = o;
                    if (!f || !f.length)c = e.data(a, b + "Handler"), a.addEventListener ? a.removeEventListener(b, c, !1) : a.attachEvent && a.detachEvent("on" + b, c), e.removeData(a, b + "Handler"), e.removeData(a, "e" + b)
                }
            }, eventHandler: function (a) {
                return function (b) {
                    for (var b = e.event.fixEvent(b || j.event), c = e.data(a, "e" + b.type), f = 0, g; g = c[f++];)g.call(a, b) === !1 && (b.preventDefault(), b.stopPropagation())
                }
            }, fixEvent: function (a) {
                if (a.target)return a;
                var b = {}, c;
                b.target = a.srcElement || document;
                b.preventDefault =
                    function () {
                        a.returnValue = !1
                    };
                b.stopPropagation = function () {
                    a.cancelBubble = !0
                };
                for (c in a)b[c] = a[c];
                return b
            }
        };
        e.capitalize = function (a) {
            var b = a.charAt(0);
            return b.toUpperCase() + a.replace(b, "")
        };
        e.getScroll = function (a) {
            a = this.capitalize(a);
            return p["scroll" + a] || m["scroll" + a]
        };
        e.getOffset = function (a, b) {
            var c = this.capitalize(b), c = p["client" + c] || m["client" + c] || 0, e = this.getScroll(b), g = a.getBoundingClientRect();
            return Math.round(g[b]) + e - c
        };
        e.drag = function (a, b) {
            var c = "getSelection"in j ? function () {
                j.getSelection().removeAllRanges()
            } :
                function () {
                    try {
                        d.selection.empty()
                    } catch (a) {
                    }
                }, f = this, g = f.event, i = !1, h = s ? a : d, k = b.style.position === "fixed", m = e.data("options").fixed;
            g.bind(a, "mousedown", function (c) {
                i = !0;
                var d = f.getScroll("top"), j = f.getScroll("left"), o = k ? 0 : j, r = k ? 0 : d;
                e.data("dragData", {
                    x: c.clientX - f.getOffset(b, "left") + (k ? j : 0),
                    y: c.clientY - f.getOffset(b, "top") + (k ? d : 0),
                    el: o,
                    et: r,
                    er: o + p.clientWidth - b.offsetWidth,
                    eb: r + p.clientHeight - b.offsetHeight
                });
                s && (q && m && b.style.removeExpression("top"), a.setCapture());
                g.bind(h, "mousemove", l);
                g.bind(h,
                    "mouseup", n);
                s && g.bind(a, "losecapture", n);
                c.stopPropagation();
                c.preventDefault()
            });
            var l = function (a) {
                if (i) {
                    c();
                    var d = e.data("dragData"), f = a.clientX - d.x, g = a.clientY - d.y, h = d.et, k = d.er, m = d.eb, d = d.el, j = b.style;
                    j.marginLeft = j.marginTop = "0px";
                    j.left = (f <= d ? d : f >= k ? k : f) + "px";
                    j.top = (g <= h ? h : g >= m ? m : g) + "px";
                    a.stopPropagation()
                }
            }, n = function (c) {
                i = !1;
                s && g.unbind(a, "losecapture", arguments.callee);
                g.unbind(h, "mousemove", l);
                g.unbind(h, "mouseup", arguments.callee);
                if (s && (a.releaseCapture(), q && m)) {
                    var d = parseInt(b.style.top) -
                        f.getScroll("top");
                    b.style.setExpression("top", "fuckIE6=document.documentElement.scrollTop+" + d + '+"px"')
                }
                c.stopPropagation()
            }
        };
        var r, u = function (a) {
            a.keyCode === 27 && v.close()
        }, v = {
            open: function (a) {
                var b = new e, c = b.getOptions(a || {}), a = e.event, f = this, g, i, h, k;
                r && (clearTimeout(r), r = o);
                if (c.overlay)g = d.getElementById("overlay"), g || (g = b.createOverlay(), m.appendChild(g), q && b.appendIframe(g)), g.style.display = "block";
                q && b.setBodyBg();
                i = d.getElementById("easyDialogBox");
                i || (i = b.createDialogBox(), m.appendChild(i));
                if (c.follow) {
                    b.setFollow(i, c.follow, c.followX, c.followY);
                    if (g)g.style.display = "none";
                    c.fixed = !1
                } else b.setPosition(i, c.fixed);
                i.style.display = "block";
                !c.follow && !c.fixed && (h = function () {
                    b.setPosition(i, !1)
                }, a.bind(j, "resize", h), e.data("resize", h));
                h = typeof c.container === "string" ? d.getElementById(c.container) : b.createDialogWrap(c.container);
                if (k = i.getElementsByTagName("*")[0]) {
                    if (k && h !== k)k.style.display = "none", m.appendChild(k), i.appendChild(h)
                } else i.appendChild(h);
                h.style.display = "block";
                k = h.offsetWidth;
                var l = h.offsetHeight;
                h.style.marginTop = h.style.marginRight = h.style.marginBottom = h.style.marginLeft = "0px";
                c.follow ? i.style.marginLeft = i.style.marginTop = "0px" : (i.style.marginLeft = "-" + k / 2 + "px", i.style.marginTop = "-" + l / 2 + "px");
                if (q && !c.overlay)i.style.width = k + "px", i.style.height = l + "px";
                h = d.getElementById("closeBtn");
                k = d.getElementById("easyDialogTitle");
                var l = d.getElementById("easyDialogYesBtn"), n = d.getElementById("easyDialogNoBtn");
                l && a.bind(l, "click", function (a) {
                    c.container.yesFn.call(f, a) !== !1 && f.close()
                });
                if (n) {
                    var p = function (a) {
                        (c.container.noFn === !0 || c.container.noFn.call(f, a) !== !1) && f.close()
                    };
                    a.bind(n, "click", p);
                    h && a.bind(h, "click", p)
                } else h && a.bind(h, "click", f.close);
                c.lock || a.bind(d, "keyup", u);
                c.autoClose && typeof c.autoClose === "number" && (r = setTimeout(f.close, c.autoClose));
                if (c.drag && k)k.style.cursor = "move", e.drag(k, i);
                e.data("dialogElements", {
                    overlay: g,
                    dialogBox: i,
                    closeBtn: h,
                    dialogTitle: k,
                    dialogYesBtn: l,
                    dialogNoBtn: n
                })
            }, close: function () {
                var a = e.data("options"), b = e.data("dialogElements"), c = e.event;
                r && (clearTimeout(r), r = o);
                if (a.overlay && b.overlay)b.overlay.style.display = "none";
                b.dialogBox.style.display = "none";
                q && b.dialogBox.style.removeExpression("top");
                b.closeBtn && c.unbind(b.closeBtn, "click");
                b.dialogTitle && c.unbind(b.dialogTitle, "mousedown");
                b.dialogYesBtn && c.unbind(b.dialogYesBtn, "click");
                b.dialogNoBtn && c.unbind(b.dialogNoBtn, "click");
                !a.follow && !a.fixed && (b = e.data("resize"), c.unbind(j, "resize", b), e.removeData("resize"));
                a.lock || c.unbind(d, "keyup", u);
                typeof a.callback === "function" && a.callback.call(v);
                e.removeData("options");
                e.removeData("dialogElements")
            }
        };
        return v
    }, n = function () {
        j.easyDialog = w()
    }, u = function () {
        if (!d.body) {
            try {
                p.doScroll("left")
            } catch (j) {
                setTimeout(u, 1);
                return
            }
            n()
        }
    };
    (function () {
        if (d.body)n(); else if (d.addEventListener)d.addEventListener("DOMContentLoaded", function () {
            d.removeEventListener("DOMContentLoaded", arguments.callee, !1);
            n()
        }, !1), j.addEventListener("load", n, !1); else if (d.attachEvent) {
            d.attachEvent("onreadystatechange", function () {
                d.readyState === "complete" && (d.detachEvent("onreadystatechange",
                    arguments.callee), n())
            });
            j.attachEvent("onload", n);
            var m = !1;
            try {
                m = j.frameElement == null
            } catch (o) {
            }
            p.doScroll && m && u()
        }
    })()
})(window, void 0);
/*! jQuery ztip by zhcexo 2014-01-17 */
!function (a) {
    function b() {
        return "tip-" + (+new Date + "").slice(-8)
    }

    function c(b, c, d) {
        return "top" == d ? a('<div class="ztip top" id="' + b + '"><span class="angle"></span><div class="tip-content">' + c + "</div></div>") : a('<div class="ztip" id="' + b + '"><span class="angle"></span><div class="tip-content">' + c + "</div></div>")
    }

    a.fn.ztip = function (d) {
        var e = {content: "", width: 0, position: "bottom"};
        return d = a.extend(e, d), this.each(function () {
            var e, f;
            a(this).data("tipId") ? (e = a("#" + a(this).data("tipId")), e.find(".tip-content").html(d.content), "top" == d.position ? e.addClass("top") : e.removeClass("top")) : (f = b(), e = c(f, d.content, d.position), a(this).data("tipId", f), a("body").append(e));
            var g, h, i, j, k, l;
            g = a(this).offset().left, h = a(this).offset().top, j = a(this).outerWidth(), l = a(this).outerHeight(), e.css("width", d.width ? d.width : "auto"), i = e.outerWidth(), k = e.outerHeight(), "top" == d.position ? e.css({
                "margin-left": -i / 2 + j / 2,
                top: h - k - 15,
                left: g
            }) : e.css({"margin-left": -i / 2 + j / 2, top: h + l + 15, left: g});
            var m;
            clearTimeout(m), e.show(), m = setTimeout(function () {
                e.hide()
            }, 5e3)
        })
    }
}(jQuery);
/*! ocean 2014-05-20 */
var h = {};
h.alert = function (a) {
    easyDialog.open({
        container: {
            header: "提示",
            content: '<div class="tip-notice-content"><p>' + a + "</p></div>",
            yesFn: function () {
            }
        }
    })
};
/*
 * jQuery.upload v1.0.2
 *
 * Copyright (c) 2010 lagos
 * Dual licensed under the MIT and GPL licenses.
 *
 * http://lagoscript.org
 */
!function (a) {
    function b(b) {
        return a.map(c(b), function (a) {
            return '<input type="hidden" name="' + a.name + '" value="' + a.value + '"/>'
        }).join("")
    }

    function c(b) {
        function c(a, b) {
            d.push({name: a, value: b})
        }

        if (a.isArray(b))return b;
        var d = [];
        return "object" == typeof b ? a.each(b, function (b) {
            a.isArray(this) ? a.each(this, function () {
                c(b, this)
            }) : c(b, a.isFunction(this) ? this() : this)
        }) : "string" == typeof b && a.each(b.split("&"), function () {
            var b = a.map(this.split("="), function (a) {
                return decodeURIComponent(a.replace(/\+/g, " "))
            });
            c(b[0], b[1])
        }), d
    }

    function d(b, c) {
        var d, f = a(b).contents().get(0);
        if (a.isXMLDoc(f) || f.XMLDocument)return f.XMLDocument || f;
        switch (d = a(f).find("body").html(), c) {
            case"xml":
                d = e(d);
                break;
            case"json":
                d = window.eval("(" + d + ")")
        }
        return d
    }

    function e(a) {
        if (window.DOMParser)return (new DOMParser).parseFromString(a, "application/xml");
        var b = new ActiveXObject("Microsoft.XMLDOM");
        return b.async = !1, b.loadXML(a), b
    }

    var f = 0;
    a.fn.upload = function (c, e, g, h) {
        var i, j, k, l = this, m = "jquery_upload" + ++f, n = a('<iframe name="' + m + '" style="position:absolute;top:-9999px" />').appendTo("body"), o = '<form target="' + m + '" method="post" enctype="multipart/form-data" />';
        return a.isFunction(e) && (h = g, g = e, e = {}), j = a("input:checkbox", this), k = a("input:checked", this), o = l.wrapAll(o).parent("form").attr("action", c), j.removeAttr("checked"), k.attr("checked", !0), i = b(e), i = i ? a(i).appendTo(o) : null, o.submit(function () {
            n.load(function () {
                var b = d(this, h), c = a("input:checked", l);
                o.after(l).remove(), j.removeAttr("checked"), c.attr("checked", !0), i && i.remove(), setTimeout(function () {
                    n.remove(), "script" === h && a.globalEval(b), g && g.call(l, b)
                }, 0)
            })
        }).submit(), this
    }
}(jQuery);
/*!
 * JavaScript Cookie v2.0.4
 * https://github.com/js-cookie/js-cookie
 *
 * Copyright 2006, 2015 Klaus Hartl & Fagner Brack
 * Released under the MIT license
 */
!function (a) {
    if ("function" == typeof define && define.amd)define(a); else if ("object" == typeof exports)module.exports = a(); else {
        var b = window.Cookies, c = window.Cookies = a();
        c.noConflict = function () {
            return window.Cookies = b, c
        }
    }
}(function () {
    function a() {
        for (var a = 0, b = {}; a < arguments.length; a++) {
            var c = arguments[a];
            for (var d in c)b[d] = c[d]
        }
        return b
    }

    function b(c) {
        function d(b, e, f) {
            var g;
            if (arguments.length > 1) {
                if (f = a({path: "/"}, d.defaults, f), "number" == typeof f.expires) {
                    var h = new Date;
                    h.setMilliseconds(h.getMilliseconds() + 864e5 * f.expires), f.expires = h
                }
                try {
                    g = JSON.stringify(e), /^[\{\[]/.test(g) && (e = g)
                } catch (i) {
                }
                return e = c.write ? c.write(e, b) : encodeURIComponent(String(e)).replace(/%(23|24|26|2B|3A|3C|3E|3D|2F|3F|40|5B|5D|5E|60|7B|7D|7C)/g, decodeURIComponent), b = encodeURIComponent(String(b)), b = b.replace(/%(23|24|26|2B|5E|60|7C)/g, decodeURIComponent), b = b.replace(/[\(\)]/g, escape), document.cookie = [b, "=", e, f.expires && "; expires=" + f.expires.toUTCString(), f.path && "; path=" + f.path, f.domain && "; domain=" + f.domain, f.secure ? "; secure" : ""].join("")
            }
            b || (g = {});
            for (var j = document.cookie ? document.cookie.split("; ") : [], k = /(%[0-9A-Z]{2})+/g, l = 0; l < j.length; l++) {
                var m = j[l].split("="), n = m[0].replace(k, decodeURIComponent), o = m.slice(1).join("=");
                '"' === o.charAt(0) && (o = o.slice(1, -1));
                try {
                    if (o = c.read ? c.read(o, n) : c(o, n) || o.replace(k, decodeURIComponent), this.json)try {
                        o = JSON.parse(o)
                    } catch (i) {
                    }
                    if (b === n) {
                        g = o;
                        break
                    }
                    b || (g[n] = o)
                } catch (i) {
                }
            }
            return g
        }

        return d.get = d.set = d, d.getJSON = function () {
            return d.apply({json: !0}, [].slice.call(arguments))
        }, d.defaults = {}, d.remove = function (b, c) {
            d(b, "", a(c, {expires: -1}))
        }, d.withConverter = b, d
    }

    return b(function () {
    })
});