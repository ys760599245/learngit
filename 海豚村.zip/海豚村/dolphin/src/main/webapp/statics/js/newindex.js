//自动完成
function autoComplete($){
    var form = $('form.auto-search');
    if(form.length === 0){return ;}
    if(!searchKey){
        searchKey = {text:'',real:''} ;
    }
    form.on('submit',function(){
       var input = this.getElementsByTagName('input')[0];
       if(input.value === searchKey.text || input.value.replace(/^\s+|\s+$/g,'') === ''){
           if(searchKey.real){
               input.value = searchKey.real;
               $(this).find('.place-holder').remove();
           }else{
               return false;
           }
       }
    }).on('click','li',function(){
        var value = this.getAttribute('title'),
        form = $(this).parents('form'),
        input = form[0].getElementsByTagName('input')[0];
        input.value = value;
        form.submit();
    });
    var timer,
        inputs = $('input:text',form).on('focus',function(){
            var value = this.value;
            if(value !== ''){
                $(this).triggerHandler('keyup');
            }
    }).on('blur',function(){

        var value = this.value;
        if(value === ''){
            placeHolder.html(searchKey.text);
        }

    }).on('keyup',function(e){
            var value = this.value,_this = this, $ul = $('div.search-autocomplete');
            if(e.keyCode === 13){
                if(value === ''){
                    this.value = searchKey.real;
                }
                if(this.value === ''){
                    return false;
                }
                $(this).parents('form').submit();
                return;
            }
            if (e.keyCode === 40) { //down arrow key
                if ($ul.hasClass('focused')) {
                    if ($ul.find('.hover').length) {
                        if ($ul.find('.hover').index() === $ul.find('li').length - 1) {
                            $ul.find('li').removeClass('hover').eq(1).addClass('hover');
                        } else {
                            $ul.find('li').eq($ul.find('.hover').index() + 1).addClass('hover').siblings('li').removeClass('hover');
                        }
                    } else {
                        $ul.find('li').eq(1).addClass('hover');
                    }
                } else {
                    $ul.addClass('focused')
                        .find('li').eq(1).addClass('hover');
                }
                $(_this).val($ul.find('.hover').attr('title'));
                setFocus(_this);
                return;
            }
            if (e.keyCode === 38) { //up arrow key
                if ($ul.hasClass('focused')) {
                    if ($ul.find('.hover').length) {
                        if ($ul.find('.hover').index() === 1) {
                            $ul.find('li').removeClass('hover').eq(-1).addClass('hover');
                        } else {
                            $ul.find('li').eq($ul.find('.hover').index() - 1).addClass('hover').siblings('li').removeClass('hover');
                        }
                    } else {
                        $ul.find('li').eq(-1).addClass('hover');
                    }
                } else {
                    $ul.addClass('focused')
                        .find('li').eq(-1).addClass('hover');
                }
                $(_this).val($ul.find('.hover').attr('title'));
                setFocus(_this);
                return;
            }
            if(value !== ''){
                var _this = this;
                if(!timer){
                    timer = setTimeout(function(){
                        var value = _this.value,vv = value.replace(/^\s+|\s+$/,''),
                            outHtml = [];
                        if(vv !== ''){
                            $.ajax({
                                type: 'get',
                                url: 'http://search.haituncun.com/v1/search/expanded?kw=' + vv + '&callback=?',
                                dataType: 'jsonp',
                                success: function (data){
                                    if(data && _this.value === value){
                                        for (var i = 0; i < data.data.length; i++) {
                                            outHtml.push('<li title="' + data.data[i] + '">' + data.data[i] + '</li>');
                                        }
                                        $(_this).siblings('div.search-autocomplete').html('<ul><li style="display:none"></li>' + outHtml.join('') + '</ul>').show();
                                        $('.search-autocomplete').removeClass('focused');
                                    }else{
                                        $(_this).siblings('div.search-autocomplete').hide();
                                    }
                                }
                            });
                        }
                        clearTimeout(timer);
                        timer = null;
                        inputs.not(_this).val(value);
                    },300)
                }
                placeHolder.html('');
            }else{
                clearTimeout(timer)
                timer = null;
                $(this).siblings('div.search-autocomplete').hide();
                placeHolder.html(searchKey.text);
                inputs.val('');
            }
        });

    $('.search-autocomplete').on('mouseover', 'li', function () {
        $('.search-autocomplete').find('li').removeClass('hover');
    });

    var text = searchKey.text,placeHolder ;
    if(inputs.val()){
        text = '';
    }else{
        text = searchKey.text;
    }
    placeHolder = $('<div class="place-holder">'+text+'</div>').insertBefore(inputs);
    form.on('click','.place-holder',function(e){
        $(this).next('input:text').select();
    });

    //光标聚焦
    function focus(sel, start, end) {
        if (sel.setSelectionRange) {
            sel.focus();
            sel.setSelectionRange(start, end);
        } else if (sel.createTextRange) {
            var range = sel.createTextRange();
            range.collapse(true);
            range.moveEnd('character', end);
            range.moveStart('character', start);
            range.select();
        }
    }

    function setFocus(sel) {
        var length = sel.value.length;
        focus(sel, length, length);
    }
}

function adSlider(){//淡出淡入轮播
    var $wrap = $(".slider-wrap");
    var $list = $wrap.find(".slider");
    var $pagination = $wrap.find(".slider-pagination");
    var $sliderBtn = $wrap.find(".btn-prev,.btn-next");
    var $btnPrev = $wrap.find(".btn-prev");
    var $btnNext= $wrap.find(".btn-next");
    var len = $list.length,curNum, preNum,time;
    var $curEle = $wrap.find(".active");
    curNum = $list.index($curEle);
    (function init(){
        $list.css({position:"absolute",top:"0",left:"0",display:"none"});
        $list.eq(0).addClass("active").css({zIndex:"10",display:"block"});
    })();
    function animateFunc(){
        $list.eq(curNum).addClass("active").fadeIn(600).css("zIndex","10");
        $pagination.find("li").removeClass("active").eq(curNum).addClass("active");
        $list.eq(preNum).removeClass("active").fadeOut(600,function(){
            $(this).css("zIndex","0")
        });
    }
    function nextEffect(){
        preNum = curNum;
        if(curNum == len-1){
            curNum = 0;
        }else{
            curNum ++;
        }
        animateFunc();
    }
    function prevEffect(){
        preNum = curNum;
        if(curNum == 0){
            curNum = len-1;
        }else{
            curNum--;
        }
        animateFunc();
    }
    var loop = setInterval(nextEffect,4000);
    $sliderBtn.hover(function(){
        clearInterval(loop);
        $btnPrev.css("marginLeft","-375px");
        $btnNext.css("marginRight","-395px");
    },function(){
        loop = setInterval(nextEffect,4000);
        $btnPrev.css("marginLeft","-415px");
        $btnNext.css("marginRight","-435px");
    });
    $(".slider-control").hover(function(){
        clearInterval(loop);
        $btnPrev.css("marginLeft","-375px");
        $btnNext.css("marginRight","-395px");
    },function(){
        $btnPrev.css("marginLeft","-415px");
        $btnNext.css("marginRight","-435px");
        loop = setInterval(nextEffect,4000);
    });
    $pagination.find("li").hover(function(){
        var _this = this;
        clearInterval(loop);
        time =setTimeout(function(){
            $list.eq(preNum).stop(true,true);
            var n = $pagination.find("li").index($(_this));
            if(curNum == n){return}
            $list.eq(curNum).stop(true,true).removeClass("active").fadeOut(600,function(){
                $(this).css("zIndex","0")
            });
            curNum = n;
            if(curNum == 0){
                preNum = len - 1;
            }else{
                preNum = curNum - 1;
            }
            animateFunc();
        },100);
    },function(){
        clearTimeout(time);
        loop = setInterval(nextEffect,4000);
    });
    $sliderBtn.on("click",function(){
        $list.eq(curNum).stop(true,true);
        $list.eq(preNum).stop(true,true);
        if($(this).hasClass("btn-prev")){
            prevEffect()
        }else{
            nextEffect()
        }
    })
}

(function($){
    $.fn.appearViewport = function(options){
        var bool = false;
        var $this = $(this);
        var $window = $(window);
        var H_win=$window.innerHeight();
        var topH = $this.offset().top;
        var H_ele = $this.height();
        var scrollH = $window.scrollTop();
        var obj = {
            doFunc:function(){}
        };
        $.extend(obj,options);
        if(topH - H_win< scrollH && scrollH < topH + H_ele){
            bool = true;
            obj.doFunc();
        }
        if(!bool){
            $window.scroll(function(){
                if(bool) return;
                scrollH = $window.scrollTop();
                if(topH - H_win< scrollH && scrollH < topH + H_ele){
                    bool = true;
                    obj.doFunc();
                }
            });
        }
    }

    //购物车顶部商品数量
    if (Cookies.get('cart_item_count') === undefined) {
        $.ajax({
            type: 'get',
            url: NEWCARTURL + '/cart/item/count?callback=?',
            dataType: 'jsonp',
            data: {
                website_id: 1
            }
        }).success(function (resJson) {
            if (resJson.status === 200) {
                $('#cartCount, #cartCountFloat').text(resJson.data.count);
            }
            Cookies.set('cart_item_count', resJson.data.count || 0, {expires: 7, path: '/'});
            
        });
    } else {
        $('#cartCount, #cartCountFloat').text(Number(Cookies.get('cart_item_count')));
    }
})(jQuery);

jQuery(function($){
    //图片懒加载
    $('img.lazy').lazyload({
        threshold: 100,
        failure_limit: 25,
        skip_invisible: false
    });
if($(".cms-home").length||$(".cms-newhome").length){
	//侧边定位
	$(document).on('click','a[href*=#]',function () {
		if (location.pathname.replace(/^\//, '') == this.pathname.replace(/^\//, '') && location.hostname == this.hostname) {
			var $target = jQuery(this.hash);
			$target = $target.length && $target || jQuery('[id=' + this.hash.slice(1) + ']');
			if ($target.length) {
				var targetOffset = $target.offset().top;
				jQuery('html,body').stop().animate({
					scrollTop: targetOffset
				}, 400);
				return false
			}
		}
	});
    //自动完成功能
    autoComplete($);
	//scroll事件
    (function(){
		var $topSearch = $(".topsearch-wrap");
		var $sideBar = $(".sidebar");
		var $list = $sideBar.find(".locate-item");
		var $section = $(".country-mall,.global-seller,.classify");
		var $window = $(window);
		var $backtop = $(".backtop");
		if($backtop){
			$(document).on("click",".backtop",function(){
				$('html, body').animate({
					scrollTop: 0
				});
				return false;
			})
		}
		function initScroll(){
			if($section.length && $sideBar.length){
				$section.each(function(index, element) {
					var box = this.getBoundingClientRect();
					var h = $(this).innerHeight();			
					if(box.top < 200 && box.top > (200-h)){
						$list.eq(index).addClass("current");
						}else{
						$list.eq(index).removeClass("current");
						}
				});
			}
			if($window.scrollTop() > 750){
				if($sideBar){
					$sideBar.slideDown('fast');
				}
				if($topSearch){
					$topSearch.slideDown();
				}	
			}else{
				if($sideBar){
					$sideBar.slideUp(100);
				}
				if($topSearch){
					$topSearch.slideUp();
				}					
			}
		}
		initScroll();
		$window.scroll(function(){
			initScroll();
		});
	})();
	//轮播
    $('.template-newlist').each(function(i,slide){
        var brandList = $(slide).find(".template-newitem");
        if(brandList.length > 1 ){
            $(slide).slidesjs({
                width: 200,
                height: 403,
                pagination:{
                    active:true
                },
                navigation:{
                    active:false
                },
                play: {
                    active: false,
                    auto: true,
                    interval: 4000,
                    swap: true,
                    pauseOnHover: true,
                    restartDelay: 2500
                }
            });
        }
    });
    //顶部广告
    (function () {
        $.ajax({
            url: 'https://app-api.haituncun.com/module/banner',
            type: 'get',
            dataType: 'jsonp',
            data: 'code=pc_top'
        }).success(function (resJson) {
            var $notice = $('.em-notice'),
                data = resJson.data,
                imgUrl, link;

            if (!data.length) {
                $notice.remove();
                return;
            }

            imgUrl = data[0].image_url;
            link = data[0].target_url;

            $notice.css('background', 'url(' + imgUrl + ') center top no-repeat')
                .find('a').attr('href', link);
        });
    })();
    (function(){
        //ad 轮播
        var address = "https://app-api.haituncun.com/module/banner";
        function jointSlider(msg){
            var str1="",str2="",str3="",className;
            var item = msg.data;
            var w = item.length*24;
            for(var i = 0; i <item.length; i++ ){
                str1 +='<div class="slider" style="background-color:#'+item[i].back_color+'">'
                    +'<div class="slider-container">'
                    +'<div class="slider-control">'
                    +'<a target="_blank" class="slider-link" href="'+item[i].target_url+'">'
                    +'<img width="770" height="420" class="slider-pic" src="'+item[i].image_url+'" >'
                    +'</a>'
                    +'</div>'
                    +'</div>'
                    +'</div>';
                if(i == 0){
                    className = "active"
                }else{
                    className = ""
                }
                str3 +='<li class="'+className+'">'
                        +'</li>';
            }
            str2 = '<ul class="slider-pagination" style="width:'+w+'"px;margin-left:-'+w/2+'px>'
                    +str3
                    +'</ul>';
            $(".focus-container .slider-wrap").prepend(str1+str2);
            adSlider();
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_banner",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointSlider)
    })();
     //全球精选
    (function(){
        var address = "https://app-api.haituncun.com/module/product";
        function jointSeller(msg) {
            var list = msg.data,str="",str1;
            for (var i = 0; i < 5; i++) {
                if(!!list[i].activity_icon ){
                    str1 ='<img class="corner-mark" src="http://assets.haituncun.com/media/activityIcon/' +list[i].activity_icon  + '"></img>';
                }else{
                    str1 ='';
                }
                str += '<li class="left">'
                    + '<a target="_blank" class="good" href="' + list[i].target_url + '">'
                    + str1
                    + '<img src="'+ list[i].image_url + '" width="170" height="170"  class="good-pic"/>'
                    + '<p class="good-summary">' + list[i].title + '</p>'
                    + '<span class="good-price"><em>' + list[i].msrp + '</em><span>' + list[i].original_price + '</span></span>'
                    + '<span class="good-sort"><i class="country flag-'+list[i].country+'"></i><span style="vertical-align: middle">'+list[i].split_order+'</span></span>'
                    + '</a>'
                    + '</li>';

            }
            $(".sales-list").html(str);
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_global",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointSeller)
    })();
    //晒单
    function billFunc(){
        var address = "/social/Share_Order/getTopComment";
        var $bill = $(".bill");
        var $billPagination = $(".bill-pagination");
        var $billCur = $billPagination.find(".bill-cur");
        $bill.find(".btn-prev").on("click",function(){
            $bill.find(".slidesjs-previous").click();
        });
        $bill.find(".btn-next").on("click",function(){
            $bill.find(".slidesjs-next").click();
        });
        function jointSingle(msg){
            if(msg.ret == 0) return false;
            var str= "";
            var item = msg.data;
            $billCur.html(1);
            $billPagination.find(".bill-sum").html(item.length);
            for(var i = 0; i < item.length; i++){
                str += '<div class="bill-item">'
                    +'<a target="_blank" class="bill-link" href="'+item[i].comment_url+'">'
                    +'<img src="'+item[i].image+'" width="240" class="bill-pic"/>'
                    +'</a>'
                    +'<span class="bill-item-title">'+item[i].title+'</span>'
                    +'<p class="bill-txt">'+item[i].content+'</p>'
                    +'</div>';
            }
            $(".bill-list").html(str).slidesjs({
                width: 240,
                height: 290,
                pagination:{
                    active:false
                },
                navigation:{
                    active:true
                },
                play: {
                    active: false,
                    auto: true,
                    interval: 4000,
                    swap: true,
                    pauseOnHover: true,
                    restartDelay: 1000
                },
                callback:{
                    complete: function (number) {
                        var n = number;
                        if(n > item.length){ n = 1;}
                        $billCur.html(n);
                    }
                }
            });
        }
        $.ajax({
            type:"post",
            url:address,
            dataType:"json"
        })
            .done(jointSingle)
    }
    //brand
    function brandFunc(){
        var address = "https://app-api.haituncun.com/module/banner";
        function jointBrand(msg){
            var $brandList = $(".brand-list");
            var str = "";
            var item = msg.data;
            for(var i = 0; i < item.length; i++){
            str += '<a target="_blank" class="brand-item" href="'+item[i].target_url+'">'
                    +'<img width="100" height="50" class="brand-logo" src="'+item[i].image_url+'"/>'
                    +'<p class="brand-txt">'
                    +'<span class="brand-name">'+item[i].title+'</span>'
                    +'<span class="brand-summary">'+item[i].sub_title+'</span>'
                    +'</p>'
                    +'</a>';
            }
            $brandList.html(str);
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_hot_brand",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointBrand)
    }
    $(".classify-container .layout").appearViewport({
         doFunc:function(){
             billFunc();
             brandFunc();
         }
    });
}
if($(".salepage").length){
//顶部轮播
    (function(){
        var address = "https://app-api.haituncun.com/module/banner";
        function jointSaleBanner(msg){
            var str1="",str2="",str3="",className;
            var item = msg.data;
            var w = item.length;
            for(var i = 0; i < item.length; i++){
                str1 +='<div class="slider" style="background-color:#'+item[i].back_color+'">'
                    +'<div class="slider-container">'
                    +'<div class="slider-control">'
                    +'<a target="_blank" class="slider-link" href="'+item[i].target_url+'">'
                    +'<img width="1920" height="420" class="slider-pic" src="'+item[i].image_url+'" >'
                    +'</a>'
                    +'</div>'
                    +'</div>'
                    +'</div>';
                if(i == 0){
                    className = "active"
                }else{
                    className = ""
                }
                str3 +='<li class="'+className+'">'
                    +'</li>';
            }
            str2 = '<ul class="slider-pagination" style="width:'+w+'"px;margin-left:-'+w/2+'px>'
                +str3
                +'</ul>';
            $(".salepage-head .slider-wrap").prepend(str1+str2);
            adSlider();
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_global_top",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointSaleBanner);
    })();
//热销榜
    (function(){
        var address = "https://app-api.haituncun.com/module/product";
        function jointSaleHot(msg){
            var item = msg.data;
            var str="",str1;
            for(var i = 0; i < item.length; i++){
                if(!!item[i].activity_icon ){
                    str1 ='<img class="icon-mark" src="http://assets.haituncun.com/media/activityIcon/' +item[i].activity_icon  + '"></img>';
                }else{
                    str1 ='';
                }
                str += '<li class="left">'
                    +'<a href="'+item[i].target_url+'" target="_blank" class="good-hot">'
                    +str1
                    +'<img src="" data-original="'+item[i].image_url+'" width="210" height="210" class="pic lazy"/>'
                    +'<span class="summary">'+item[i].title+'</span>'
                    +'<span class="sort"><i class="country flag-'+item[i].country+'"></i><em>'+item[i].split_order+'</em></span>'
                    +'<span class="price"><em class="txt-red">'+item[i].msrp+'</em>'+item[i].original_price+'</span>'
                    +'<button class="btn">立即购买</button>'
                    +'</a>'
                    +'</li>';
            }
            var all ='<h2 class="caption">'
                +'<i class="line-left"></i>'
                +'<i class="line-right"></i>'
                +'<span>今日热销榜</span>'
                +'</h2>'
                +'<ul class="good-hotlist clearfix">'
                +str
                +'</ul> ';
            $(".salepage .salepage-hot").prepend(all).slideDown();
            //图片懒加载
            $('.salepage-hot img.lazy').lazyload({
                threshold: 100,
                failure_limit: 25,
                skip_invisible: false
            });
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_global_hot",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointSaleHot);
    })();
    //更多特卖
    (function(){
        var address="https://app-api.haituncun.com/module/product";
        function jointMore(msg){
            var item = msg.data;
            var str = "",str1;
            for(var i = 0; i < item.length; i++){
                if(!!item[i].activity_icon ){
                    str1 ='<img class="icon-mark" src="http://assets.haituncun.com/media/activityIcon/' +item[i].activity_icon  + '"></img>';
                }else{
                    str1 ='';
                }
                str += '<li class="left">'
                    +'<a href="'+item[i].target_url+'" target="_blank" class="good-sale">'
                    +str1
                    +'<img src="" data-original="'+item[i].image_url+'" width="190" height="190" class="pic lazy"/>'
                    +'<div class="good-saletxt">'
                    +'<span class="summary">'+item[i].title+'</span>'
                    +'<p class="info">'+item[i].description+'</p>'
                    +'<span class="sort">'+item[i].split_order+'</span>'
                    +'<span class="price"><em class="txt-red">'+item[i].msrp+'</em>'+item[i].original_price+'</span>'
                    +'<button class="btn">马上抢购</button>'
                    +'</div>'
                    +'</a>'
                    +'</li>';
         }
            var all = '<h2 class="caption">'
                +'<i class="line-left"></i>'
                +'<i class="line-right"></i>'
                +'<span>更多热卖</span>'
                +'</h2>'
                +'<ul class="good-salelist clearfix">'
                +str
                +'</ul>';
            $(".salepage .salepage-sale").prepend(all).slideDown();
            //图片懒加载
            $('.salepage-sale img.lazy').lazyload({
                threshold: 100,
                failure_limit: 25,
                skip_invisible: false
            });
        }
        $.ajax({
            type:"get",
            url:address,
            data:"code=pc_global_sale",
            dataType:"jsonp",
            jsonp:"callback"
        })
            .done(jointMore)
    })()
}
});
jQuery(function () {
    var $ = jQuery;
    if ($('body').hasClass('cms-home') || $('body').hasClass('cms-newhome')) {
        $.ajax({
            type: 'get',
            url: ROOT_URL + 'vpop/home/ajaxshow',
            dataType: 'json',
            success: function (data) {
                if (!data.ret) {
                    return;
                } else {
                    var html = '<div class="iMask"></div>';
                    html += '<div class="iCont">' + data.content + '<a href="javascript:void(0)" class="close" title="点击关闭">关闭</a></div>';
                    $('body').append(html);

                    var iCont = $('.iCont'),
                        width = iCont.outerWidth(),
                        height = iCont.outerHeight();

                    iCont.css({
                        'margin-left': -width / 2,
                        'margin-top': -height / 2
                    });

                    $('.iCont .close').click(function (e) {
                        e.preventDefault();
                        $('.iMask, .iCont').remove();
                        $(this).unbind('click');
                    });

                    if (data.residenceTime) {
                        setTimeout(function () {
                            $('.iCont .close').trigger('click');
                        }, data.residenceTime * 1000);
                    }
                }
            }
        });
    }

    //官方微信二维码弹出
    ~function () {
        var $hook = $('.footer').find('.foot-weixin'),
            html = '<div id="foot-weixin"><img src="//assets.haituncun.com/skin/frontend/PlumTree/default/images/v5/foot-weixin.png" width="148" height="176" /></div>',
            $body = $('body');

        $hook.hover(function () {
            var $this = $(this);

            $body.append(html)
            $('#foot-weixin').css({
                position: 'absolute',
                top: $this.offset().top + 28,
                left: $this.offset().left - 15
            });
        }, function () {
            $('#foot-weixin').remove();
        });
    }();
});