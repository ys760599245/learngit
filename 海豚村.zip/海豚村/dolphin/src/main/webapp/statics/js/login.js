
var ROOT_URL = 'http://' + window.location.host + '/';
// 表单切换
var regChange = function(regForm){
	var targetForm = $('#'+regForm);
	var formList  = $(targetForm).parents('.form-box').find('form');
	formList.each(function(i){
		formList[i].reset();
	});
	$(formList).addClass('hidden');
	$(targetForm).removeClass('hidden');
	$(targetForm).find('input').each(function(i){
		$(this).parents('.htc-require').removeClass('form-error form-valid');
	});
}
// 获取图形验证码
var getCheckCode = function(formId){
	var formElement = $('#'+formId);
	var type = $(formElement).find('.J-checkcode-type').val() || 'sms';
	$.ajax({
		url: ROOT_URL+'o_customer/security/getCaptcha',
		type: 'post',
		dataType: 'json',
		data: {formId: formId, type: type},
	}).done(function(data){
		if(data.ret !== 1){
			$(formElement).find('.code-img').show().find('img').attr('src', data.url);
		}else{
			$(formElement).find('.code-img').show().find('img').attr('src', data.url);
			$(formElement).find('.J-checkcode').removeClass('htc-ignore').addClass('htc-require');
		}
	}).fail(function(){
		console.log('网络错误');
	});
}
// 获取邮件验证码
var getEmailCode = function(formId){
	var formElement = $('#'+formId),
		btnGetcode = $(formElement).find('.J-get-email-code'),
		emailElement = $(formElement).find('.J-email-input'),
		checkcodeElement = $(formElement).find('.J-checkcode-input');
	var email = $(emailElement).val(),
		checkcode = $(checkcodeElement).val();

	if(!/^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$/.test(email)){
		$(emailElement).change();
		return false;
	}
	if($(checkcodeElement).parents('.htc-require').length > 0 && checkcode === ''){
		$(checkcodeElement).change();
		return false;
	}
	$.ajax({
		url: ROOT_URL+'o_customer/security/sendEmail',
		type: 'post',
		dataType: 'json',
		data: {
			email: email,
			formId: formId,
			captcha: checkcode
		}
	}).done(function(data){
		if(data.ret !== 1){
			getCheckCode(formId);
			if(/.*验证码.*/.test(data.errMsg)){
				vform.process.errorHold(checkcodeElement, data.errMsg);
				return ;
			}
			vform.process.errorHold(emailElement, data.errMsg);
			return ;
		}else{
			$(btnGetcode).attr('disabled',true);
			//倒计时
			countdown(btnGetcode, formId);
		}
	}).fail(function(){
		console.log('网络错误');
	});
}
// 获取手机验证码
var getPhoneCode = function(formId){
	var formElement = $('#'+formId),
		btnGetcode = $(formElement).find('.J-get-phone-code'),
		phoneElement = $(formElement).find('.J-phone-input'),
		checkcodeElement = $(formElement).find('.J-checkcode-input');
	var cellphone = $(phoneElement).val(),
		checkcode = $(checkcodeElement).val();
	if(!/^1[3|4|5|7|8]\d{9}$/.test(cellphone)){
		$(phoneElement).change();
		return false;
	}
	//倒计时
	countdown(btnGetcode, formId);
	console.dir($(checkcodeElement).parents('.htc-require'));
	if($(checkcodeElement).parents('.htc-require').length > 0 && checkcode === ''){
		$(checkcodeElement).change();
		return false;
	}
	$.ajax({
		url: ROOT_URL+'o_customer/security/sendSMS',
		type: 'post',
		dataType: 'json',
		data: {
			cellphone: cellphone,
			username: username,
			formId: formId,
			captcha: checkcode
		}
	}).done(function(data){
		if(data.ret !== 1){
			getCheckCode(formId);
			if(/.*验证码.*/.test(data.errMsg)){
				vform.process.errorHold(checkcodeElement, data.errMsg);
				return;
			}
			vform.process.errorHold(phoneElement, data.errMsg);
			return ;
		}else{
			$(btnGetcode).attr('disabled',true);
			//倒计时
			countdown(btnGetcode, formId);
		}
	}).fail(function(){
		console.log('网络错误');
	});
};
// 倒计时
var countdown = function(btnGetcode, formId) {
    var time = 60;
    var timer;
    $(btnGetcode).html('倒计时'+time+'(s)').addClass(
        'btn-code-disable');
    timer = setInterval(function () {
        time--;
        $(btnGetcode).html('倒计时'+time+'(s)');
        if (time == 0) {
            clearInterval(timer);
            // getCheckCode(formId);
            $(btnGetcode).html('获取验证码').removeClass(
                'btn-code-disable');
            $(btnGetcode).removeAttr('disabled');
        }
    }, 1000);
}
// 页面倒计时跳转(time/秒)
var timeToPage = function(url, time){
	var element = $('.J-count-down'),
		time = time || 3;
	var timer = setInterval(function(){
		time--;
		$(element).html(time);
		if(time <= 0){
			location.href = url;
			clearInterval(timer);
			return true;
		}
	}, 1000)	
}

// 立即验证
$('.J-verify-now').on('click', function(){
	var $checkEle = $('[type="radio"]:checked');
	var wayV = $checkEle.val();
	
	$('.retrieve-content').hide();
	if(wayV === 'email'){
		$('#retrieve-email-form').show();
		getCheckCode('retrieve-password-auth-m');
	}else if(wayV === 'phone'){
		$('#retrieve-phone-form').show();
		getCheckCode('retrieve-password-auth-p');
	}
	
});
//tab滑动
var tabSlide = function(){
	$('.form-tab').find('.tab-a').on('click', function(){
		var offset = '',
			index = '',
			role = '';
		offset = $(this).width();
		index = $(this).data('index');
		role = $(this).data('role');
		var tx = offset*index;
		if($(this).css('transform')){
			$(this).siblings('.tab-slide').css({
				'webkitTransform': 'translateX('+tx+'px)',
				'transform': 'translateX('+tx+'px)',
			});
		}else{
			$(this).siblings('.tab-slide').css('left', tx+'px');
		}
		$('.form-box').hide();
		$('#'+role).show();
	});
}
// 密码强度
$('.J-password-strength').on('keyup', function(){
	var _self = this,
		value = '',
		strength = '',
		className = '';
	value = $(_self).val();
	if(value == ''){
		$('#password-strength').hide();
		return false;
	}
	strength = $.pwdstrength.check(value);
	if(strength <= 1){
		className = 'level-low';
	}else if(strength == 2){
		className = 'level-medium';
	}else{
		className = 'level-high';
	}
	$('#password-strength').removeClass().addClass(className).show();
});
// 获取微信图片
var getWXImg = function () {
	$url = ROOT_URL + 'union/login/getWXImg/';
	$('.ew-container').find('.wx-login').attr('src', $url);
};
// 微信登录
var wxscan = function () {
	if(!$('.ew-container').hasClass('show-scale')){
		clearTimeout(timer);
		return ;
	}
	getWXImg();
	var timer = setTimeout(function () {
	    $.ajax({
	        url: ROOT_URL + 'union/login/wxScan/',
	        type: 'get',
	        data: {t:new Date().getTime()},
	        dataType: 'json',
	        timeout: 0,
	    }).done(function(data){
	    	if (data == 0) {
                wxscan();
            } else {
                window.location.href = ROOT_URL + 'union/login/callback?code=1&state=weixin';
            }
	    }).fail(function(){
	    	wxscan();
	    });
	}, 1000);
};

// 表单UI事件
(function($){
	formUIInit = function(){
		$('.u-form').on('click', function(e){
			var target = e.target || e.srcElement;
			if(target.className === 'wx-toggle'){
				$('.ew-container').toggleClass('show-scale');
				wxscan();
			}else if(target.className === 'tab-a'){
				var offset , index , role , tx ;
				offset = $(target).width();
				index = $(target).data('index');
				role = $(target).data('role');
				tx = offset*index;
				if($(target).css('transform')){
					$(target).siblings('.tab-slide').css({
						'transform': 'translateX('+tx+'px)',
					});
				}else{
					$(target).siblings('.tab-slide').css('left', tx+'px');
				}
				$('.form-box').hide();
				$('#'+role).show();
			}
		});
		$('.u-form').on('mousedown', function(e){
			var target = e.target || e.srcElement;
			if(target.className === 'i-reset'){
				$(target).siblings('input').val('');
			}
		});
		$('.form-text').on({
			focus: function(){
				var _self = this;
				$(this).siblings('label').addClass('hidden');
				$(this).parents('.form-group').addClass('form-focus');
			},
			blur: function(e){
				var _self = this;
				$(_self).parents('.form-group').removeClass('form-focus');
				if($(_self).val() === ''){
					$(_self).siblings('label').removeClass('hidden');
					$(_self).siblings('.i-reset').hide();	
				}else{
					$(_self).siblings('label').addClass('hidden');
					$(_self).siblings('.i-reset').show();
				}
			},
			change: function(e){
				var _self = this;
				if($(_self).val() === ''){
					$(_self).siblings('label').removeClass('hidden');
					$(_self).siblings('.i-reset').hide();	
				}else{
					$(_self).siblings('label').addClass('hidden');
					$(_self).siblings('.i-reset').show();
				}
			},
			keyup: function(e){
				var _self = this;
				if($(_self).val() === ''){
					$(_self).siblings('.i-reset').hide();	
				}else{
					$(_self).siblings('.i-reset').show();
				}
			}
		});
		$('')
	}
	formUIInit();
})(jQuery);

// 表单验证
(function($){
    var formValid = function(){
		var _self = this,
			result = false;
		// 绑定Change事件
		_bindChangeEvent = function(targetElement, validator){
			for(vItem in validator){
				if(vItem !== 'compared'){
					_self.rules[vItem].call(_self, targetElement, validator[vItem]);
				}else{
					_self.rules['compared'].call(_self, targetElement, validator[vItem][0], validator[vItem][1]);
				}
			}
		};
		_bindBlurEvent = function(targetElement, validator){
			for(vItem in validator){
				if(vItem === 'compared'){
					_self.rules['compared'].call(_self, targetElement, validator[vItem][0], validator[vItem][1]);
				}
			}
		};
		_self.config = function(formTarget, options){
			var formElement = $('#'+formTarget)[0];
			$.each(options, function(item){
				(function(item){
					var timer = '';
					if($(formElement).find('#'+item).length < 1){
						return ;
					}
					var childElement = $(formElement).find('#'+item);
					if(typeof options[item].required === 'string'){
						$(childElement).data('required', true);
						$(childElement).data('required-msg', options[item].required);
					}
					// 输入框值改变进行验证
					$(childElement).on('change', function(e, s){
						// 表单不需验证时直接返回
						if($(this).parents('.htc-require').length < 1){
							return true;
						}
						// 绑定验证器
						_bindChangeEvent(childElement, options[item]);

					});
					// 输入框值失去焦点进行验证
					$(childElement).on('blur', function(e, s){
						// 表单不需验证时直接返回
						if($(this).parents('.htc-require').length < 1){
							return true;
						}
						// 绑定验证器
						_bindBlurEvent(childElement, options[item]);

					});
					
				})(item);
			});
			
		};
		// 表单提交验证
		_self.valid= function(formTarget, callback){

			var formElement = $('#'+formTarget)[0];
			var elementList = $(formElement).find('.htc-require input');

			for(var i=0; i<elementList.length; i++){
				
				if($(elementList[i]).data('required') == true && $(elementList[i]).val() == ''){
					_self.rules.required.call(_self, $(elementList[i]), $(elementList[i]).data('required-msg'));
					$(elementList[i]).data('htc-valid', false);
					result = false;
					return result;
				}else if($(elementList[i]).data('htc-valid') == false){
					result = false;
					return result;
				}
			}
			result = true;
			return result;
		} ;
    }
    // 验证器
    formValid.prototype = {
    	// 验证规则
		rules : {
			required: function(element, errorMsg){
				var value = element.val(),
					self = this;
					
				if(value === '' || ($(element).is(':checkbox') && !$(element).is(':checked'))){
					$(element).data('htc-valid',false);
					return self.process.errorHold.call(self, element, errorMsg);
				}
				$(element).data('htc-valid', true);
				self.process.validateHold(element);
			},
			phone: function(element, errorMsg){
				var value = element.val(),
					self = this;
				if(value === ''){
					return ;
				}else if(value !== '' && !/^1[3|4|5|7|8]\d{9}$/.test(value)){
					$(element).data('htc-valid',false);
					return self.process.errorHold.call(self, element, errorMsg);
				}
				$(".phone").show();
				$(element).data('htc-valid',true);
				return self.process.validateHold.call(self, element);
			},
			email: function(element, errorMsg){
				var value = element.val(),
					self = this;
				if(value === ''){
					return ;
				}
				$(element).data('htc-valid', true);
				return self.process.validateHold.call(self, element);
			},
			password: function(element, errorMsg){
				var value = element.val(),
					self = this;
				if(value === ''){
					return ;
				}else if(value.length < 6 || value.length > 16){
					$(element).data('htc-valid', false);
					return self.process.errorHold.call(self, element, errorMsg);
				}
				$(element).data('htc-valid', true);
				return self.process.validateHold.call(self, element);
			},
			compared: function(element, compareId, errorMsg){
				var value = element.val(),
					self = this;
				if(value === ''){
					return ;
				}else if(value !== $('#'+compareId).val()){
					$(element).data('htc-valid', false);
					return self.process.errorHold.call(self, element, errorMsg);
				}
				$(element).data('htc-valid', true);
				return self.process.validateHold.call(self, element);
			},
			choose: function(element){
				if(!$(element).is(':checkbox')){
					return ;
				}
				if(!$(element).is(':checked')){
					$(element).parents('form').find('[type="submit"]').addClass('btn-disable').attr('disabled',true);
				}else{
					$(element).parents('form').find('[type="submit"]').removeClass('btn-disable').attr('disabled',false);
				}
			},
			remote: function(element, callback){
				var value = element.val();
				var self = this;
				if(value === ''){
					return false;
				}
				if(typeof callback == 'function'){
					callback();
				}
			}
		},
		// 处理验证结果
		process:{
			// 验证出错
			errorHold: function(element, msg){
				element.parents('.htc-require').removeClass('form-valid').addClass('form-error').find('.error').html('<i class="i-error"></i>'+msg);
				element.parents('form').find('.form-alert .error').hide();
				return false;
			},
			// 验证通过
			validateHold: function(element){
				element.parents('.htc-require').removeClass('form-error').addClass('form-valid');
				return true;
			},
			// 表单提交错误提示
			formErrorHold: function(formElement, errMsg){
				$(formElement).find('.form-alert .error').html('<i class="i-error"></i>'+errMsg).show();
			}
		},
		// 加入到验证条件中
		join: function(targetElement){
			$(targetElement).removeClass('htc-ignore').addClass('htc-require');
		},
    }
	vform = new formValid()    

})(jQuery);
// 密码强度
(function ($) {
    /*
     * 0-1弱
     * 2中
     * 3-4强
     */

    var pwdstrength = function () { }

    pwdstrength.prototype = {
        constructor: pwdstrength,
        //Unicode 编码区分数字，字母，特殊字符
        CharMode: function (iN) {
            if (iN >= 48 && iN <= 57) //数字（U+0030 - U+0039）
                return 1; //二进制是0001
            if (iN >= 65 && iN <= 90) //大写字母（U+0041 - U+005A）
                return 2; //二进制是0010
            if (iN >= 97 && iN <= 122) //小写字母（U+0061 - U+007A）
                return 4; //二进制是0100
            else //其他算特殊字符
                return 8; //二进制是1000
        },
        bitTotal: function (num) {
            modes = 0;
            for (i = 0; i < 4; i++) {
                if (num & 1) //num不是0的话
                    modes++; //复杂度+1
                num >>>= 1; //num右移1位
            }
            return modes;
        },
        check: function (sPW) {
            if (sPW.length < 8) //小于7位，直接“弱”
                return 0;
            Modes = 0;
            for (i = 0; i < sPW.length; i++) { //密码的每一位执行“位运算 OR”
                Modes |= this.CharMode(sPW.charCodeAt(i));
            }
            return this.bitTotal(Modes);
        }
    }

    if (typeof $.pwdstrength == 'undefined' || $.pwdstrength == null) {
        $.pwdstrength = new pwdstrength();
    }
})(jQuery)

// 验证手机号callback (正确:显示获取手机验证码按钮)
var validPhoneCallback = function(targetId){

	var targetElement = $('#'+targetId);
	var formElement = $(targetElement).parents('form')[0];

	if(!$(targetElement).data('htc-valid')){
		return false;
	}

	var phoneNumber = $(targetElement).val();

	$.ajax({
		url: ROOT_URL+'customer/account/loginUserExist',
		dataType: 'json',
		data: {account: phoneNumber},
		type: 'post',
		beforeSend: function(jqXHR){
			formElement.jqXHR && formElement.jqXHR.abort();
			formElement.jqXHR = jqXHR;
		},
	}).done(function(data){
		if(data.ret === 1){
			vform.join($(formElement).find('.J-phonecode'));
			vform.join($(formElement).find('.J-checkcode'));
			$(targetElement).data('htc-valid', true);
		}else{
			vform.process.errorHold(targetElement, data.errMsg);
			$(targetElement).data('htc-valid', false);
		}
	}).fail(function(){
		console.log('网络错误');
	}).always(function(){
		formElement.jqXHR = '';
	});
};
// 验证账号不存在callback (账号不存为真)
var validAccountNoExistCallback = function(targetId){
	var targetElement = $('#'+targetId);
	var formElement = $(targetElement).parents('form')[0];

	if(!$(targetElement).data('htc-valid')){
		return false;
	}
	var accountNumber = $(targetElement).val();
	$.ajax({
		url: ROOT_URL+'customer/account/loginUserExist',
		dataType: 'json',
		data: {account: accountNumber},
		type: 'post',
		beforeSend: function(jqXHR){
			formElement.jqXHR && formElement.jqXHR.abort();
			formElement.jqXHR = jqXHR;
		},
	}).done(function(data){
		if(data.ret !== 1){
			vform.process.errorHold(targetElement, data.errMsg);
			$(targetElement).data('htc-valid', false);
		}else{
			$(targetElement).data('htc-valid', true);
		}
		
	}).fail(function(){
		console.log('网络错误');
	}).always(function(){
		formElement.jqXHR = '';
	});
};
// 验证账号存在callback （账号存在通过）
var validAccountExistCallback = function(targetId){
	var targetElement = $('#'+targetId);
	var formElement = $(targetElement).parents('form')[0];

	if(!$(targetElement).data('htc-valid')){
		return false;
	}
	var accountNumber = $(targetElement).val();
	$.ajax({
		url: ROOT_URL+'customer/account/loginUserExist',
		dataType: 'json',
		data: {account: accountNumber},
		type: 'post',
		beforeSend: function(jqXHR){
			formElement.jqXHR && formElement.jqXHR.abort();
			formElement.jqXHR = jqXHR;
		},
	}).done(function(data){
		if(data.ret === 1){
			vform.process.errorHold(targetElement, '账号不存在');
			$(targetElement).data('htc-valid', false);
		}else{
			$(targetElement).data('htc-valid', true);
		}
	}).fail(function(){
		console.log('网络错误');
	}).always(function(){
		formElement.jqXHR = '';
	});
}
// 页面表单验证条件
formElementValidator = new function(){
	// 登录表单验证
	this.login = function(){
		getCheckCode('login-form');
		vform.config('login-form', {
    		username: {
    			required: '请输入账号',
    			remote: function(){
    				validAccountExistCallback('username');
    			}
    		},
    		password: {
    			required: '请输入密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		captcha: {
    			required: '请输入图形验证码',
    		},
    	});
	};
	// 手机注册表单验证
	this.regByPhone = function(){
		var checkXhr = '';
		getCheckCode('phone-reg-form');
		vform.config('phone-reg-form', {
    		cellphone: {
    			required: '请输入手机号码',
    			phone: '请输入正确的手机号',
    			remote: function(){
						validPhoneCallback('cellphone');
    				}
    		},
    		pPassword: {
    			required: '请设置密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		pRepassword: {
    			required: '请设置确认密码',
    			compared: ['pPassword', '两次密码输入不一致']
    		},
    		pCaptcha: {
    			required: '请输入图形验证码',
    		},
    		pCode: {
    			required: '请输入短信验证码'
    		},
    		pAgree: {
    			choose: '请阅读协议'
    		}
    	});
	};
	// 邮箱注册表单验证
	this.regByEmail = function(){
		var checkXhr='';
		getCheckCode('email-reg-form');
		vform.config('email-reg-form', {
    		email: {
    			required: '请输入邮箱',
    			email: '邮箱格式错误',
    			remote: function(){
    				validAccountNoExistCallback('email');
    			}
    		},
    		ePassword: {
    			required: '请设置密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		eRepassword: {
    			required: '请设置确认密码',
    			compared: ['ePassword', '两次密码输入不一致']
    		},
    		eCellphone: {
    			required: '请输入手机号码',
    			phone: '请输入正确的手机号',
    			remote: function(){
    				validPhoneCallback('eCellphone');
    			}
    		},
    		eCaptcha: {
    			required: '请输入图形验证码'
    		},
    		eCode: {
    			required: '请输入短信验证码'
    		},
    		eAgree: {
    			choose: '请阅读协议'
    		}
    	});
	};
	// 绑定手机表单验证
	this.bindPhone = function(){
		getCheckCode('bind-phone');
		vform.config('bind-phone', {
    		phone: {
    			required: '请输入手机号码',
    			phone: '请输入正确的手机号',
    			remote: function(){
    					validPhoneCallback('phone');
    			}
    		},
    		password: {
    			required: '请设置密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		repassword: {
    			required: '请设置确认密码',
    			compared: ['password', '两次密码输入不一致']
    		},
    		phonecode: {
    			required: '请输入短信验证码',
    		},
    		checkcode: {
    			required: '请输入图形验证码',
    		},
    		agree: {
    			choose: '请阅读协议',
    		}
    	});
	};
	// 绑定账号表单验证
	this.bindAccount = function(){
		getCheckCode('bind-account-form');
		vform.config('bind-account-form', {
    		account: {
    			required: '请输入账号',
    			remote: function(){
    				validAccountExistCallback('account');
    			}
    		},
    		password: {
    			required: '请输入密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		checkcode: {
    			required: '请输入图形验证码'
    		}
    	});
	};
	// 找回密码密码申请表单验证
	this.retrievePasswordSub = function(){
		getCheckCode('retrieve-password');
		vform.config('retrieve-password', {
    		account: {
    			required: '请输入您的绑定手机或邮箱'	
    		},
    		checkcode: {
    			required: '请输入验证码'
    		}
    	});
	};
	// 找回密码验证账号表单
	this.retrievePasswordAuth = function(){
		vform.config('retrieve-password-auth-p', {
    		pCode: {
    			required: '请输入短信验证码'	
    		},
    		
    		captcha: {
    			required: '请输入验证码'
    		}
    	});
    	vform.config('retrieve-password-auth-m', {
    		eCode: {
    			required: '请输入邮件验证码'	
    		},
    		captcha: {
    			required: '请输入验证码'
    		}
    	});
	};
	// 重置密码表单验证
	this.retrievePasswordReset = function(){
		vform.config('retrieve-password', {
    		password: {
    			required: '请输入密码',
    			password: '6-16个数字、字母或符号区分大小写'	
    		},
    		rePassword: {
    			required: '请输入确认密码',
    			compared: ['password', '两次密码输入不一致']
    		}
    	});
	};
	// 修改密码表单验证
	this.changePassword = function(){
		getCheckCode('change-password');
		vform.config('change-password', {
    		eCode: {
    			required: '请输入邮箱验证码'	
    		},
    		pCode: {
    			required: '请输入短信验证码',
    		},
    		checkcode: {
    			required: '请输入验证码',
    		}
    	});
	};
	// 设置新密码表单验证
	this.setNewPassword = function(){
		vform.config('reset-password-form', {
    		password: {
    			required: '请输入新密码',
    			password: '6-16个数字、字母或符号区分大小写'
    		},
    		repassword: {
    			required: '请输入确认密码',
    			compared: ['password', '密码不一致']
    		}
    	});
	};
	// 修改绑定手机申请表单验证
	this.changeBindPhone = function(){
		getCheckCode('u-cellphone-auth');
		vform.config('u-cellphone-auth', {
    		pCode: {
    			required: '请输入短信验证码'
    		},
    		eCode: {
    			required: '请输入邮件验证码'
    		},
    		checkcode: {
    			required: '请输入验证码'
    		}
    	});
	};
	// 修改绑定邮箱申请表单验证
	this.changeBindEmail = function(){
		getCheckCode('u-email-auth');
		vform.config('u-email-auth', {
    		eCode: {
    			required: '请输入邮件验证码'
    		},
    		pCode: {
    			required: '请输入短信验证码'
    		},
    		checkcode: {
    			required: '请输入验证码'
    		}
    	});
	};

	// 修改绑定邮箱申请表单验证
	this.authEmail = function(){
		getCheckCode('email-auth');
		vform.config('email-auth', {
    		eCode: {
    			required: '请输入邮件验证码'
    		},
    		pCode: {
    			required: '请输入短信验证码'
    		},
    		checkcode: {
    			required: '请输入验证码'
    		}
    	});
	};

	// 更新绑定手机表单验证
	this.updateBindPhone = function(){
		getCheckCode('reset-cellphone-form');
		vform.config('reset-cellphone-form', {
    		cellphone: {
    			required: '请输入验证手机',
    			phone: '请输入正确的手机',
    			remote: function(){
	    				validAccountNoExistCallback('cellphone');
	    			}
    		},
    		code: {
    			required: '请输入短信验证码'
    		},
    		checkcode: {
    			required: '请输入验证码',
    		}
    	});
	};
	// 更新绑定邮箱表单验证
	this.updateBindEmail = function(){
		getCheckCode('reset-email-form');
		vform.config('reset-email-form', {
    		email: {
    			required: '请输入验证邮箱',
    			email: '请输入正确的邮箱',
    			remote: function(){
    					validAccountNoExistCallback('email');
    				}
    		},
    		code: {
    			required: '请输入邮箱验证码'
    		},
    		checkcode: {
    			required: '请输入验证码',
    		}
    	});
	}
	// 安全认证表单验证(弹框)
	this.safetyVerify = function(){
		vform.config('safety-verify-form', {
    		bCellphone: {
    			required: '请输入手机号码',
    			phone: '请输入正确的手机号码',
    			remote: function(){
		    				validAccountNoExistCallback('bCellphone');
		    			}
    		},
    		bCaptcha: {
    			required: '请输入验证码',
    		},
    		bCode: {
    			required: '请输入短信验证码',	
    		},
    	});
	}

}
// 页面表单提交事件
formSubmitEvent = new function(){

	// 登录表单提交
	this.login= function(){
		
		var formElement = $('#login-form')[0];

		var formSubmit = function(){
			var _self = this;
			var pData = $(formElement).serialize();
			var checkXhr = '';
			$.ajax({
				url: ROOT_URL+'customer/account/loginPost',
				type: 'post',
				dataType: 'json',
				data: pData,
				beforeSend: function(jqXHR){
					checkXhr && checkXhr.abort();
					checkXhr = jqXHR;
					$(_self).attr('disabled', true);
				}
			}).done(function(data){
				if(data.ret !== 1){
					getCheckCode('login-form');
					if(sa_enabled && typeof indexSensors !== "undefined") {//神策登录信息埋点
				        indexSensors.login('union', [data.errMsg]);
				    }
					if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#captcha'), data.errMsg);
						return ;
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = data.url;
				}
			}).fail(function(){
				console.log('网络错误');
			}).always(function(){
				var timer = setTimeout(function(){
					$(_self).attr('disabled', false);
					clearTimeout(timer);
				}, 1500);
			});
		}

		$('#login-btn').on('click', function(e){

			var _self = this;
			e.preventDefault();
			
			if(!vform.valid('login-form')){
				$(".input-tip .error:visible").each(function() {
				  if ($(this).text()) {
				    if(sa_enabled && typeof indexSensors !== "undefined") {//神策登录信息埋点
				        indexSensors.login('union', [$(this).text()]);
				    }
				  }
				})
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret !== 1){
						formSubmit.call(_self);
					}
				});
				
			}else{
				formSubmit.call(_self);
			}

		});
	};
	// 手机注册表单提交
	this.regByPhone = function(){

		var formElement = $('#phone-reg-form')[0];
		var formSubmit = function(){
			var checkXhr = '',
				_self = this;

			if(vform.valid('phone-reg-form')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'customer/account/createPhonePost',
					type:'POST',
					data: pData,
					dataType: 'json',
					beforeSend: function(jqXHR){
						checkXhr && checkXhr.abort();
						checkXhr = jqXHR;
						$(_self).attr('disabled', true);
					}
				}).done(function(data){
					if(data.ret !== 1){
						getCheckCode('phone-reg-form');
						if(sa_enabled && typeof indexSensors !== "undefined") {//神策注册信息埋点
					        indexSensors.register('union', [data.errMsg]);
					    }
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCaptcha'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
						
					}else{
						location.href = data.url;
					}
				}).fail(function(){
					console.log('网络错误');
				}).always(function(){
					var timer = setTimeout(function(){
						$(_self).attr('disabled', false);
						clearTimeout(timer);
					}, 1500);
				});
			}
		}

		$('#reg-by-phone').on('click', function(e){
			var _self = this;
			e.preventDefault();
			$('#pRepassword').trigger('change');
			if(!vform.valid('phone-reg-form')){
				$(".input-tip .error:visible").each(function() {
				  if ($(this).text()) {
				    if(sa_enabled && typeof indexSensors !== "undefined") {//神策注册信息埋点
				        indexSensors.register('union', [$(this).text()]);
				    }
				  }
				})
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
				
			}else{
				formSubmit.call(_self);
			}
		});
	};
	// 邮箱注册表单提交
	this.regByEmail = function(){

		var formElement = $('#email-reg-form')[0];

		var formSubmit = function(){
			var checkXhr = '',
				_self = this;

			if(vform.valid('email-reg-form')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'customer/account/createAjaxPost',
					type:'POST',
					data: pData,
					dataType: 'json',
					beforeSend: function(jqXHR){
						checkXhr && checkXhr.abort();
						checkXhr = jqXHR;
						$(_self).attr('disabled', true);
					}
				}).done(function(data){
					if(data.ret !== 1){
						getCheckCode('email-reg-form');
						if(sa_enabled && typeof indexSensors !== "undefined") {//神策注册信息埋点
					        indexSensors.register('union', [data.errMsg]);
					    }
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCaptcha'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = data.url;
					}
				}).fail(function(){
					console.log('网络错误');
				}).always(function(){
					var timer = setTimeout(function(){
						$(_self).attr('disabled', false);
						clearTimeout(timer);
					}, 1500);
				});
			}else{
				$(".input-tip .error:visible").each(function() {
				  if ($(this).text()) {
				    if(sa_enabled && typeof indexSensors !== "undefined") {//神策注册信息埋点
				        indexSensors.register('union', [$(this).text()]);
				    }
				  }
				})
			}
		}

		$('#reg-by-email').on('click', function(e){
			var _self = this;
			e.preventDefault();
			
			$('#eRepassword').trigger('change');
			if(!vform.valid('reg-by-email')){
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	};
	// 绑定手机表单提交
	this.bindPhone =function(){

		var formElement = $('#bind-phone')[0];
		var formSubmit = function(){
			var checkXhr = '',
				_self = this;
			var pData = $(formElement).serialize();
			$.ajax({
				url: ROOT_URL+'union/binding/bindNewCellPhone',
				type: 'post',
				dataType: 'json',
				data: pData,
				beforeSend: function(jqXHR){
					checkXhr && checkXhr.abort();
					checkXhr = jqXHR;
					$(_self).attr('disabled', true);
				}
			}).done(function(data){
				if(data.ret !== 1){
					getCheckCode('bind-phone');
					if(/.*手机验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#phonecode'), data.errMsg);
					}else if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#checkcode'), data.errMsg);
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = data.url;
				}
			}).fail(function(){
				console.log('网络错误');
			}).always(function(){
				var timer = setTimeout(function(){
					$(_self).attr('disabled', false);
					clearTimeout(timer);
				}, 1500);
			});	
		};
		$('#go-login').on('click', function(e){
			
			var _self = this;
			e.preventDefault();
			
			$('#repassword').trigger('change');
			if(!vform.valid('bind-phone')){
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	};
	// 绑定账号表单提交
	this.bindAccount = function(){
		var formElement = $('#bind-account-form')[0];
		var formSubmit = function(){
			var pData = $(formElement).serialize();
			$.ajax({
				url: ROOT_URL+'union/binding/bindAccount',
				type: 'post',
				dataType: 'json',
				data: pData
			}).done(function(data){
				if(data.ret !== 1){
					getCheckCode('bind-account-form');
					if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#checkcode'), data.errMsg);
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = data.url;
				}
			}).fail(function(){
				console.log('网络错误');
			});
		};
		$('#go-login').on('click', function(e){
			var _self = this;
			e.preventDefault();
			
			if(!vform.valid('bind-account-form')){
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret !== 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}

		});
	};
	// 找回密码申请表单提交
	this.retrievePasswordSub = function(){

		var formElement = $('#retrieve-password')[0];
		var formSubmit = function(){
			var pData = $(formElement).serialize();
			var account = $('#account').val();
			$.ajax({
				url: ROOT_URL+'o_customer/security/authAccount',
				type: 'POST',
				dataType: 'json',
				data: pData
			}).done(function(data){
				if(data.ret !== 1){
					getCheckCode('retrieve-password');
					if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#checkcode'), data.errMsg);
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = ROOT_URL+'o_customer/security/findPwdAuthPage?account='+account;
				}
			}).fail(function(){
				console.log('网络错误');
			});
		};
		$('.submit-btn').on('click', function(e){
			var _self = this;
			e.preventDefault();
			if(!vform.valid('retrieve-password')){
				return ;
			}				
			if(formElement.jqXHR){

				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	};

	// 找回密码身份验证表单提交
	this.retrievePasswordAuth = function(){
		$('.submit-btn').on('click', function(e){
			e.preventDefault();

			var $checkEle = $('[type="radio"]:checked');
			var wayV = $checkEle.val();
			
			if(wayV === 'email'){
				formId = 'retrieve-password-auth-m';
			}else if(wayV === 'phone'){
				formId = 'retrieve-password-auth-p';
			}

			var formElement = $('#'+formId)[0];
			if(vform.valid(formId)){
				var pData = $(formElement).serialize();
				var account = $('#account').val();
				$.ajax({
					url: ROOT_URL+'o_customer/security/auth',
					type: 'POST',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret !== 1){
						getCheckCode(formId);
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#captcha'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}

					}else{
						location.href = ROOT_URL+'o_customer/security/resetPwd?token_code='+data.token.code+'&token_type='+data.token.type;
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	};

	// 重置密码表单提交
	this.retrievePasswordReset = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#retrieve-password')[0];
			e.preventDefault();
			$('#rePassword').trigger('change');
			if(vform.valid('retrieve-password')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/updatePwd',
					type: 'POST',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret !== 1){
						vform.process.formErrorHold(formElement, data.errMsg);
					}else{
						location.href = ROOT_URL+'o_customer/security/pwdUpdatedPage';
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	};
	// 修改密码表单提交
	this.changePassword = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#change-password')[0];
			e.preventDefault();
			if(vform.valid('change-password')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/auth',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						getCheckCode('change-password');
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#checkcode'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = ROOT_URL+'o_customer/security/setPasswordPage?token_code='+data.token.code+'&token_type='+data.token.type;
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	};
	// 设置新密码表单提交
	this.setNewPassword = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#reset-password-form')[0];
			e.preventDefault();
			$('#repassword').trigger('change');
			if(vform.valid('reset-password-form')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/updatePwd',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						vform.process.formErrorHold(formElement, data.errMsg);
					}else{
						location.href = ROOT_URL+'o_customer/security/passwordUpdatedPage';
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	};

	// 修改绑定手机申请表单提交
	this.changeBindPhone = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#u-cellphone-auth')[0];
			e.preventDefault();
			if(vform.valid('u-cellphone-auth')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/auth',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						getCheckCode('u-cellphone-auth');
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#checkcode'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = ROOT_URL+'o_customer/security/setCellphonePage?token_code='+data.token.code+'&token_type='+data.token.type;
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	}

	// 修改绑定邮箱申请表单提交
	this.changeBindEmail = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#u-email-auth')[0];
			e.preventDefault();
			if(vform.valid('u-email-auth')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/auth',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						getCheckCode('u-email-auth');
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#checkcode'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = ROOT_URL+'o_customer/security/setEmailPage?token_code='+data.token.code+'&token_type='+data.token.type;
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	}

	// 修改绑定邮箱申请表单提交
	this.authEmail = function(){
		$('.submit-btn').on('click', function(e){
			var formElement = $('#email-auth')[0];
			e.preventDefault();
			if(vform.valid('email-auth')){
				var pData = $(formElement).serialize();
				$.ajax({
					url: ROOT_URL+'o_customer/security/bind',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						getCheckCode('email-auth');
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#pCode'), data.errMsg);
						}else if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#eCode'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#checkcode'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = ROOT_URL+'o_customer/security/index';
					}
				}).fail(function(){
					console.log('网络错误');
				});
			}
		});
	}

	// 更新绑定手机/邮箱表单提交
	this.updateBindPhone = function(){
		
		var formElement = $('#reset-cellphone-form')[0];
		var formSubmit = function(){
			var pData = $(formElement).serialize();
				console.dir(pData);
				$.ajax({
					url: ROOT_URL+'o_customer/security/updateBinding',
					type: 'post',
					dataType: 'json',
					data: pData
				}).done(function(data){
					if(data.ret != 1){
						getCheckCode('reset-cellphone-form');
						if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#code'), data.errMsg);
						}else if(/.*验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#checkcode'), data.errMsg);
						}else{
							vform.process.formErrorHold(formElement, data.errMsg);
						}
					}else{
						location.href = ROOT_URL+'o_customer/security/cellphoneUpdatedPage';
					}
				}).fail(function(){
					console.log('网络错误');
				});
		};
		$('.submit-btn').on('click', function(e){
			
			var _self = this;
			e.preventDefault();
			
			if(!vform.valid('reset-cellphone-form')){
				return ;
			}				
			if(formElement.jqXHR){
				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	}
	this.updateBindEmail = function(){

		var formElement = $('#reset-email-form')[0];
		var formSubmit = function(){
			var pData = $(formElement).serialize();
			$.ajax({
				url: ROOT_URL+'o_customer/security/updateBinding',
				type: 'post',
				dataType: 'json',
				data: pData
			}).done(function(data){
				if(data.ret != 1){
					getCheckCode('reset-email-form');
					if(/.*邮箱验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#code'), data.errMsg);
					}else if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#checkcode'), data.errMsg);
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = ROOT_URL+'o_customer/security/emailUpdatedPage';
				}
			}).fail(function(){
				console.log('网络错误');
			});
		};
		$('.submit-btn').on('click', function(e){

			var _self = this;
			e.preventDefault();
			
			if(!vform.valid('reset-email-form')){
				return ;
			}				
			if(formElement.jqXHR){
				$.when(formElement.jqXHR).done(function(data){
					if(data.ret == 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	}
	// 安全认证表单提交(弹框)
	this.safetyVerify = function(){

		var formElement = $('#safety-verify-form')[0];
		var formSubmit = function(){
			var pData = $(formElement).serialize();
			$.ajax({
				url: ROOT_URL+'o_customer/security/bind',
				type: 'post',
				dataType: 'json',
				data: pData
			}).done(function(data){
				if(data.ret !== 1){
					getCheckCode('safety-verify-form');
					if(/.*手机验证码.*/.test(data.errMsg)){
							vform.process.errorHold($('#bCode'), data.errMsg);
					}else if(/.*验证码.*/.test(data.errMsg)){
						vform.process.errorHold($('#bCaptcha'), data.errMsg);
					}else{
						vform.process.formErrorHold(formElement, data.errMsg);
					}
				}else{
					location.href = ROOT_URL+'o_customer/security/index';
				}
			}).fail(function(){
				console.log('网络错误');
			});
		}
		$('#d-bind-submit').on('click', function(e){
			var _self = this;
			e.preventDefault();
			
			if(!vform.valid('safety-verify-form')){
				return ;
			}				
			if(formElement.jqXHR){
				$.when(formElement.jqXHR).done(function(data){
					if(data.ret === 1){
						formSubmit.call(_self);
					}
				});
			}else{
				formSubmit.call(_self);
			}
		});
	}
}

// 用户弹框
userDialog = new function(){
	var _self = this;
	var _wraper = '<div class="dialog-wraper"></div>'
	var _loginForm = '<div class="login-dialog-inner">'+
						'<form id="login-form">	'+	
						'<div class="form-alert"><p class="error"></p></div>'+
						'<input class="J-checkcode-type" type="hidden" name="checkcode-type" value="login" disabled>'+				
						'<div class="form-group form-account htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-icon"></span>'+
								'<input id="username" class="form-text" name="username" type="text" autocomplete="off">'+
								'<label class="input-text" for="username">已验证手机/邮箱</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-group form-password htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-icon"></span>'+
								'<input id="password" class="form-text" name="password" type="password" autocomplete="off">'+
								'<label class="input-text" for="password">密码</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+							
						'<div class="J-checkcode form-group form-checkcode htc-ignore">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-icon"></span>'+
								'<input id="captcha" class="J-checkcode-input form-text" name="captcha" type="text" maxlength="6" autocomplete="off">'+
								'<label class="input-text" for="captcha">请输入验证码</label>'+
								'<span  class="code-img" onclick="getCheckCode(\'login-form\')"><img width="46" height="36" src="" /></span>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-remember">'+
							'<span class="left">'+
								'<input id="rem" class="hidden" type="checkbox" name="remember_me" value="1" checked>'+
								'<label class="check-box" for="rem">记住密码</label>'+
							'</span>'+
							'<a class="right" href="'+ROOT_URL+'o_customer/security/findpwdpage">忘记密码?</a>'+
						'</div>'+
						'<div class="form-submit">'+
							'<button id="login-btn" class="submit-btn login-btn" type="submit"></button>'+
						'</div>'+
						'</form>'+
					'</div>';
	var _regFrom = '<div class="inner">'+
					'<form id="phone-reg-form">'+
						'<input type="hidden" name="formId" value="phone-reg-form" />'+
						'<div class="form-alert"><p class="error"></p></div>'+
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">手 机 号 码</span>'+
								'<input id="cellphone" class="J-phone-input form-text" name="cellphone" type="text" maxlength="11 autocomplete="off">'+
								'<label class="input-text" for="cellphone">请使用常用手机</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-change">或使用<a href="javascript:regChange(\'email-reg-form\');">邮箱注册</a></div>'+
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">请设置密码</span>'+
								'<input id="pPassword" class="form-text" name="password" type="password" autocomplete="off">'+
								'<label class="input-text" for="pPassword">6-16个数字、字母或符号区分大小写</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+	
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">确 认 密 码</span>'+
								'<input id="pRepassword" class="form-text" name="password_confirm" type="password" autocomplete="off">'+
								'<label class="input-text" for="pRepassword">请输入确认密码</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>	'+
						'<div class="J-checkcode form-group form-checkcode htc-ignore">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">验　证　码<i></i></span>'+
								'<input id="pCaptcha" class="J-checkcode-input form-text" name="captcha" type="text" maxlength="6" autocomplete="off">'+
								'<label class="input-text" for="pCaptcha">请输入验证码</label>'+
								'<span  class="code-img" onclick="getCheckCode(\'phone-reg-form\')"><img width="46" height="36" src="" /></span>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="J-phonecode form-group form-phonecode htc-ignore">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">手机验证码</span>'+
								'<input id="pCode" class="J-phonecode-input form-text" name="code" type="text" maxlength="6" autocomplete="off">'+
								'<label class="input-text" for="pCode">请输入手机验证码</label>'+
								'<button class="J-get-phone-code get-phone-code" type="button" onclick="getPhoneCode(\'phone-reg-form\')">获取验证码</button> '+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-agreen htc-require">'+
							'<span class="left">'+
								'<input id="pAgree" class="hidden" type="checkbox" value="1" name="agree" checked>'+
								'<label class="check-box" for="pAgree">我已阅读并同意</label>'+
								'<a href="#">《海豚村服务条款》</a>'+
							'</span>'+
						'</div>'+
						'<div class="form-submit">'+
							'<button id="reg-by-phone" class="submit-btn register-btn" type="submit"></button>'+
						'</div>'+
					'</form>'+
					'<form id="email-reg-form" class="hidden">'+
						'<input type="hidden" name="formId" value="email-reg-form" />'+
						'<div class="form-alert"><p class="error"></p></div>'+
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">邮 箱 账 号</span>'+
								'<input id="email" class="J-email-input form-text" name="email" type="text">'+
								'<label class="input-text" for="email">建议使用常用邮箱</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-change">或使用<a href="javascript:regChange(\'phone-reg-form\');">手机注册</a></div>'+
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">请设置密码</span>'+
								'<input id="ePassword" class="form-text" name="password" type="password" autocomplete="off">'+
								'<label class="input-text" for="ePassword">请输入密码</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">确 认 密 码</span>'+
								'<input id="eRepassword" class="form-text" name="password_confirm" type="password" autocomplete="off">'+
								'<label class="input-text" for="eRepassword">请输入确认密码</label>'+
								'<i class="i-status"></i>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+	
						'<div class="form-group htc-require">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">手 机 号 码</span>'+
								'<input id="eCellphone" class="J-phone-input form-text" name="cellphone" type="text" maxlength="11" autocomplete="off">'+
								'<label class="input-text" for="eCellphone">请输入常用手机</label>'+
								'<i class="i-reset"></i>'+
								'<i class="i-status"></i>'+
							'</div>'+
						'</div>'+
						'<div class="J-checkcode form-group form-checkcode htc-ignore">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">验　证　码</span>'+
								'<input id="eCaptcha" class="J-checkcode-input form-text" name="captcha" type="text" maxlength="6" autocomplete="off">'+
								'<label class="input-text" for="eCaptcha">请输入验证码</label>'+
								'<span  class="code-img" onclick="getCheckCode(\'email-reg-form\')"><img width="46" height="36" src="" /></span>'+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="J-phonecode form-group form-phonecode htc-ignore">'+
							'<div class="input-tip">'+
								'<span class="error"></span>'+
							'</div>'+
							'<div class="input-area">'+
								'<span class="input-label">手机验证码</span>'+
								'<input id="eCode" class="J-phonecode-input form-text" name="code" type="text" maxlength="6" autocomplete="off">'+
								'<label class="input-text" for="eCode">请输入手机验证码</label>'+
								'<button class="J-get-phone-code get-phone-code" type="button" onclick="getPhoneCode(\'email-reg-form\')">获取验证码</button> '+
								'<i class="i-reset"></i>'+
							'</div>'+
						'</div>'+
						'<div class="form-agreen htc-require">'+
							'<span class="left">'+
								'<input id="eAgree" class="hidden" type="checkbox" value="1" name="agree" checked>'+
								'<label class="check-box" for="eAgree">我已阅读并同意</label>'+
								'<a href="#">《海豚村服务条款》</a>'+
							'</span>'+
						'</div>'+
						'<div class="form-submit">'+
							'<button id="reg-by-email" class="submit-btn register-btn" type="submit"></button>'+
						'</div>'+
					'</form>'+
				'</div>';
	var _loginRegDialogContent = '<div id="d-login-reg" class="login-reg-dialog u-dialog">'+
								'<div class="u-form">'+
									'<div class="form-header">'+
										'<h1>海豚村会员</h1>'+
										'<a class="close-btn right" href="javascript:userDialog.closeDialog(\'d-login-reg\');" title="关闭"></a>'+
									'</div>'+
									'<div class="form-tab">'+
										'<a class="tab-a" href="javascript:void(0);" data-index="0" data-role="login-dialog">账号登录</a><a class="tab-a" href="javascript:void(0);" data-index="1" data-role="register-dialog">免费注册</a>'+
										'<span class="tab-line"></span>'+
										'<span class="tab-slide"></span>'+
									'</div>'+
									'<div id="login-dialog" class="form-box">'+
									_loginForm +
									'</div>'+
									'<div id="register-dialog" class="form-box form-label-input hidden">'+
									_regFrom +
									'</div>'+
									'<div class="form-footer">'+
										'<dl class="coagent">'+
											'<dt>快捷登录方式:</dt>'+
											'<dd class="qq"><a href="'+ROOT_URL+'union/login/login/state/qq" title="QQ"></a></dd>'+
											'<dd class="sweibo"><a href="'+ROOT_URL+'union/login/login/state/sina" title="新浪微博"></a></dd>'+
											'<dd class="ali"><a href="'+ROOT_URL+'union/login/login/state/alipay" title="支付宝"></a></dd>'+
											'<dd class="bank"><a href="'+ROOT_URL+'union/login/login/state/unionpay" title="银联"></a></dd>'+
										'</dl>'+
										'<div class="by-weixin right">'+
											'<div class="wx-tip">微信扫描直接登录</div>'+
											'<div class="wx-entry">'+
												'<a id="wx-toggle" class="wx-toggle" href="javascript:void(0);"></a>'+
											'</div>'+
										'</div>'+
									'</div>'+
									'<div class="ew-container">'+
										'<div class="inner">'+
											'<h2>打开微信，扫码直接登录</h2>'+
											'<img class="wx-login" src="' + ROOT_URL + 'skin/frontend/PlumTree/default/images/v3/lay_ajaxload.gif" alt="" width="160" height="160">'+
										'</div>'+
										'<i class="mid-i"></i>'+
										'<a class="wx-toggle" href="javascript:void(0);"></a>'+
									'</div>'+
								'</div>'+
							'</div>';

	var _bindPhoneForm = '<div id="d-bind-phone" class="safety-verify-dialog u-dialog">'+
							'<div class="u-form">'+
								'<div class="form-header">'+
									'<h1>安全验证</h1>'+
									'<a class="close-btn right" href="javascript:userDialog.closeDialog(\'d-bind-phone\');" title="关闭"></a>'+
								'</div>'+
								'<div class="form-box form-label-input">'+
									'<div class="inner">'+
										'<div class="form-tips">'+
											'<p>为了保护您的账号安全，请先进行安全验证。</p>'+
										'</div>'+
										'<form id="safety-verify-form">	'+	
											'<div class="form-alert"><p class="error"></p></div>'+				
											'<div class="J-checkcode form-group form-checkcode htc-require">'+
												'<div class="input-tip">'+
													'<span class="error"></span>'+
												'</div>'+
												'<div class="input-area">'+
													'<span class="input-label">验　证　码</span>'+
													'<input id="bCaptcha" class="J-checkcode-input form-text" name="captcha" type="text" maxlength="6" autocomplete="off">'+
													'<label class="input-text" for="bCaptcha">请输入验证码</label>'+
													'<span  class="code-img" onclick="getCheckCode(\'safety-verify-form\')"><img width="46" height="36" src="" />　换一张</span>'+
													'<i class="i-reset"></i>'+
												'</div>'+
											'</div>'+
											'<div class="form-group htc-require">'+
												'<div class="input-tip">'+
													'<span class="error"></span>'+
												'</div>'+
												'<div class="input-area">'+
													'<span class="input-label">手 机 号 码</span>'+
													'<input id="bCellphone" class="J-phone-input form-text" name="cellphone" type="text" maxlength="11" autocomplete="off">'+
													'<label class="input-text" for="bCellphone">请使用常用手机</label>'+
													'<i class="i-status"></i>'+
													'<i class="i-reset"></i>'+
												'</div>'+
											'</div>	'+
											'<div class="form-group form-phonecode htc-require">'+
												'<div class="input-tip">'+
													'<span class="error"></span>'+
												'</div>'+
												'<div class="input-area">'+
													'<span class="input-label">短信验证码</span>'+
													'<input id="bCode" class="form-text" name="code" type="text" maxlength="6" autocomplete="off">'+
													'<label class="input-text" for="bCode">请输入手机验证码</label>'+
													'<button class="J-get-phone-code get-phone-code" type="button" onclick="getPhoneCode(\'safety-verify-form\')">获取验证码</button>'+
												'</div>'+
											'</div>'+	
											'<div class="form-submit">'+
												'<button id="d-bind-submit" class="submit-btn" type="submit">确认</button>'+
											'</div>'+
										'</form>'+
									'</div>'+
								'</div>'+
							'</div>'+
						'</div>';
	var _saftyTip = '<div id="safty-tip-layer" class="safty-tip-layer">'+
					    '<div class="grid-all textl">'+
					    	'<a href="'+ROOT_URL+'o_customer/security/index/">'+
						        '由于海豚村会员系统调整，<strong>自3月1日起将暂停赠送海豚币</strong>，注册/下单/晒单/手机验证均不再赠送，给您带来的不便，敬请谅解！'+
					        '</a>'+
					        '<a id="stl-close" class="stl-close" href="javascript:userDialog.closeDialog(\'safty-tip-layer\');"></a>'+
					    '</div>'+
					'</div>';
	var _loginRegJS = '<script>'+
						'formUIInit();'+ // 表单UI初始化
						'formElementValidator.login();'+ // 登录表单验证
						'formSubmitEvent.login();'+ // 登录表单提交
						'formElementValidator.regByPhone();'+ // 手机注册表单验证
						'formSubmitEvent.regByPhone();'+ // 手机注册表单提交
						'formElementValidator.regByEmail();'+ // 邮箱注册表单验证
						'formSubmitEvent.regByEmail();'+ // 邮箱注册表单提交
					'</script>';	
	var _bindPhoneJS = '<script>'+
						'formUIInit();'+ // 表单UI初始化
						'formElementValidator.safetyVerify();'+
						'formSubmitEvent.safetyVerify();'+
					'</script>';
	// 弹出对话框
	var _showDialog = function(dialogId){
		$('.dialog-wraper').show();
		$('#'+dialogId).show();
	};
	// 登录注册弹框
	_self.loginReg = function(){
		if($('#d-login-reg').length < 1){
			$('body').append(_wraper+_loginRegDialogContent + _loginRegJS);
		}else{
			_showDialog('d-login-reg');
		}
	};
	// 绑定手机弹框
	_self.bindPhone = function(){
		if($('#d-bind-phone').length <1){
			$('body').append(_wraper+_bindPhoneForm+_bindPhoneJS);
		}else{
			_showDialog('d-bind-phone');
		}
		getCheckCode('safety-verify-form');
	};
	// 安全提示弹层
	_self.saftyTip = function(){
		if($('#safty-tip-layer').length <1){
			$('.main-container').before(_saftyTip);
		}else{
			_showDialog('safty-tip-layer');
		}
	};
	// 关闭对话框
	_self.closeDialog = function(dialogId){
		$('.dialog-wraper').hide();
		$('#'+dialogId).hide();
		if(dialogId === 'd-bind-phone'){
			$.cookie('bind_phone_alert', 1, { expires: 7, path: '/' }); 
		}else if(dialogId === 'safty-tip-layer'){
			$.cookie('bind_phone_tips', 1, { expires: 7, path: '/' }); 
		}
	};
}



