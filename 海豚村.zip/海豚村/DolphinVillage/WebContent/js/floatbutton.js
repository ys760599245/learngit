try{document.open();}catch(e){;}
//var live800_companyID=getQueryString('companyID');
var jsessionId = ";jsessionid=CF48E74E8366F076493413B4F56C540D";
try{
    if(navigator.cookieEnabled){jsessionId = "";}
}catch(e){}
var enterurl = null;
var isOldSkin=false;
var server_prefix_list=['https://v2.live800.com/live800'];
var isNeedCheckDomainBinding=false;
var globalWindowAttribute='toolbar=0,scrollbars=0,location=0,menubar=0,resizable=1,width=920,height=620';
live800_chatVersion="5";
//jid=getQueryString('jid');
var live800_baseUrl="v2.live800.com";
var live800_baseHtmlUrl="v2.live800.com";
var live800_baseWebApp="/live800";
var live800_baseChatHtmlDir="/chatClient";
//trustfulInfo=getQueryString('info');
//alert(jQuery("#customer-service").attr("id"));
live800_Language="zh";
//live800_configID=getQueryString('configID');
live800_configContent="live800_float=1&live800_online=http%3A%2F%2Fv2.live800.com%2Flive800%2FchatClient%2Ficons%2F21_online.gif&live800_offline=http%3A%2F%2Fv2.live800.com%2Flive800%2FchatClient%2Ficons%2F21_offline.gif&live800_closeIcon=0&live800_floatToRight=1&live800_floatTop=150&live800_floatSide=5&live800_switch=0&Live800_default=1";

document.write("<scr"+"ipt language=\"javascript\" src=\""+SKIN_URL+"js/live800/floatButtonStatic.js\"></scr"+"ipt>");