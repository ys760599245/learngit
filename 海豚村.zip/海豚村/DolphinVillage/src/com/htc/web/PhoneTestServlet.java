package com.htc.web;

import java.io.IOException;
import java.io.PrintWriter;



import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.alibaba.fastjson.JSON;
import com.htc.service.PhoneService;
import com.htc.service.impl.PhoneServiceImpl;

public class PhoneTestServlet extends HttpServlet {

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter out = response.getWriter();
		
		PhoneService phService=new PhoneServiceImpl();
		
		String opr=request.getParameter("opr");
		if("opr".equals(opr)){
			String phone=request.getParameter("phone");
			System.out.println("PhoneTestServlet"+phone);
			int code=phService.getCode(phone);
			out.print(code);
			response.sendRedirect("./regist.jsp");
		}
		out.flush();
		out.close();
		
		
	}

}
