package com.htc.service.impl;

import com.htc.service.PhoneService;
import com.htc.util.sendsms;

public class PhoneServiceImpl implements PhoneService{

	int code=0;
	sendsms sendsms=new sendsms();
	
	@Override
	public int getCode(String cellphone) {
		if(cellphone!=null&&!cellphone.equals("")){
			code=(int)((Math.random()*9+1)*100000);//获取六位数
			System.out.println("PhoneServiceImpl"+code);
			System.out.println("PhoneServiceImpl"+cellphone);
			sendsms.getPhone(cellphone, code);//手机号 验证码
			return code; //获得验证码
		}
		return 0;
	}
}
