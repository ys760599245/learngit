package com.htc.service;

public interface PhoneService {

	/**
	 * 短信接口
	 * @param phone
	 * 输入手机号码获得验证码
	 */
	public int getCode(String cellphone);
	
}
